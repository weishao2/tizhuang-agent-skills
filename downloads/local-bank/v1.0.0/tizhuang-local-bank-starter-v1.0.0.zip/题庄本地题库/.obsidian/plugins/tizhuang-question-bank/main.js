var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name2 in all)
    __defProp(target, name2, { get: all[name2], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.js
var main_exports = {};
__export(main_exports, {
  BankView: () => BankView,
  LibraryView: () => LibraryView,
  default: () => TeacherBankPlugin,
  markdown: () => markdown
});
module.exports = __toCommonJS(main_exports);

// src/navigation.js
var import_obsidian = require("obsidian");
var NAVIGATION = [["home", "\u9996\u9875"], ["website", "\u7F51\u7AD9\u53D6\u9898"], ["questions", "\u6211\u7684\u9898\u76EE"], ["basket", "\u7EC4\u5377\u7BEE"], ["pdf", "PDF \u5BFC\u5165"]];
function renderNavigation(parent, view, active) {
  const nav = document.createElement("nav");
  nav.className = "tz-lib-tabs";
  nav.setAttribute("aria-label", "\u672C\u5730\u9898\u5E93\u5BFC\u822A");
  parent.append(nav);
  for (const [id, label2] of NAVIGATION) {
    const button2 = document.createElement("button");
    button2.type = "button";
    button2.className = "tz-quiet";
    button2.dataset.tab = id;
    button2.textContent = id === "basket" && view.plugin.basket?.data.items.length ? `${label2}\uFF08${view.plugin.basket.data.items.length}\uFF09` : label2;
    button2.classList.toggle("is-active", id === active);
    if (id === active) button2.setAttribute("aria-current", "page");
    button2.onclick = () => {
      if (view.plugin.localTaskActive || view.plugin.store?.busy || view.plugin.basket?.busy) {
        new import_obsidian.Notice("\u6B63\u5728\u4FDD\u5B58\u9898\u5E93\uFF0C\u8BF7\u7A0D\u5019\u518D\u5207\u6362\u3002");
        return;
      }
      return id === active ? void 0 : id === "website" ? view.plugin.open(view.leaf) : view.plugin.openLibrary(id, view.leaf);
    };
    nav.append(button2);
  }
  return nav;
}

// node_modules/yaml/browser/dist/index.js
var dist_exports = {};
__export(dist_exports, {
  Alias: () => Alias,
  CST: () => cst_exports,
  Composer: () => Composer,
  Document: () => Document,
  Lexer: () => Lexer,
  LineCounter: () => LineCounter,
  Pair: () => Pair,
  Parser: () => Parser,
  Scalar: () => Scalar,
  Schema: () => Schema,
  YAMLError: () => YAMLError,
  YAMLMap: () => YAMLMap,
  YAMLParseError: () => YAMLParseError,
  YAMLSeq: () => YAMLSeq,
  YAMLWarning: () => YAMLWarning,
  isAlias: () => isAlias,
  isCollection: () => isCollection,
  isDocument: () => isDocument,
  isMap: () => isMap,
  isNode: () => isNode,
  isPair: () => isPair,
  isScalar: () => isScalar,
  isSeq: () => isSeq,
  parse: () => parse,
  parseAllDocuments: () => parseAllDocuments,
  parseDocument: () => parseDocument,
  stringify: () => stringify3,
  visit: () => visit,
  visitAsync: () => visitAsync
});

// node_modules/yaml/browser/dist/nodes/identity.js
var ALIAS = Symbol.for("yaml.alias");
var DOC = Symbol.for("yaml.document");
var MAP = Symbol.for("yaml.map");
var PAIR = Symbol.for("yaml.pair");
var SCALAR = Symbol.for("yaml.scalar");
var SEQ = Symbol.for("yaml.seq");
var NODE_TYPE = Symbol.for("yaml.node.type");
var isAlias = (node2) => !!node2 && typeof node2 === "object" && node2[NODE_TYPE] === ALIAS;
var isDocument = (node2) => !!node2 && typeof node2 === "object" && node2[NODE_TYPE] === DOC;
var isMap = (node2) => !!node2 && typeof node2 === "object" && node2[NODE_TYPE] === MAP;
var isPair = (node2) => !!node2 && typeof node2 === "object" && node2[NODE_TYPE] === PAIR;
var isScalar = (node2) => !!node2 && typeof node2 === "object" && node2[NODE_TYPE] === SCALAR;
var isSeq = (node2) => !!node2 && typeof node2 === "object" && node2[NODE_TYPE] === SEQ;
function isCollection(node2) {
  if (node2 && typeof node2 === "object")
    switch (node2[NODE_TYPE]) {
      case MAP:
      case SEQ:
        return true;
    }
  return false;
}
function isNode(node2) {
  if (node2 && typeof node2 === "object")
    switch (node2[NODE_TYPE]) {
      case ALIAS:
      case MAP:
      case SCALAR:
      case SEQ:
        return true;
    }
  return false;
}
var hasAnchor = (node2) => (isScalar(node2) || isCollection(node2)) && !!node2.anchor;

// node_modules/yaml/browser/dist/visit.js
var BREAK = Symbol("break visit");
var SKIP = Symbol("skip children");
var REMOVE = Symbol("remove node");
function visit(node2, visitor) {
  const visitor_ = initVisitor(visitor);
  if (isDocument(node2)) {
    const cd = visit_(null, node2.contents, visitor_, Object.freeze([node2]));
    if (cd === REMOVE)
      node2.contents = null;
  } else
    visit_(null, node2, visitor_, Object.freeze([]));
}
visit.BREAK = BREAK;
visit.SKIP = SKIP;
visit.REMOVE = REMOVE;
function visit_(key, node2, visitor, path) {
  const ctrl = callVisitor(key, node2, visitor, path);
  if (isNode(ctrl) || isPair(ctrl)) {
    replaceNode(key, path, ctrl);
    return visit_(key, ctrl, visitor, path);
  }
  if (typeof ctrl !== "symbol") {
    if (isCollection(node2)) {
      path = Object.freeze(path.concat(node2));
      for (let i = 0; i < node2.items.length; ++i) {
        const ci = visit_(i, node2.items[i], visitor, path);
        if (typeof ci === "number")
          i = ci - 1;
        else if (ci === BREAK)
          return BREAK;
        else if (ci === REMOVE) {
          node2.items.splice(i, 1);
          i -= 1;
        }
      }
    } else if (isPair(node2)) {
      path = Object.freeze(path.concat(node2));
      const ck = visit_("key", node2.key, visitor, path);
      if (ck === BREAK)
        return BREAK;
      else if (ck === REMOVE)
        node2.key = null;
      const cv = visit_("value", node2.value, visitor, path);
      if (cv === BREAK)
        return BREAK;
      else if (cv === REMOVE)
        node2.value = null;
    }
  }
  return ctrl;
}
async function visitAsync(node2, visitor) {
  const visitor_ = initVisitor(visitor);
  if (isDocument(node2)) {
    const cd = await visitAsync_(null, node2.contents, visitor_, Object.freeze([node2]));
    if (cd === REMOVE)
      node2.contents = null;
  } else
    await visitAsync_(null, node2, visitor_, Object.freeze([]));
}
visitAsync.BREAK = BREAK;
visitAsync.SKIP = SKIP;
visitAsync.REMOVE = REMOVE;
async function visitAsync_(key, node2, visitor, path) {
  const ctrl = await callVisitor(key, node2, visitor, path);
  if (isNode(ctrl) || isPair(ctrl)) {
    replaceNode(key, path, ctrl);
    return visitAsync_(key, ctrl, visitor, path);
  }
  if (typeof ctrl !== "symbol") {
    if (isCollection(node2)) {
      path = Object.freeze(path.concat(node2));
      for (let i = 0; i < node2.items.length; ++i) {
        const ci = await visitAsync_(i, node2.items[i], visitor, path);
        if (typeof ci === "number")
          i = ci - 1;
        else if (ci === BREAK)
          return BREAK;
        else if (ci === REMOVE) {
          node2.items.splice(i, 1);
          i -= 1;
        }
      }
    } else if (isPair(node2)) {
      path = Object.freeze(path.concat(node2));
      const ck = await visitAsync_("key", node2.key, visitor, path);
      if (ck === BREAK)
        return BREAK;
      else if (ck === REMOVE)
        node2.key = null;
      const cv = await visitAsync_("value", node2.value, visitor, path);
      if (cv === BREAK)
        return BREAK;
      else if (cv === REMOVE)
        node2.value = null;
    }
  }
  return ctrl;
}
function initVisitor(visitor) {
  if (typeof visitor === "object" && (visitor.Collection || visitor.Node || visitor.Value)) {
    return Object.assign({
      Alias: visitor.Node,
      Map: visitor.Node,
      Scalar: visitor.Node,
      Seq: visitor.Node
    }, visitor.Value && {
      Map: visitor.Value,
      Scalar: visitor.Value,
      Seq: visitor.Value
    }, visitor.Collection && {
      Map: visitor.Collection,
      Seq: visitor.Collection
    }, visitor);
  }
  return visitor;
}
function callVisitor(key, node2, visitor, path) {
  if (typeof visitor === "function")
    return visitor(key, node2, path);
  if (isMap(node2))
    return visitor.Map?.(key, node2, path);
  if (isSeq(node2))
    return visitor.Seq?.(key, node2, path);
  if (isPair(node2))
    return visitor.Pair?.(key, node2, path);
  if (isScalar(node2))
    return visitor.Scalar?.(key, node2, path);
  if (isAlias(node2))
    return visitor.Alias?.(key, node2, path);
  return void 0;
}
function replaceNode(key, path, node2) {
  const parent = path[path.length - 1];
  if (isCollection(parent)) {
    parent.items[key] = node2;
  } else if (isPair(parent)) {
    if (key === "key")
      parent.key = node2;
    else
      parent.value = node2;
  } else if (isDocument(parent)) {
    parent.contents = node2;
  } else {
    const pt = isAlias(parent) ? "alias" : "scalar";
    throw new Error(`Cannot replace node with ${pt} parent`);
  }
}

// node_modules/yaml/browser/dist/doc/directives.js
var escapeChars = {
  "!": "%21",
  ",": "%2C",
  "[": "%5B",
  "]": "%5D",
  "{": "%7B",
  "}": "%7D"
};
var escapeTagName = (tn) => tn.replace(/[!,[\]{}]/g, (ch) => escapeChars[ch]);
var Directives = class _Directives {
  constructor(yaml, tags) {
    this.docStart = null;
    this.docEnd = false;
    this.yaml = Object.assign({}, _Directives.defaultYaml, yaml);
    this.tags = Object.assign({}, _Directives.defaultTags, tags);
  }
  clone() {
    const copy = new _Directives(this.yaml, this.tags);
    copy.docStart = this.docStart;
    return copy;
  }
  /**
   * During parsing, get a Directives instance for the current document and
   * update the stream state according to the current version's spec.
   */
  atDocument() {
    const res = new _Directives(this.yaml, this.tags);
    switch (this.yaml.version) {
      case "1.1":
        this.atNextDocument = true;
        break;
      case "1.2":
        this.atNextDocument = false;
        this.yaml = {
          explicit: _Directives.defaultYaml.explicit,
          version: "1.2"
        };
        this.tags = Object.assign({}, _Directives.defaultTags);
        break;
    }
    return res;
  }
  /**
   * @param onError - May be called even if the action was successful
   * @returns `true` on success
   */
  add(line, onError) {
    if (this.atNextDocument) {
      this.yaml = { explicit: _Directives.defaultYaml.explicit, version: "1.1" };
      this.tags = Object.assign({}, _Directives.defaultTags);
      this.atNextDocument = false;
    }
    const parts = line.trim().split(/[ \t]+/);
    const name2 = parts.shift();
    switch (name2) {
      case "%TAG": {
        if (parts.length !== 2) {
          onError(0, "%TAG directive should contain exactly two parts");
          if (parts.length < 2)
            return false;
        }
        const [handle, prefix] = parts;
        this.tags[handle] = prefix;
        return true;
      }
      case "%YAML": {
        this.yaml.explicit = true;
        if (parts.length !== 1) {
          onError(0, "%YAML directive should contain exactly one part");
          return false;
        }
        const [version] = parts;
        if (version === "1.1" || version === "1.2") {
          this.yaml.version = version;
          return true;
        } else {
          const isValid = /^\d+\.\d+$/.test(version);
          onError(6, `Unsupported YAML version ${version}`, isValid);
          return false;
        }
      }
      default:
        onError(0, `Unknown directive ${name2}`, true);
        return false;
    }
  }
  /**
   * Resolves a tag, matching handles to those defined in %TAG directives.
   *
   * @returns Resolved tag, which may also be the non-specific tag `'!'` or a
   *   `'!local'` tag, or `null` if unresolvable.
   */
  tagName(source, onError) {
    if (source === "!")
      return "!";
    if (source[0] !== "!") {
      onError(`Not a valid tag: ${source}`);
      return null;
    }
    if (source[1] === "<") {
      const verbatim = source.slice(2, -1);
      if (verbatim === "!" || verbatim === "!!") {
        onError(`Verbatim tags aren't resolved, so ${source} is invalid.`);
        return null;
      }
      if (source[source.length - 1] !== ">")
        onError("Verbatim tags must end with a >");
      return verbatim;
    }
    const [, handle, suffix] = source.match(/^(.*!)([^!]*)$/s);
    if (!suffix)
      onError(`The ${source} tag has no suffix`);
    const prefix = this.tags[handle];
    if (prefix) {
      try {
        return prefix + decodeURIComponent(suffix);
      } catch (error) {
        onError(String(error));
        return null;
      }
    }
    if (handle === "!")
      return source;
    onError(`Could not resolve tag: ${source}`);
    return null;
  }
  /**
   * Given a fully resolved tag, returns its printable string form,
   * taking into account current tag prefixes and defaults.
   */
  tagString(tag) {
    for (const [handle, prefix] of Object.entries(this.tags)) {
      if (tag.startsWith(prefix))
        return handle + escapeTagName(tag.substring(prefix.length));
    }
    return tag[0] === "!" ? tag : `!<${tag}>`;
  }
  toString(doc) {
    const lines = this.yaml.explicit ? [`%YAML ${this.yaml.version || "1.2"}`] : [];
    const tagEntries = Object.entries(this.tags);
    let tagNames;
    if (doc && tagEntries.length > 0 && isNode(doc.contents)) {
      const tags = {};
      visit(doc.contents, (_key, node2) => {
        if (isNode(node2) && node2.tag)
          tags[node2.tag] = true;
      });
      tagNames = Object.keys(tags);
    } else
      tagNames = [];
    for (const [handle, prefix] of tagEntries) {
      if (handle === "!!" && prefix === "tag:yaml.org,2002:")
        continue;
      if (!doc || tagNames.some((tn) => tn.startsWith(prefix)))
        lines.push(`%TAG ${handle} ${prefix}`);
    }
    return lines.join("\n");
  }
};
Directives.defaultYaml = { explicit: false, version: "1.2" };
Directives.defaultTags = { "!!": "tag:yaml.org,2002:" };

// node_modules/yaml/browser/dist/doc/anchors.js
function anchorIsValid(anchor) {
  if (/[\x00-\x19\s,[\]{}]/.test(anchor)) {
    const sa = JSON.stringify(anchor);
    const msg = `Anchor must not contain whitespace or control characters: ${sa}`;
    throw new Error(msg);
  }
  return true;
}
function anchorNames(root2) {
  const anchors = /* @__PURE__ */ new Set();
  visit(root2, {
    Value(_key, node2) {
      if (node2.anchor)
        anchors.add(node2.anchor);
    }
  });
  return anchors;
}
function findNewAnchor(prefix, exclude) {
  for (let i = 1; true; ++i) {
    const name2 = `${prefix}${i}`;
    if (!exclude.has(name2))
      return name2;
  }
}
function createNodeAnchors(doc, prefix) {
  const aliasObjects = [];
  const sourceObjects = /* @__PURE__ */ new Map();
  let prevAnchors = null;
  return {
    onAnchor: (source) => {
      aliasObjects.push(source);
      prevAnchors ?? (prevAnchors = anchorNames(doc));
      const anchor = findNewAnchor(prefix, prevAnchors);
      prevAnchors.add(anchor);
      return anchor;
    },
    /**
     * With circular references, the source node is only resolved after all
     * of its child nodes are. This is why anchors are set only after all of
     * the nodes have been created.
     */
    setAnchors: () => {
      for (const source of aliasObjects) {
        const ref = sourceObjects.get(source);
        if (typeof ref === "object" && ref.anchor && (isScalar(ref.node) || isCollection(ref.node))) {
          ref.node.anchor = ref.anchor;
        } else {
          const error = new Error("Failed to resolve repeated object (this should not happen)");
          error.source = source;
          throw error;
        }
      }
    },
    sourceObjects
  };
}

// node_modules/yaml/browser/dist/doc/applyReviver.js
function applyReviver(reviver, obj, key, val) {
  if (val && typeof val === "object") {
    if (Array.isArray(val)) {
      for (let i = 0, len = val.length; i < len; ++i) {
        const v0 = val[i];
        const v1 = applyReviver(reviver, val, String(i), v0);
        if (v1 === void 0)
          delete val[i];
        else if (v1 !== v0)
          val[i] = v1;
      }
    } else if (val instanceof Map) {
      for (const k of Array.from(val.keys())) {
        const v0 = val.get(k);
        const v1 = applyReviver(reviver, val, k, v0);
        if (v1 === void 0)
          val.delete(k);
        else if (v1 !== v0)
          val.set(k, v1);
      }
    } else if (val instanceof Set) {
      for (const v0 of Array.from(val)) {
        const v1 = applyReviver(reviver, val, v0, v0);
        if (v1 === void 0)
          val.delete(v0);
        else if (v1 !== v0) {
          val.delete(v0);
          val.add(v1);
        }
      }
    } else {
      for (const [k, v0] of Object.entries(val)) {
        const v1 = applyReviver(reviver, val, k, v0);
        if (v1 === void 0)
          delete val[k];
        else if (v1 !== v0)
          val[k] = v1;
      }
    }
  }
  return reviver.call(obj, key, val);
}

// node_modules/yaml/browser/dist/nodes/toJS.js
function toJS(value, arg, ctx) {
  if (Array.isArray(value))
    return value.map((v, i) => toJS(v, String(i), ctx));
  if (value && typeof value.toJSON === "function") {
    if (!ctx || !hasAnchor(value))
      return value.toJSON(arg, ctx);
    const data = { aliasCount: 0, count: 1, res: void 0 };
    ctx.anchors.set(value, data);
    ctx.onCreate = (res2) => {
      data.res = res2;
      delete ctx.onCreate;
    };
    const res = value.toJSON(arg, ctx);
    if (ctx.onCreate)
      ctx.onCreate(res);
    return res;
  }
  if (typeof value === "bigint" && !ctx?.keep)
    return Number(value);
  return value;
}

// node_modules/yaml/browser/dist/nodes/Node.js
var NodeBase = class {
  constructor(type) {
    Object.defineProperty(this, NODE_TYPE, { value: type });
  }
  /** Create a copy of this node.  */
  clone() {
    const copy = Object.create(Object.getPrototypeOf(this), Object.getOwnPropertyDescriptors(this));
    if (this.range)
      copy.range = this.range.slice();
    return copy;
  }
  /** A plain JavaScript representation of this node. */
  toJS(doc, { mapAsMap, maxAliasCount, onAnchor, reviver } = {}) {
    if (!isDocument(doc))
      throw new TypeError("A document argument is required");
    const ctx = {
      anchors: /* @__PURE__ */ new Map(),
      doc,
      keep: true,
      mapAsMap: mapAsMap === true,
      mapKeyWarned: false,
      maxAliasCount: typeof maxAliasCount === "number" ? maxAliasCount : 100
    };
    const res = toJS(this, "", ctx);
    if (typeof onAnchor === "function")
      for (const { count, res: res2 } of ctx.anchors.values())
        onAnchor(res2, count);
    return typeof reviver === "function" ? applyReviver(reviver, { "": res }, "", res) : res;
  }
};

// node_modules/yaml/browser/dist/nodes/Alias.js
var Alias = class extends NodeBase {
  constructor(source) {
    super(ALIAS);
    this.source = source;
    Object.defineProperty(this, "tag", {
      set() {
        throw new Error("Alias nodes cannot have tags");
      }
    });
  }
  /**
   * Resolve the value of this alias within `doc`, finding the last
   * instance of the `source` anchor before this node.
   */
  resolve(doc, ctx) {
    if (ctx?.maxAliasCount === 0)
      throw new ReferenceError("Alias resolution is disabled");
    let nodes;
    if (ctx?.aliasResolveCache) {
      nodes = ctx.aliasResolveCache;
    } else {
      nodes = [];
      visit(doc, {
        Node: (_key, node2) => {
          if (isAlias(node2) || hasAnchor(node2))
            nodes.push(node2);
        }
      });
      if (ctx)
        ctx.aliasResolveCache = nodes;
    }
    let found = void 0;
    for (const node2 of nodes) {
      if (node2 === this)
        break;
      if (node2.anchor === this.source)
        found = node2;
    }
    if (found && ctx) {
      const { anchors, doc: doc2, maxAliasCount } = ctx;
      let data = anchors.get(found);
      if (!data) {
        toJS(found, null, ctx);
        data = anchors.get(found);
      }
      if (data?.res === void 0) {
        const msg = "This should not happen: Alias anchor was not resolved?";
        throw new ReferenceError(msg);
      }
      if (maxAliasCount >= 0) {
        data.count += 1;
        if (data.aliasCount === 0)
          data.aliasCount = getAliasCount(doc2, found, anchors);
        if (data.count * data.aliasCount > maxAliasCount) {
          const msg = "Excessive alias count indicates a resource exhaustion attack";
          throw new ReferenceError(msg);
        }
      }
    }
    return found;
  }
  toJSON(_arg, ctx) {
    if (!ctx)
      return { source: this.source };
    const source = this.resolve(ctx.doc, ctx);
    if (!source) {
      const msg = `Unresolved alias (the anchor must be set before the alias): ${this.source}`;
      throw new ReferenceError(msg);
    }
    return ctx.anchors.get(source).res;
  }
  toString(ctx, _onComment, _onChompKeep) {
    const src = `*${this.source}`;
    if (ctx) {
      anchorIsValid(this.source);
      if (ctx.options.verifyAliasOrder && !ctx.anchors.has(this.source)) {
        const msg = `Unresolved alias (the anchor must be set before the alias): ${this.source}`;
        throw new Error(msg);
      }
      if (ctx.implicitKey)
        return `${src} `;
    }
    return src;
  }
};
function getAliasCount(doc, node2, anchors) {
  if (isAlias(node2)) {
    const source = node2.resolve(doc);
    const anchor = anchors && source && anchors.get(source);
    return anchor ? anchor.count * anchor.aliasCount : 0;
  } else if (isCollection(node2)) {
    let count = 0;
    for (const item of node2.items) {
      const c = getAliasCount(doc, item, anchors);
      if (c > count)
        count = c;
    }
    return count;
  } else if (isPair(node2)) {
    const kc = getAliasCount(doc, node2.key, anchors);
    const vc = getAliasCount(doc, node2.value, anchors);
    return Math.max(kc, vc);
  }
  return 1;
}

// node_modules/yaml/browser/dist/nodes/Scalar.js
var isScalarValue = (value) => !value || typeof value !== "function" && typeof value !== "object";
var Scalar = class extends NodeBase {
  constructor(value) {
    super(SCALAR);
    this.value = value;
  }
  toJSON(arg, ctx) {
    return ctx?.keep ? this.value : toJS(this.value, arg, ctx);
  }
  toString() {
    return String(this.value);
  }
};
Scalar.BLOCK_FOLDED = "BLOCK_FOLDED";
Scalar.BLOCK_LITERAL = "BLOCK_LITERAL";
Scalar.PLAIN = "PLAIN";
Scalar.QUOTE_DOUBLE = "QUOTE_DOUBLE";
Scalar.QUOTE_SINGLE = "QUOTE_SINGLE";

// node_modules/yaml/browser/dist/doc/createNode.js
var defaultTagPrefix = "tag:yaml.org,2002:";
function findTagObject(value, tagName, tags) {
  if (tagName) {
    const match = tags.filter((t) => t.tag === tagName);
    const tagObj = match.find((t) => !t.format) ?? match[0];
    if (!tagObj)
      throw new Error(`Tag ${tagName} not found`);
    return tagObj;
  }
  return tags.find((t) => t.identify?.(value) && !t.format);
}
function createNode(value, tagName, ctx) {
  if (isDocument(value))
    value = value.contents;
  if (isNode(value))
    return value;
  if (isPair(value)) {
    const map2 = ctx.schema[MAP].createNode?.(ctx.schema, null, ctx);
    map2.items.push(value);
    return map2;
  }
  if (value instanceof String || value instanceof Number || value instanceof Boolean || typeof BigInt !== "undefined" && value instanceof BigInt) {
    value = value.valueOf();
  }
  const { aliasDuplicateObjects, onAnchor, onTagObj, schema: schema4, sourceObjects } = ctx;
  let ref = void 0;
  if (aliasDuplicateObjects && value && typeof value === "object") {
    ref = sourceObjects.get(value);
    if (ref) {
      ref.anchor ?? (ref.anchor = onAnchor(value));
      return new Alias(ref.anchor);
    } else {
      ref = { anchor: null, node: null };
      sourceObjects.set(value, ref);
    }
  }
  if (tagName?.startsWith("!!"))
    tagName = defaultTagPrefix + tagName.slice(2);
  let tagObj = findTagObject(value, tagName, schema4.tags);
  if (!tagObj) {
    if (value && typeof value.toJSON === "function") {
      value = value.toJSON();
    }
    if (!value || typeof value !== "object") {
      const node3 = new Scalar(value);
      if (ref)
        ref.node = node3;
      return node3;
    }
    tagObj = value instanceof Map ? schema4[MAP] : Symbol.iterator in Object(value) ? schema4[SEQ] : schema4[MAP];
  }
  if (onTagObj) {
    onTagObj(tagObj);
    delete ctx.onTagObj;
  }
  const node2 = tagObj?.createNode ? tagObj.createNode(ctx.schema, value, ctx) : typeof tagObj?.nodeClass?.from === "function" ? tagObj.nodeClass.from(ctx.schema, value, ctx) : new Scalar(value);
  if (tagName)
    node2.tag = tagName;
  else if (!tagObj.default)
    node2.tag = tagObj.tag;
  if (ref)
    ref.node = node2;
  return node2;
}

// node_modules/yaml/browser/dist/nodes/Collection.js
function collectionFromPath(schema4, path, value) {
  let v = value;
  for (let i = path.length - 1; i >= 0; --i) {
    const k = path[i];
    if (typeof k === "number" && Number.isInteger(k) && k >= 0) {
      const a = [];
      a[k] = v;
      v = a;
    } else {
      v = /* @__PURE__ */ new Map([[k, v]]);
    }
  }
  return createNode(v, void 0, {
    aliasDuplicateObjects: false,
    keepUndefined: false,
    onAnchor: () => {
      throw new Error("This should not happen, please report a bug.");
    },
    schema: schema4,
    sourceObjects: /* @__PURE__ */ new Map()
  });
}
var isEmptyPath = (path) => path == null || typeof path === "object" && !!path[Symbol.iterator]().next().done;
var Collection = class extends NodeBase {
  constructor(type, schema4) {
    super(type);
    Object.defineProperty(this, "schema", {
      value: schema4,
      configurable: true,
      enumerable: false,
      writable: true
    });
  }
  /**
   * Create a copy of this collection.
   *
   * @param schema - If defined, overwrites the original's schema
   */
  clone(schema4) {
    const copy = Object.create(Object.getPrototypeOf(this), Object.getOwnPropertyDescriptors(this));
    if (schema4)
      copy.schema = schema4;
    copy.items = copy.items.map((it) => isNode(it) || isPair(it) ? it.clone(schema4) : it);
    if (this.range)
      copy.range = this.range.slice();
    return copy;
  }
  /**
   * Adds a value to the collection. For `!!map` and `!!omap` the value must
   * be a Pair instance or a `{ key, value }` object, which may not have a key
   * that already exists in the map.
   */
  addIn(path, value) {
    if (isEmptyPath(path))
      this.add(value);
    else {
      const [key, ...rest] = path;
      const node2 = this.get(key, true);
      if (isCollection(node2))
        node2.addIn(rest, value);
      else if (node2 === void 0 && this.schema)
        this.set(key, collectionFromPath(this.schema, rest, value));
      else
        throw new Error(`Expected YAML collection at ${key}. Remaining path: ${rest}`);
    }
  }
  /**
   * Removes a value from the collection.
   * @returns `true` if the item was found and removed.
   */
  deleteIn(path) {
    const [key, ...rest] = path;
    if (rest.length === 0)
      return this.delete(key);
    const node2 = this.get(key, true);
    if (isCollection(node2))
      return node2.deleteIn(rest);
    else
      throw new Error(`Expected YAML collection at ${key}. Remaining path: ${rest}`);
  }
  /**
   * Returns item at `key`, or `undefined` if not found. By default unwraps
   * scalar values from their surrounding node; to disable set `keepScalar` to
   * `true` (collections are always returned intact).
   */
  getIn(path, keepScalar) {
    const [key, ...rest] = path;
    const node2 = this.get(key, true);
    if (rest.length === 0)
      return !keepScalar && isScalar(node2) ? node2.value : node2;
    else
      return isCollection(node2) ? node2.getIn(rest, keepScalar) : void 0;
  }
  hasAllNullValues(allowScalar) {
    return this.items.every((node2) => {
      if (!isPair(node2))
        return false;
      const n = node2.value;
      return n == null || allowScalar && isScalar(n) && n.value == null && !n.commentBefore && !n.comment && !n.tag;
    });
  }
  /**
   * Checks if the collection includes a value with the key `key`.
   */
  hasIn(path) {
    const [key, ...rest] = path;
    if (rest.length === 0)
      return this.has(key);
    const node2 = this.get(key, true);
    return isCollection(node2) ? node2.hasIn(rest) : false;
  }
  /**
   * Sets a value in this collection. For `!!set`, `value` needs to be a
   * boolean to add/remove the item from the set.
   */
  setIn(path, value) {
    const [key, ...rest] = path;
    if (rest.length === 0) {
      this.set(key, value);
    } else {
      const node2 = this.get(key, true);
      if (isCollection(node2))
        node2.setIn(rest, value);
      else if (node2 === void 0 && this.schema)
        this.set(key, collectionFromPath(this.schema, rest, value));
      else
        throw new Error(`Expected YAML collection at ${key}. Remaining path: ${rest}`);
    }
  }
};

// node_modules/yaml/browser/dist/stringify/stringifyComment.js
var stringifyComment = (str) => str.replace(/^(?!$)(?: $)?/gm, "#");
function indentComment(comment, indent) {
  if (/^\n+$/.test(comment))
    return comment.substring(1);
  return indent ? comment.replace(/^(?! *$)/gm, indent) : comment;
}
var lineComment = (str, indent, comment) => str.endsWith("\n") ? indentComment(comment, indent) : comment.includes("\n") ? "\n" + indentComment(comment, indent) : (str.endsWith(" ") ? "" : " ") + comment;

// node_modules/yaml/browser/dist/stringify/foldFlowLines.js
var FOLD_FLOW = "flow";
var FOLD_BLOCK = "block";
var FOLD_QUOTED = "quoted";
function foldFlowLines(text2, indent, mode = "flow", { indentAtStart, lineWidth = 80, minContentWidth = 20, onFold, onOverflow } = {}) {
  if (!lineWidth || lineWidth < 0)
    return text2;
  if (lineWidth < minContentWidth)
    minContentWidth = 0;
  const endStep = Math.max(1 + minContentWidth, 1 + lineWidth - indent.length);
  if (text2.length <= endStep)
    return text2;
  const folds = [];
  const escapedFolds = {};
  let end = lineWidth - indent.length;
  if (typeof indentAtStart === "number") {
    if (indentAtStart > lineWidth - Math.max(2, minContentWidth))
      folds.push(0);
    else
      end = lineWidth - indentAtStart;
  }
  let split = void 0;
  let prev = void 0;
  let overflow = false;
  let i = -1;
  let escStart = -1;
  let escEnd = -1;
  if (mode === FOLD_BLOCK) {
    i = consumeMoreIndentedLines(text2, i, indent.length);
    if (i !== -1)
      end = i + endStep;
  }
  for (let ch; ch = text2[i += 1]; ) {
    if (mode === FOLD_QUOTED && ch === "\\") {
      escStart = i;
      switch (text2[i + 1]) {
        case "x":
          i += 3;
          break;
        case "u":
          i += 5;
          break;
        case "U":
          i += 9;
          break;
        default:
          i += 1;
      }
      escEnd = i;
    }
    if (ch === "\n") {
      if (mode === FOLD_BLOCK)
        i = consumeMoreIndentedLines(text2, i, indent.length);
      end = i + indent.length + endStep;
      split = void 0;
    } else {
      if (ch === " " && prev && prev !== " " && prev !== "\n" && prev !== "	") {
        const next2 = text2[i + 1];
        if (next2 && next2 !== " " && next2 !== "\n" && next2 !== "	")
          split = i;
      }
      if (i >= end) {
        if (split) {
          folds.push(split);
          end = split + endStep;
          split = void 0;
        } else if (mode === FOLD_QUOTED) {
          while (prev === " " || prev === "	") {
            prev = ch;
            ch = text2[i += 1];
            overflow = true;
          }
          const j = i > escEnd + 1 ? i - 2 : escStart - 1;
          if (escapedFolds[j])
            return text2;
          folds.push(j);
          escapedFolds[j] = true;
          end = j + endStep;
          split = void 0;
        } else {
          overflow = true;
        }
      }
    }
    prev = ch;
  }
  if (overflow && onOverflow)
    onOverflow();
  if (folds.length === 0)
    return text2;
  if (onFold)
    onFold();
  let res = text2.slice(0, folds[0]);
  for (let i2 = 0; i2 < folds.length; ++i2) {
    const fold = folds[i2];
    const end2 = folds[i2 + 1] || text2.length;
    if (fold === 0)
      res = `
${indent}${text2.slice(0, end2)}`;
    else {
      if (mode === FOLD_QUOTED && escapedFolds[fold])
        res += `${text2[fold]}\\`;
      res += `
${indent}${text2.slice(fold + 1, end2)}`;
    }
  }
  return res;
}
function consumeMoreIndentedLines(text2, i, indent) {
  let end = i;
  let start = i + 1;
  let ch = text2[start];
  while (ch === " " || ch === "	") {
    if (i < start + indent) {
      ch = text2[++i];
    } else {
      do {
        ch = text2[++i];
      } while (ch && ch !== "\n");
      end = i;
      start = i + 1;
      ch = text2[start];
    }
  }
  return end;
}

// node_modules/yaml/browser/dist/stringify/stringifyString.js
var getFoldOptions = (ctx, isBlock3) => ({
  indentAtStart: isBlock3 ? ctx.indent.length : ctx.indentAtStart,
  lineWidth: ctx.options.lineWidth,
  minContentWidth: ctx.options.minContentWidth
});
var containsDocumentMarker = (str) => /^(%|---|\.\.\.)/m.test(str);
function lineLengthOverLimit(str, lineWidth, indentLength) {
  if (!lineWidth || lineWidth < 0)
    return false;
  const limit = lineWidth - indentLength;
  const strLen = str.length;
  if (strLen <= limit)
    return false;
  for (let i = 0, start = 0; i < strLen; ++i) {
    if (str[i] === "\n") {
      if (i - start > limit)
        return true;
      start = i + 1;
      if (strLen - start <= limit)
        return false;
    }
  }
  return true;
}
function doubleQuotedString(value, ctx) {
  const json = JSON.stringify(value);
  if (ctx.options.doubleQuotedAsJSON)
    return json;
  const { implicitKey } = ctx;
  const minMultiLineLength = ctx.options.doubleQuotedMinMultiLineLength;
  const indent = ctx.indent || (containsDocumentMarker(value) ? "  " : "");
  let str = "";
  let start = 0;
  for (let i = 0, ch = json[i]; ch; ch = json[++i]) {
    if (ch === " " && json[i + 1] === "\\" && json[i + 2] === "n") {
      str += json.slice(start, i) + "\\ ";
      i += 1;
      start = i;
      ch = "\\";
    }
    if (ch === "\\")
      switch (json[i + 1]) {
        case "u":
          {
            str += json.slice(start, i);
            const code = json.substr(i + 2, 4);
            switch (code) {
              case "0000":
                str += "\\0";
                break;
              case "0007":
                str += "\\a";
                break;
              case "000b":
                str += "\\v";
                break;
              case "001b":
                str += "\\e";
                break;
              case "0085":
                str += "\\N";
                break;
              case "00a0":
                str += "\\_";
                break;
              case "2028":
                str += "\\L";
                break;
              case "2029":
                str += "\\P";
                break;
              default:
                if (code.substr(0, 2) === "00")
                  str += "\\x" + code.substr(2);
                else
                  str += json.substr(i, 6);
            }
            i += 5;
            start = i + 1;
          }
          break;
        case "n":
          if (implicitKey || json[i + 2] === '"' || json.length < minMultiLineLength) {
            i += 1;
          } else {
            str += json.slice(start, i) + "\n\n";
            while (json[i + 2] === "\\" && json[i + 3] === "n" && json[i + 4] !== '"') {
              str += "\n";
              i += 2;
            }
            str += indent;
            if (json[i + 2] === " ")
              str += "\\";
            i += 1;
            start = i + 1;
          }
          break;
        default:
          i += 1;
      }
  }
  str = start ? str + json.slice(start) : json;
  return implicitKey ? str : foldFlowLines(str, indent, FOLD_QUOTED, getFoldOptions(ctx, false));
}
function singleQuotedString(value, ctx) {
  if (ctx.options.singleQuote === false || ctx.implicitKey && value.includes("\n") || /[ \t]\n|\n[ \t]/.test(value))
    return doubleQuotedString(value, ctx);
  const indent = ctx.indent || (containsDocumentMarker(value) ? "  " : "");
  const res = "'" + value.replace(/'/g, "''").replace(/\n+/g, `$&
${indent}`) + "'";
  return ctx.implicitKey ? res : foldFlowLines(res, indent, FOLD_FLOW, getFoldOptions(ctx, false));
}
function quotedString(value, ctx) {
  const { singleQuote } = ctx.options;
  let qs;
  if (singleQuote === false)
    qs = doubleQuotedString;
  else {
    const hasDouble = value.includes('"');
    const hasSingle = value.includes("'");
    if (hasDouble && !hasSingle)
      qs = singleQuotedString;
    else if (hasSingle && !hasDouble)
      qs = doubleQuotedString;
    else
      qs = singleQuote ? singleQuotedString : doubleQuotedString;
  }
  return qs(value, ctx);
}
var blockEndNewlines;
try {
  blockEndNewlines = new RegExp("(^|(?<!\n))\n+(?!\n|$)", "g");
} catch {
  blockEndNewlines = /\n+(?!\n|$)/g;
}
function blockString({ comment, type, value }, ctx, onComment, onChompKeep) {
  const { blockQuote, commentString, lineWidth } = ctx.options;
  if (!blockQuote || /\n[\t ]+$/.test(value)) {
    return quotedString(value, ctx);
  }
  const indent = ctx.indent || (ctx.forceBlockIndent || containsDocumentMarker(value) ? "  " : "");
  const literal = blockQuote === "literal" ? true : blockQuote === "folded" || type === Scalar.BLOCK_FOLDED ? false : type === Scalar.BLOCK_LITERAL ? true : !lineLengthOverLimit(value, lineWidth, indent.length);
  if (!value)
    return literal ? "|\n" : ">\n";
  let chomp;
  let endStart;
  for (endStart = value.length; endStart > 0; --endStart) {
    const ch = value[endStart - 1];
    if (ch !== "\n" && ch !== "	" && ch !== " ")
      break;
  }
  let end = value.substring(endStart);
  const endNlPos = end.indexOf("\n");
  if (endNlPos === -1) {
    chomp = "-";
  } else if (value === end || endNlPos !== end.length - 1) {
    chomp = "+";
    if (onChompKeep)
      onChompKeep();
  } else {
    chomp = "";
  }
  if (end) {
    value = value.slice(0, -end.length);
    if (end[end.length - 1] === "\n")
      end = end.slice(0, -1);
    end = end.replace(blockEndNewlines, `$&${indent}`);
  }
  let startWithSpace = false;
  let startEnd;
  let startNlPos = -1;
  for (startEnd = 0; startEnd < value.length; ++startEnd) {
    const ch = value[startEnd];
    if (ch === " ")
      startWithSpace = true;
    else if (ch === "\n")
      startNlPos = startEnd;
    else
      break;
  }
  let start = value.substring(0, startNlPos < startEnd ? startNlPos + 1 : startEnd);
  if (start) {
    value = value.substring(start.length);
    start = start.replace(/\n+/g, `$&${indent}`);
  }
  const indentSize = indent ? "2" : "1";
  let header = (startWithSpace ? indentSize : "") + chomp;
  if (comment) {
    header += " " + commentString(comment.replace(/ ?[\r\n]+/g, " "));
    if (onComment)
      onComment();
  }
  if (!literal) {
    const foldedValue = value.replace(/\n+/g, "\n$&").replace(/(?:^|\n)([\t ].*)(?:([\n\t ]*)\n(?![\n\t ]))?/g, "$1$2").replace(/\n+/g, `$&${indent}`);
    let literalFallback = false;
    const foldOptions = getFoldOptions(ctx, true);
    if (blockQuote !== "folded" && type !== Scalar.BLOCK_FOLDED) {
      foldOptions.onOverflow = () => {
        literalFallback = true;
      };
    }
    const body = foldFlowLines(`${start}${foldedValue}${end}`, indent, FOLD_BLOCK, foldOptions);
    if (!literalFallback)
      return `>${header}
${indent}${body}`;
  }
  value = value.replace(/\n+/g, `$&${indent}`);
  return `|${header}
${indent}${start}${value}${end}`;
}
function plainString(item, ctx, onComment, onChompKeep) {
  const { type, value } = item;
  const { actualString, implicitKey, indent, indentStep, inFlow } = ctx;
  if (implicitKey && value.includes("\n") || inFlow && /[[\]{},]/.test(value)) {
    return quotedString(value, ctx);
  }
  if (/^[\n\t ,[\]{}#&*!|>'"%@`]|^[?-]$|^[?-][ \t]|[\n:][ \t]|[ \t]\n|[\n\t ]#|[\n\t :]$/.test(value)) {
    return implicitKey || inFlow || !value.includes("\n") ? quotedString(value, ctx) : blockString(item, ctx, onComment, onChompKeep);
  }
  if (!implicitKey && !inFlow && type !== Scalar.PLAIN && value.includes("\n")) {
    return blockString(item, ctx, onComment, onChompKeep);
  }
  if (containsDocumentMarker(value)) {
    if (indent === "") {
      ctx.forceBlockIndent = true;
      return blockString(item, ctx, onComment, onChompKeep);
    } else if (implicitKey && indent === indentStep) {
      return quotedString(value, ctx);
    }
  }
  const str = value.replace(/\n+/g, `$&
${indent}`);
  if (actualString) {
    const test = (tag) => tag.default && tag.tag !== "tag:yaml.org,2002:str" && tag.test?.test(str);
    const { compat, tags } = ctx.doc.schema;
    if (tags.some(test) || compat?.some(test))
      return quotedString(value, ctx);
  }
  return implicitKey ? str : foldFlowLines(str, indent, FOLD_FLOW, getFoldOptions(ctx, false));
}
function stringifyString(item, ctx, onComment, onChompKeep) {
  const { implicitKey, inFlow } = ctx;
  const ss = typeof item.value === "string" ? item : Object.assign({}, item, { value: String(item.value) });
  let { type } = item;
  if (type !== Scalar.QUOTE_DOUBLE) {
    if (/[\x00-\x08\x0b-\x1f\x7f-\x9f\u{D800}-\u{DFFF}]/u.test(ss.value))
      type = Scalar.QUOTE_DOUBLE;
  }
  const _stringify = (_type) => {
    switch (_type) {
      case Scalar.BLOCK_FOLDED:
      case Scalar.BLOCK_LITERAL:
        return implicitKey || inFlow ? quotedString(ss.value, ctx) : blockString(ss, ctx, onComment, onChompKeep);
      case Scalar.QUOTE_DOUBLE:
        return doubleQuotedString(ss.value, ctx);
      case Scalar.QUOTE_SINGLE:
        return singleQuotedString(ss.value, ctx);
      case Scalar.PLAIN:
        return plainString(ss, ctx, onComment, onChompKeep);
      default:
        return null;
    }
  };
  let res = _stringify(type);
  if (res === null) {
    const { defaultKeyType, defaultStringType } = ctx.options;
    const t = implicitKey && defaultKeyType || defaultStringType;
    res = _stringify(t);
    if (res === null)
      throw new Error(`Unsupported default string type ${t}`);
  }
  return res;
}

// node_modules/yaml/browser/dist/stringify/stringify.js
function createStringifyContext(doc, options) {
  const opt = Object.assign({
    blockQuote: true,
    commentString: stringifyComment,
    defaultKeyType: null,
    defaultStringType: "PLAIN",
    directives: null,
    doubleQuotedAsJSON: false,
    doubleQuotedMinMultiLineLength: 40,
    falseStr: "false",
    flowCollectionPadding: true,
    indentSeq: true,
    lineWidth: 80,
    minContentWidth: 20,
    nullStr: "null",
    simpleKeys: false,
    singleQuote: null,
    trailingComma: false,
    trueStr: "true",
    verifyAliasOrder: true
  }, doc.schema.toStringOptions, options);
  let inFlow;
  switch (opt.collectionStyle) {
    case "block":
      inFlow = false;
      break;
    case "flow":
      inFlow = true;
      break;
    default:
      inFlow = null;
  }
  return {
    anchors: /* @__PURE__ */ new Set(),
    doc,
    flowCollectionPadding: opt.flowCollectionPadding ? " " : "",
    indent: "",
    indentStep: typeof opt.indent === "number" ? " ".repeat(opt.indent) : "  ",
    inFlow,
    options: opt
  };
}
function getTagObject(tags, item) {
  if (item.tag) {
    const match = tags.filter((t) => t.tag === item.tag);
    if (match.length > 0)
      return match.find((t) => t.format === item.format) ?? match[0];
  }
  let tagObj = void 0;
  let obj;
  if (isScalar(item)) {
    obj = item.value;
    let match = tags.filter((t) => t.identify?.(obj));
    if (match.length > 1) {
      const testMatch = match.filter((t) => t.test);
      if (testMatch.length > 0)
        match = testMatch;
    }
    tagObj = match.find((t) => t.format === item.format) ?? match.find((t) => !t.format);
  } else {
    obj = item;
    tagObj = tags.find((t) => t.nodeClass && obj instanceof t.nodeClass);
  }
  if (!tagObj) {
    const name2 = obj?.constructor?.name ?? (obj === null ? "null" : typeof obj);
    throw new Error(`Tag not resolved for ${name2} value`);
  }
  return tagObj;
}
function stringifyProps(node2, tagObj, { anchors, doc }) {
  if (!doc.directives)
    return "";
  const props = [];
  const anchor = (isScalar(node2) || isCollection(node2)) && node2.anchor;
  if (anchor && anchorIsValid(anchor)) {
    anchors.add(anchor);
    props.push(`&${anchor}`);
  }
  const tag = node2.tag ?? (tagObj.default ? null : tagObj.tag);
  if (tag)
    props.push(doc.directives.tagString(tag));
  return props.join(" ");
}
function stringify(item, ctx, onComment, onChompKeep) {
  if (isPair(item))
    return item.toString(ctx, onComment, onChompKeep);
  if (isAlias(item)) {
    if (ctx.doc.directives)
      return item.toString(ctx);
    if (ctx.resolvedAliases?.has(item)) {
      throw new TypeError(`Cannot stringify circular structure without alias nodes`);
    } else {
      if (ctx.resolvedAliases)
        ctx.resolvedAliases.add(item);
      else
        ctx.resolvedAliases = /* @__PURE__ */ new Set([item]);
      item = item.resolve(ctx.doc);
    }
  }
  let tagObj = void 0;
  const node2 = isNode(item) ? item : ctx.doc.createNode(item, { onTagObj: (o) => tagObj = o });
  tagObj ?? (tagObj = getTagObject(ctx.doc.schema.tags, node2));
  const props = stringifyProps(node2, tagObj, ctx);
  if (props.length > 0)
    ctx.indentAtStart = (ctx.indentAtStart ?? 0) + props.length + 1;
  const str = typeof tagObj.stringify === "function" ? tagObj.stringify(node2, ctx, onComment, onChompKeep) : isScalar(node2) ? stringifyString(node2, ctx, onComment, onChompKeep) : node2.toString(ctx, onComment, onChompKeep);
  if (!props)
    return str;
  return isScalar(node2) || str[0] === "{" || str[0] === "[" ? `${props} ${str}` : `${props}
${ctx.indent}${str}`;
}

// node_modules/yaml/browser/dist/stringify/stringifyPair.js
function stringifyPair({ key, value }, ctx, onComment, onChompKeep) {
  const { allNullValues, doc, indent, indentStep, options: { commentString, indentSeq, simpleKeys } } = ctx;
  let keyComment = isNode(key) && key.comment || null;
  if (simpleKeys) {
    if (keyComment) {
      throw new Error("With simple keys, key nodes cannot have comments");
    }
    if (isCollection(key) || !isNode(key) && typeof key === "object") {
      const msg = "With simple keys, collection cannot be used as a key value";
      throw new Error(msg);
    }
  }
  let explicitKey = !simpleKeys && (!key || keyComment && value == null && !ctx.inFlow || isCollection(key) || (isScalar(key) ? key.type === Scalar.BLOCK_FOLDED || key.type === Scalar.BLOCK_LITERAL : typeof key === "object"));
  ctx = Object.assign({}, ctx, {
    allNullValues: false,
    implicitKey: !explicitKey && (simpleKeys || !allNullValues),
    indent: indent + indentStep
  });
  let keyCommentDone = false;
  let chompKeep = false;
  let str = stringify(key, ctx, () => keyCommentDone = true, () => chompKeep = true);
  if (!explicitKey && !ctx.inFlow && str.length > 1024) {
    if (simpleKeys)
      throw new Error("With simple keys, single line scalar must not span more than 1024 characters");
    explicitKey = true;
  }
  if (ctx.inFlow) {
    if (allNullValues || value == null) {
      if (keyCommentDone && onComment)
        onComment();
      return str === "" ? "?" : explicitKey ? `? ${str}` : str;
    }
  } else if (allNullValues && !simpleKeys || value == null && explicitKey) {
    str = `? ${str}`;
    if (keyComment && !keyCommentDone) {
      str += lineComment(str, ctx.indent, commentString(keyComment));
    } else if (chompKeep && onChompKeep)
      onChompKeep();
    return str;
  }
  if (keyCommentDone)
    keyComment = null;
  if (explicitKey) {
    if (keyComment)
      str += lineComment(str, ctx.indent, commentString(keyComment));
    str = `? ${str}
${indent}:`;
  } else {
    str = `${str}:`;
    if (keyComment)
      str += lineComment(str, ctx.indent, commentString(keyComment));
  }
  let vsb, vcb, valueComment;
  if (isNode(value)) {
    vsb = !!value.spaceBefore;
    vcb = value.commentBefore;
    valueComment = value.comment;
  } else {
    vsb = false;
    vcb = null;
    valueComment = null;
    if (value && typeof value === "object")
      value = doc.createNode(value);
  }
  ctx.implicitKey = false;
  if (!explicitKey && !keyComment && isScalar(value))
    ctx.indentAtStart = str.length + 1;
  chompKeep = false;
  if (!indentSeq && indentStep.length >= 2 && !ctx.inFlow && !explicitKey && isSeq(value) && !value.flow && !value.tag && !value.anchor) {
    ctx.indent = ctx.indent.substring(2);
  }
  let valueCommentDone = false;
  const valueStr = stringify(value, ctx, () => valueCommentDone = true, () => chompKeep = true);
  let ws = " ";
  if (keyComment || vsb || vcb) {
    ws = vsb ? "\n" : "";
    if (vcb) {
      const cs = commentString(vcb);
      ws += `
${indentComment(cs, ctx.indent)}`;
    }
    if (valueStr === "" && !ctx.inFlow) {
      if (ws === "\n" && valueComment)
        ws = "\n\n";
    } else {
      ws += `
${ctx.indent}`;
    }
  } else if (!explicitKey && isCollection(value)) {
    const vs0 = valueStr[0];
    const nl0 = valueStr.indexOf("\n");
    const hasNewline = nl0 !== -1;
    const flow = ctx.inFlow ?? value.flow ?? value.items.length === 0;
    if (hasNewline || !flow) {
      let hasPropsLine = false;
      if (hasNewline && (vs0 === "&" || vs0 === "!")) {
        let sp0 = valueStr.indexOf(" ");
        if (vs0 === "&" && sp0 !== -1 && sp0 < nl0 && valueStr[sp0 + 1] === "!") {
          sp0 = valueStr.indexOf(" ", sp0 + 1);
        }
        if (sp0 === -1 || nl0 < sp0)
          hasPropsLine = true;
      }
      if (!hasPropsLine)
        ws = `
${ctx.indent}`;
    }
  } else if (valueStr === "" || valueStr[0] === "\n") {
    ws = "";
  }
  str += ws + valueStr;
  if (ctx.inFlow) {
    if (valueCommentDone && onComment)
      onComment();
  } else if (valueComment && !valueCommentDone) {
    str += lineComment(str, ctx.indent, commentString(valueComment));
  } else if (chompKeep && onChompKeep) {
    onChompKeep();
  }
  return str;
}

// node_modules/yaml/browser/dist/log.js
function warn(logLevel, warning) {
  if (logLevel === "debug" || logLevel === "warn") {
    console.warn(warning);
  }
}

// node_modules/yaml/browser/dist/schema/yaml-1.1/merge.js
var MERGE_KEY = "<<";
var merge = {
  identify: (value) => value === MERGE_KEY || typeof value === "symbol" && value.description === MERGE_KEY,
  default: "key",
  tag: "tag:yaml.org,2002:merge",
  test: /^<<$/,
  resolve: () => Object.assign(new Scalar(Symbol(MERGE_KEY)), {
    addToJSMap: addMergeToJSMap
  }),
  stringify: () => MERGE_KEY
};
var isMergeKey = (ctx, key) => (merge.identify(key) || isScalar(key) && (!key.type || key.type === Scalar.PLAIN) && merge.identify(key.value)) && ctx?.doc.schema.tags.some((tag) => tag.tag === merge.tag && tag.default);
function addMergeToJSMap(ctx, map2, value) {
  const source = resolveAliasValue(ctx, value);
  if (isSeq(source))
    for (const it of source.items)
      mergeValue(ctx, map2, it);
  else if (Array.isArray(source))
    for (const it of source)
      mergeValue(ctx, map2, it);
  else
    mergeValue(ctx, map2, source);
}
function mergeValue(ctx, map2, value) {
  const source = resolveAliasValue(ctx, value);
  if (!isMap(source))
    throw new Error("Merge sources must be maps or map aliases");
  const srcMap = source.toJSON(null, ctx, Map);
  for (const [key, value2] of srcMap) {
    if (map2 instanceof Map) {
      if (!map2.has(key))
        map2.set(key, value2);
    } else if (map2 instanceof Set) {
      map2.add(key);
    } else if (!Object.prototype.hasOwnProperty.call(map2, key)) {
      Object.defineProperty(map2, key, {
        value: value2,
        writable: true,
        enumerable: true,
        configurable: true
      });
    }
  }
  return map2;
}
function resolveAliasValue(ctx, value) {
  return ctx && isAlias(value) ? value.resolve(ctx.doc, ctx) : value;
}

// node_modules/yaml/browser/dist/nodes/addPairToJSMap.js
function addPairToJSMap(ctx, map2, { key, value }) {
  if (isNode(key) && key.addToJSMap)
    key.addToJSMap(ctx, map2, value);
  else if (isMergeKey(ctx, key))
    addMergeToJSMap(ctx, map2, value);
  else {
    const jsKey = toJS(key, "", ctx);
    if (map2 instanceof Map) {
      map2.set(jsKey, toJS(value, jsKey, ctx));
    } else if (map2 instanceof Set) {
      map2.add(jsKey);
    } else {
      const stringKey = stringifyKey(key, jsKey, ctx);
      const jsValue = toJS(value, stringKey, ctx);
      if (stringKey in map2)
        Object.defineProperty(map2, stringKey, {
          value: jsValue,
          writable: true,
          enumerable: true,
          configurable: true
        });
      else
        map2[stringKey] = jsValue;
    }
  }
  return map2;
}
function stringifyKey(key, jsKey, ctx) {
  if (jsKey === null)
    return "";
  if (typeof jsKey !== "object")
    return String(jsKey);
  if (isNode(key) && ctx?.doc) {
    const strCtx = createStringifyContext(ctx.doc, {});
    strCtx.anchors = /* @__PURE__ */ new Set();
    for (const node2 of ctx.anchors.keys())
      strCtx.anchors.add(node2.anchor);
    strCtx.inFlow = true;
    strCtx.inStringifyKey = true;
    const strKey = key.toString(strCtx);
    if (!ctx.mapKeyWarned) {
      let jsonStr = JSON.stringify(strKey);
      if (jsonStr.length > 40)
        jsonStr = jsonStr.substring(0, 36) + '..."';
      warn(ctx.doc.options.logLevel, `Keys with collection values will be stringified due to JS Object restrictions: ${jsonStr}. Set mapAsMap: true to use object keys.`);
      ctx.mapKeyWarned = true;
    }
    return strKey;
  }
  return JSON.stringify(jsKey);
}

// node_modules/yaml/browser/dist/nodes/Pair.js
function createPair(key, value, ctx) {
  const k = createNode(key, void 0, ctx);
  const v = createNode(value, void 0, ctx);
  return new Pair(k, v);
}
var Pair = class _Pair {
  constructor(key, value = null) {
    Object.defineProperty(this, NODE_TYPE, { value: PAIR });
    this.key = key;
    this.value = value;
  }
  clone(schema4) {
    let { key, value } = this;
    if (isNode(key))
      key = key.clone(schema4);
    if (isNode(value))
      value = value.clone(schema4);
    return new _Pair(key, value);
  }
  toJSON(_, ctx) {
    const pair = ctx?.mapAsMap ? /* @__PURE__ */ new Map() : {};
    return addPairToJSMap(ctx, pair, this);
  }
  toString(ctx, onComment, onChompKeep) {
    return ctx?.doc ? stringifyPair(this, ctx, onComment, onChompKeep) : JSON.stringify(this);
  }
};

// node_modules/yaml/browser/dist/stringify/stringifyCollection.js
function stringifyCollection(collection, ctx, options) {
  const flow = ctx.inFlow ?? collection.flow;
  const stringify4 = flow ? stringifyFlowCollection : stringifyBlockCollection;
  return stringify4(collection, ctx, options);
}
function stringifyBlockCollection({ comment, items }, ctx, { blockItemPrefix, flowChars, itemIndent, onChompKeep, onComment }) {
  const { indent, options: { commentString } } = ctx;
  const itemCtx = Object.assign({}, ctx, { indent: itemIndent, type: null });
  let chompKeep = false;
  const lines = [];
  for (let i = 0; i < items.length; ++i) {
    const item = items[i];
    let comment2 = null;
    if (isNode(item)) {
      if (!chompKeep && item.spaceBefore)
        lines.push("");
      addCommentBefore(ctx, lines, item.commentBefore, chompKeep);
      if (item.comment)
        comment2 = item.comment;
    } else if (isPair(item)) {
      const ik = isNode(item.key) ? item.key : null;
      if (ik) {
        if (!chompKeep && ik.spaceBefore)
          lines.push("");
        addCommentBefore(ctx, lines, ik.commentBefore, chompKeep);
      }
    }
    chompKeep = false;
    let str2 = stringify(item, itemCtx, () => comment2 = null, () => chompKeep = true);
    if (comment2)
      str2 += lineComment(str2, itemIndent, commentString(comment2));
    if (chompKeep && comment2)
      chompKeep = false;
    lines.push(blockItemPrefix + str2);
  }
  let str;
  if (lines.length === 0) {
    str = flowChars.start + flowChars.end;
  } else {
    str = lines[0];
    for (let i = 1; i < lines.length; ++i) {
      const line = lines[i];
      str += line ? `
${indent}${line}` : "\n";
    }
  }
  if (comment) {
    str += "\n" + indentComment(commentString(comment), indent);
    if (onComment)
      onComment();
  } else if (chompKeep && onChompKeep)
    onChompKeep();
  return str;
}
function stringifyFlowCollection({ items }, ctx, { flowChars, itemIndent }) {
  const { indent, indentStep, flowCollectionPadding: fcPadding, options: { commentString } } = ctx;
  itemIndent += indentStep;
  const itemCtx = Object.assign({}, ctx, {
    indent: itemIndent,
    inFlow: true,
    type: null
  });
  let reqNewline = false;
  let linesAtValue = 0;
  const lines = [];
  for (let i = 0; i < items.length; ++i) {
    const item = items[i];
    let comment = null;
    if (isNode(item)) {
      if (item.spaceBefore)
        lines.push("");
      addCommentBefore(ctx, lines, item.commentBefore, false);
      if (item.comment)
        comment = item.comment;
    } else if (isPair(item)) {
      const ik = isNode(item.key) ? item.key : null;
      if (ik) {
        if (ik.spaceBefore)
          lines.push("");
        addCommentBefore(ctx, lines, ik.commentBefore, false);
        if (ik.comment)
          reqNewline = true;
      }
      const iv = isNode(item.value) ? item.value : null;
      if (iv) {
        if (iv.comment)
          comment = iv.comment;
        if (iv.commentBefore)
          reqNewline = true;
      } else if (item.value == null && ik?.comment) {
        comment = ik.comment;
      }
    }
    if (comment)
      reqNewline = true;
    let str = stringify(item, itemCtx, () => comment = null);
    reqNewline || (reqNewline = lines.length > linesAtValue || str.includes("\n"));
    if (i < items.length - 1) {
      str += ",";
    } else if (ctx.options.trailingComma) {
      if (ctx.options.lineWidth > 0) {
        reqNewline || (reqNewline = lines.reduce((sum, line) => sum + line.length + 2, 2) + (str.length + 2) > ctx.options.lineWidth);
      }
      if (reqNewline) {
        str += ",";
      }
    }
    if (comment)
      str += lineComment(str, itemIndent, commentString(comment));
    lines.push(str);
    linesAtValue = lines.length;
  }
  const { start, end } = flowChars;
  if (lines.length === 0) {
    return start + end;
  } else {
    if (!reqNewline) {
      const len = lines.reduce((sum, line) => sum + line.length + 2, 2);
      reqNewline = ctx.options.lineWidth > 0 && len > ctx.options.lineWidth;
    }
    if (reqNewline) {
      let str = start;
      for (const line of lines)
        str += line ? `
${indentStep}${indent}${line}` : "\n";
      return `${str}
${indent}${end}`;
    } else {
      return `${start}${fcPadding}${lines.join(" ")}${fcPadding}${end}`;
    }
  }
}
function addCommentBefore({ indent, options: { commentString } }, lines, comment, chompKeep) {
  if (comment && chompKeep)
    comment = comment.replace(/^\n+/, "");
  if (comment) {
    const ic = indentComment(commentString(comment), indent);
    lines.push(ic.trimStart());
  }
}

// node_modules/yaml/browser/dist/nodes/YAMLMap.js
function findPair(items, key) {
  const k = isScalar(key) ? key.value : key;
  for (const it of items) {
    if (isPair(it)) {
      if (it.key === key || it.key === k)
        return it;
      if (isScalar(it.key) && it.key.value === k)
        return it;
    }
  }
  return void 0;
}
var YAMLMap = class extends Collection {
  static get tagName() {
    return "tag:yaml.org,2002:map";
  }
  constructor(schema4) {
    super(MAP, schema4);
    this.items = [];
  }
  /**
   * A generic collection parsing method that can be extended
   * to other node classes that inherit from YAMLMap
   */
  static from(schema4, obj, ctx) {
    const { keepUndefined, replacer } = ctx;
    const map2 = new this(schema4);
    const add = (key, value) => {
      if (typeof replacer === "function")
        value = replacer.call(obj, key, value);
      else if (Array.isArray(replacer) && !replacer.includes(key))
        return;
      if (value !== void 0 || keepUndefined)
        map2.items.push(createPair(key, value, ctx));
    };
    if (obj instanceof Map) {
      for (const [key, value] of obj)
        add(key, value);
    } else if (obj && typeof obj === "object") {
      for (const key of Object.keys(obj))
        add(key, obj[key]);
    }
    if (typeof schema4.sortMapEntries === "function") {
      map2.items.sort(schema4.sortMapEntries);
    }
    return map2;
  }
  /**
   * Adds a value to the collection.
   *
   * @param overwrite - If not set `true`, using a key that is already in the
   *   collection will throw. Otherwise, overwrites the previous value.
   */
  add(pair, overwrite) {
    let _pair;
    if (isPair(pair))
      _pair = pair;
    else if (!pair || typeof pair !== "object" || !("key" in pair)) {
      _pair = new Pair(pair, pair?.value);
    } else
      _pair = new Pair(pair.key, pair.value);
    const prev = findPair(this.items, _pair.key);
    const sortEntries = this.schema?.sortMapEntries;
    if (prev) {
      if (!overwrite)
        throw new Error(`Key ${_pair.key} already set`);
      if (isScalar(prev.value) && isScalarValue(_pair.value))
        prev.value.value = _pair.value;
      else
        prev.value = _pair.value;
    } else if (sortEntries) {
      const i = this.items.findIndex((item) => sortEntries(_pair, item) < 0);
      if (i === -1)
        this.items.push(_pair);
      else
        this.items.splice(i, 0, _pair);
    } else {
      this.items.push(_pair);
    }
  }
  delete(key) {
    const it = findPair(this.items, key);
    if (!it)
      return false;
    const del = this.items.splice(this.items.indexOf(it), 1);
    return del.length > 0;
  }
  get(key, keepScalar) {
    const it = findPair(this.items, key);
    const node2 = it?.value;
    return (!keepScalar && isScalar(node2) ? node2.value : node2) ?? void 0;
  }
  has(key) {
    return !!findPair(this.items, key);
  }
  set(key, value) {
    this.add(new Pair(key, value), true);
  }
  /**
   * @param ctx - Conversion context, originally set in Document#toJS()
   * @param {Class} Type - If set, forces the returned collection type
   * @returns Instance of Type, Map, or Object
   */
  toJSON(_, ctx, Type) {
    const map2 = Type ? new Type() : ctx?.mapAsMap ? /* @__PURE__ */ new Map() : {};
    if (ctx?.onCreate)
      ctx.onCreate(map2);
    for (const item of this.items)
      addPairToJSMap(ctx, map2, item);
    return map2;
  }
  toString(ctx, onComment, onChompKeep) {
    if (!ctx)
      return JSON.stringify(this);
    for (const item of this.items) {
      if (!isPair(item))
        throw new Error(`Map items must all be pairs; found ${JSON.stringify(item)} instead`);
    }
    if (!ctx.allNullValues && this.hasAllNullValues(false))
      ctx = Object.assign({}, ctx, { allNullValues: true });
    return stringifyCollection(this, ctx, {
      blockItemPrefix: "",
      flowChars: { start: "{", end: "}" },
      itemIndent: ctx.indent || "",
      onChompKeep,
      onComment
    });
  }
};

// node_modules/yaml/browser/dist/schema/common/map.js
var map = {
  collection: "map",
  default: true,
  nodeClass: YAMLMap,
  tag: "tag:yaml.org,2002:map",
  resolve(map2, onError) {
    if (!isMap(map2))
      onError("Expected a mapping for this tag");
    return map2;
  },
  createNode: (schema4, obj, ctx) => YAMLMap.from(schema4, obj, ctx)
};

// node_modules/yaml/browser/dist/nodes/YAMLSeq.js
var YAMLSeq = class extends Collection {
  static get tagName() {
    return "tag:yaml.org,2002:seq";
  }
  constructor(schema4) {
    super(SEQ, schema4);
    this.items = [];
  }
  add(value) {
    this.items.push(value);
  }
  /**
   * Removes a value from the collection.
   *
   * `key` must contain a representation of an integer for this to succeed.
   * It may be wrapped in a `Scalar`.
   *
   * @returns `true` if the item was found and removed.
   */
  delete(key) {
    const idx = asItemIndex(key);
    if (typeof idx !== "number")
      return false;
    const del = this.items.splice(idx, 1);
    return del.length > 0;
  }
  get(key, keepScalar) {
    const idx = asItemIndex(key);
    if (typeof idx !== "number")
      return void 0;
    const it = this.items[idx];
    return !keepScalar && isScalar(it) ? it.value : it;
  }
  /**
   * Checks if the collection includes a value with the key `key`.
   *
   * `key` must contain a representation of an integer for this to succeed.
   * It may be wrapped in a `Scalar`.
   */
  has(key) {
    const idx = asItemIndex(key);
    return typeof idx === "number" && idx < this.items.length;
  }
  /**
   * Sets a value in this collection. For `!!set`, `value` needs to be a
   * boolean to add/remove the item from the set.
   *
   * If `key` does not contain a representation of an integer, this will throw.
   * It may be wrapped in a `Scalar`.
   */
  set(key, value) {
    const idx = asItemIndex(key);
    if (typeof idx !== "number")
      throw new Error(`Expected a valid index, not ${key}.`);
    const prev = this.items[idx];
    if (isScalar(prev) && isScalarValue(value))
      prev.value = value;
    else
      this.items[idx] = value;
  }
  toJSON(_, ctx) {
    const seq2 = [];
    if (ctx?.onCreate)
      ctx.onCreate(seq2);
    let i = 0;
    for (const item of this.items)
      seq2.push(toJS(item, String(i++), ctx));
    return seq2;
  }
  toString(ctx, onComment, onChompKeep) {
    if (!ctx)
      return JSON.stringify(this);
    return stringifyCollection(this, ctx, {
      blockItemPrefix: "- ",
      flowChars: { start: "[", end: "]" },
      itemIndent: (ctx.indent || "") + "  ",
      onChompKeep,
      onComment
    });
  }
  static from(schema4, obj, ctx) {
    const { replacer } = ctx;
    const seq2 = new this(schema4);
    if (obj && Symbol.iterator in Object(obj)) {
      let i = 0;
      for (let it of obj) {
        if (typeof replacer === "function") {
          const key = obj instanceof Set ? it : String(i++);
          it = replacer.call(obj, key, it);
        }
        seq2.items.push(createNode(it, void 0, ctx));
      }
    }
    return seq2;
  }
};
function asItemIndex(key) {
  let idx = isScalar(key) ? key.value : key;
  if (idx && typeof idx === "string")
    idx = Number(idx);
  return typeof idx === "number" && Number.isInteger(idx) && idx >= 0 ? idx : null;
}

// node_modules/yaml/browser/dist/schema/common/seq.js
var seq = {
  collection: "seq",
  default: true,
  nodeClass: YAMLSeq,
  tag: "tag:yaml.org,2002:seq",
  resolve(seq2, onError) {
    if (!isSeq(seq2))
      onError("Expected a sequence for this tag");
    return seq2;
  },
  createNode: (schema4, obj, ctx) => YAMLSeq.from(schema4, obj, ctx)
};

// node_modules/yaml/browser/dist/schema/common/string.js
var string = {
  identify: (value) => typeof value === "string",
  default: true,
  tag: "tag:yaml.org,2002:str",
  resolve: (str) => str,
  stringify(item, ctx, onComment, onChompKeep) {
    ctx = Object.assign({ actualString: true }, ctx);
    return stringifyString(item, ctx, onComment, onChompKeep);
  }
};

// node_modules/yaml/browser/dist/schema/common/null.js
var nullTag = {
  identify: (value) => value == null,
  createNode: () => new Scalar(null),
  default: true,
  tag: "tag:yaml.org,2002:null",
  test: /^(?:~|[Nn]ull|NULL)?$/,
  resolve: () => new Scalar(null),
  stringify: ({ source }, ctx) => typeof source === "string" && nullTag.test.test(source) ? source : ctx.options.nullStr
};

// node_modules/yaml/browser/dist/schema/core/bool.js
var boolTag = {
  identify: (value) => typeof value === "boolean",
  default: true,
  tag: "tag:yaml.org,2002:bool",
  test: /^(?:[Tt]rue|TRUE|[Ff]alse|FALSE)$/,
  resolve: (str) => new Scalar(str[0] === "t" || str[0] === "T"),
  stringify({ source, value }, ctx) {
    if (source && boolTag.test.test(source)) {
      const sv = source[0] === "t" || source[0] === "T";
      if (value === sv)
        return source;
    }
    return value ? ctx.options.trueStr : ctx.options.falseStr;
  }
};

// node_modules/yaml/browser/dist/stringify/stringifyNumber.js
function stringifyNumber({ format, minFractionDigits, tag, value }) {
  if (typeof value === "bigint")
    return String(value);
  const num = typeof value === "number" ? value : Number(value);
  if (!isFinite(num))
    return isNaN(num) ? ".nan" : num < 0 ? "-.inf" : ".inf";
  let n = Object.is(value, -0) ? "-0" : JSON.stringify(value);
  if (!format && minFractionDigits && (!tag || tag === "tag:yaml.org,2002:float") && /^-?\d/.test(n) && !n.includes("e")) {
    let i = n.indexOf(".");
    if (i < 0) {
      i = n.length;
      n += ".";
    }
    let d = minFractionDigits - (n.length - i - 1);
    while (d-- > 0)
      n += "0";
  }
  return n;
}

// node_modules/yaml/browser/dist/schema/core/float.js
var floatNaN = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  test: /^(?:[-+]?\.(?:inf|Inf|INF)|\.nan|\.NaN|\.NAN)$/,
  resolve: (str) => str.slice(-3).toLowerCase() === "nan" ? NaN : str[0] === "-" ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY,
  stringify: stringifyNumber
};
var floatExp = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  format: "EXP",
  test: /^[-+]?(?:\.[0-9]+|[0-9]+(?:\.[0-9]*)?)[eE][-+]?[0-9]+$/,
  resolve: (str) => parseFloat(str),
  stringify(node2) {
    const num = Number(node2.value);
    return isFinite(num) ? num.toExponential() : stringifyNumber(node2);
  }
};
var float = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  test: /^[-+]?(?:\.[0-9]+|[0-9]+\.[0-9]*)$/,
  resolve(str) {
    const node2 = new Scalar(parseFloat(str));
    const dot = str.indexOf(".");
    if (dot !== -1 && str[str.length - 1] === "0")
      node2.minFractionDigits = str.length - dot - 1;
    return node2;
  },
  stringify: stringifyNumber
};

// node_modules/yaml/browser/dist/schema/core/int.js
var intIdentify = (value) => typeof value === "bigint" || Number.isInteger(value);
var intResolve = (str, offset, radix, { intAsBigInt }) => intAsBigInt ? BigInt(str) : parseInt(str.substring(offset), radix);
function intStringify(node2, radix, prefix) {
  const { value } = node2;
  if (intIdentify(value) && value >= 0)
    return prefix + value.toString(radix);
  return stringifyNumber(node2);
}
var intOct = {
  identify: (value) => intIdentify(value) && value >= 0,
  default: true,
  tag: "tag:yaml.org,2002:int",
  format: "OCT",
  test: /^0o[0-7]+$/,
  resolve: (str, _onError, opt) => intResolve(str, 2, 8, opt),
  stringify: (node2) => intStringify(node2, 8, "0o")
};
var int = {
  identify: intIdentify,
  default: true,
  tag: "tag:yaml.org,2002:int",
  test: /^[-+]?[0-9]+$/,
  resolve: (str, _onError, opt) => intResolve(str, 0, 10, opt),
  stringify: stringifyNumber
};
var intHex = {
  identify: (value) => intIdentify(value) && value >= 0,
  default: true,
  tag: "tag:yaml.org,2002:int",
  format: "HEX",
  test: /^0x[0-9a-fA-F]+$/,
  resolve: (str, _onError, opt) => intResolve(str, 2, 16, opt),
  stringify: (node2) => intStringify(node2, 16, "0x")
};

// node_modules/yaml/browser/dist/schema/core/schema.js
var schema = [
  map,
  seq,
  string,
  nullTag,
  boolTag,
  intOct,
  int,
  intHex,
  floatNaN,
  floatExp,
  float
];

// node_modules/yaml/browser/dist/schema/json/schema.js
function intIdentify2(value) {
  return typeof value === "bigint" || Number.isInteger(value);
}
var stringifyJSON = ({ value }) => JSON.stringify(value);
var jsonScalars = [
  {
    identify: (value) => typeof value === "string",
    default: true,
    tag: "tag:yaml.org,2002:str",
    resolve: (str) => str,
    stringify: stringifyJSON
  },
  {
    identify: (value) => value == null,
    createNode: () => new Scalar(null),
    default: true,
    tag: "tag:yaml.org,2002:null",
    test: /^null$/,
    resolve: () => null,
    stringify: stringifyJSON
  },
  {
    identify: (value) => typeof value === "boolean",
    default: true,
    tag: "tag:yaml.org,2002:bool",
    test: /^true$|^false$/,
    resolve: (str) => str === "true",
    stringify: stringifyJSON
  },
  {
    identify: intIdentify2,
    default: true,
    tag: "tag:yaml.org,2002:int",
    test: /^-?(?:0|[1-9][0-9]*)$/,
    resolve: (str, _onError, { intAsBigInt }) => intAsBigInt ? BigInt(str) : parseInt(str, 10),
    stringify: ({ value }) => intIdentify2(value) ? value.toString() : JSON.stringify(value)
  },
  {
    identify: (value) => typeof value === "number",
    default: true,
    tag: "tag:yaml.org,2002:float",
    test: /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]*)?(?:[eE][-+]?[0-9]+)?$/,
    resolve: (str) => parseFloat(str),
    stringify: stringifyJSON
  }
];
var jsonError = {
  default: true,
  tag: "",
  test: /^/,
  resolve(str, onError) {
    onError(`Unresolved plain scalar ${JSON.stringify(str)}`);
    return str;
  }
};
var schema2 = [map, seq].concat(jsonScalars, jsonError);

// node_modules/yaml/browser/dist/schema/yaml-1.1/binary.js
var binary = {
  identify: (value) => value instanceof Uint8Array,
  // Buffer inherits from Uint8Array
  default: false,
  tag: "tag:yaml.org,2002:binary",
  /**
   * Returns a Buffer in node and an Uint8Array in browsers
   *
   * To use the resulting buffer as an image, you'll want to do something like:
   *
   *   const blob = new Blob([buffer], { type: 'image/jpeg' })
   *   document.querySelector('#photo').src = URL.createObjectURL(blob)
   */
  resolve(src, onError) {
    if (typeof atob === "function") {
      const str = atob(src.replace(/[\n\r]/g, ""));
      const buffer = new Uint8Array(str.length);
      for (let i = 0; i < str.length; ++i)
        buffer[i] = str.charCodeAt(i);
      return buffer;
    } else {
      onError("This environment does not support reading binary tags; either Buffer or atob is required");
      return src;
    }
  },
  stringify({ comment, type, value }, ctx, onComment, onChompKeep) {
    if (!value)
      return "";
    const buf = value;
    let str;
    if (typeof btoa === "function") {
      let s = "";
      for (let i = 0; i < buf.length; ++i)
        s += String.fromCharCode(buf[i]);
      str = btoa(s);
    } else {
      throw new Error("This environment does not support writing binary tags; either Buffer or btoa is required");
    }
    type ?? (type = Scalar.BLOCK_LITERAL);
    if (type !== Scalar.QUOTE_DOUBLE) {
      const lineWidth = Math.max(ctx.options.lineWidth - ctx.indent.length, ctx.options.minContentWidth);
      const n = Math.ceil(str.length / lineWidth);
      const lines = new Array(n);
      for (let i = 0, o = 0; i < n; ++i, o += lineWidth) {
        lines[i] = str.substr(o, lineWidth);
      }
      str = lines.join(type === Scalar.BLOCK_LITERAL ? "\n" : " ");
    }
    return stringifyString({ comment, type, value: str }, ctx, onComment, onChompKeep);
  }
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/pairs.js
function resolvePairs(seq2, onError) {
  if (isSeq(seq2)) {
    for (let i = 0; i < seq2.items.length; ++i) {
      let item = seq2.items[i];
      if (isPair(item))
        continue;
      else if (isMap(item)) {
        if (item.items.length > 1)
          onError("Each pair must have its own sequence indicator");
        const pair = item.items[0] || new Pair(new Scalar(null));
        if (item.commentBefore)
          pair.key.commentBefore = pair.key.commentBefore ? `${item.commentBefore}
${pair.key.commentBefore}` : item.commentBefore;
        if (item.comment) {
          const cn = pair.value ?? pair.key;
          cn.comment = cn.comment ? `${item.comment}
${cn.comment}` : item.comment;
        }
        item = pair;
      }
      seq2.items[i] = isPair(item) ? item : new Pair(item);
    }
  } else
    onError("Expected a sequence for this tag");
  return seq2;
}
function createPairs(schema4, iterable, ctx) {
  const { replacer } = ctx;
  const pairs2 = new YAMLSeq(schema4);
  pairs2.tag = "tag:yaml.org,2002:pairs";
  let i = 0;
  if (iterable && Symbol.iterator in Object(iterable))
    for (let it of iterable) {
      if (typeof replacer === "function")
        it = replacer.call(iterable, String(i++), it);
      let key, value;
      if (Array.isArray(it)) {
        if (it.length === 2) {
          key = it[0];
          value = it[1];
        } else
          throw new TypeError(`Expected [key, value] tuple: ${it}`);
      } else if (it && it instanceof Object) {
        const keys = Object.keys(it);
        if (keys.length === 1) {
          key = keys[0];
          value = it[key];
        } else {
          throw new TypeError(`Expected tuple with one key, not ${keys.length} keys`);
        }
      } else {
        key = it;
      }
      pairs2.items.push(createPair(key, value, ctx));
    }
  return pairs2;
}
var pairs = {
  collection: "seq",
  default: false,
  tag: "tag:yaml.org,2002:pairs",
  resolve: resolvePairs,
  createNode: createPairs
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/omap.js
var YAMLOMap = class _YAMLOMap extends YAMLSeq {
  constructor() {
    super();
    this.add = YAMLMap.prototype.add.bind(this);
    this.delete = YAMLMap.prototype.delete.bind(this);
    this.get = YAMLMap.prototype.get.bind(this);
    this.has = YAMLMap.prototype.has.bind(this);
    this.set = YAMLMap.prototype.set.bind(this);
    this.tag = _YAMLOMap.tag;
  }
  /**
   * If `ctx` is given, the return type is actually `Map<unknown, unknown>`,
   * but TypeScript won't allow widening the signature of a child method.
   */
  toJSON(_, ctx) {
    if (!ctx)
      return super.toJSON(_);
    const map2 = /* @__PURE__ */ new Map();
    if (ctx?.onCreate)
      ctx.onCreate(map2);
    for (const pair of this.items) {
      let key, value;
      if (isPair(pair)) {
        key = toJS(pair.key, "", ctx);
        value = toJS(pair.value, key, ctx);
      } else {
        key = toJS(pair, "", ctx);
      }
      if (map2.has(key))
        throw new Error("Ordered maps must not include duplicate keys");
      map2.set(key, value);
    }
    return map2;
  }
  static from(schema4, iterable, ctx) {
    const pairs2 = createPairs(schema4, iterable, ctx);
    const omap2 = new this();
    omap2.items = pairs2.items;
    return omap2;
  }
};
YAMLOMap.tag = "tag:yaml.org,2002:omap";
var omap = {
  collection: "seq",
  identify: (value) => value instanceof Map,
  nodeClass: YAMLOMap,
  default: false,
  tag: "tag:yaml.org,2002:omap",
  resolve(seq2, onError) {
    const pairs2 = resolvePairs(seq2, onError);
    const seenKeys = [];
    for (const { key } of pairs2.items) {
      if (isScalar(key)) {
        if (seenKeys.includes(key.value)) {
          onError(`Ordered maps must not include duplicate keys: ${key.value}`);
        } else {
          seenKeys.push(key.value);
        }
      }
    }
    return Object.assign(new YAMLOMap(), pairs2);
  },
  createNode: (schema4, iterable, ctx) => YAMLOMap.from(schema4, iterable, ctx)
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/bool.js
function boolStringify({ value, source }, ctx) {
  const boolObj = value ? trueTag : falseTag;
  if (source && boolObj.test.test(source))
    return source;
  return value ? ctx.options.trueStr : ctx.options.falseStr;
}
var trueTag = {
  identify: (value) => value === true,
  default: true,
  tag: "tag:yaml.org,2002:bool",
  test: /^(?:Y|y|[Yy]es|YES|[Tt]rue|TRUE|[Oo]n|ON)$/,
  resolve: () => new Scalar(true),
  stringify: boolStringify
};
var falseTag = {
  identify: (value) => value === false,
  default: true,
  tag: "tag:yaml.org,2002:bool",
  test: /^(?:N|n|[Nn]o|NO|[Ff]alse|FALSE|[Oo]ff|OFF)$/,
  resolve: () => new Scalar(false),
  stringify: boolStringify
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/float.js
var floatNaN2 = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  test: /^(?:[-+]?\.(?:inf|Inf|INF)|\.nan|\.NaN|\.NAN)$/,
  resolve: (str) => str.slice(-3).toLowerCase() === "nan" ? NaN : str[0] === "-" ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY,
  stringify: stringifyNumber
};
var floatExp2 = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  format: "EXP",
  test: /^[-+]?(?:[0-9][0-9_]*)?(?:\.[0-9_]*)?[eE][-+]?[0-9]+$/,
  resolve: (str) => parseFloat(str.replace(/_/g, "")),
  stringify(node2) {
    const num = Number(node2.value);
    return isFinite(num) ? num.toExponential() : stringifyNumber(node2);
  }
};
var float2 = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  test: /^[-+]?(?:[0-9][0-9_]*)?\.[0-9_]*$/,
  resolve(str) {
    const node2 = new Scalar(parseFloat(str.replace(/_/g, "")));
    const dot = str.indexOf(".");
    if (dot !== -1) {
      const f = str.substring(dot + 1).replace(/_/g, "");
      if (f[f.length - 1] === "0")
        node2.minFractionDigits = f.length;
    }
    return node2;
  },
  stringify: stringifyNumber
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/int.js
var intIdentify3 = (value) => typeof value === "bigint" || Number.isInteger(value);
function intResolve2(str, offset, radix, { intAsBigInt }) {
  const sign = str[0];
  if (sign === "-" || sign === "+")
    offset += 1;
  str = str.substring(offset).replace(/_/g, "");
  if (intAsBigInt) {
    switch (radix) {
      case 2:
        str = `0b${str}`;
        break;
      case 8:
        str = `0o${str}`;
        break;
      case 16:
        str = `0x${str}`;
        break;
    }
    const n2 = BigInt(str);
    return sign === "-" ? BigInt(-1) * n2 : n2;
  }
  const n = parseInt(str, radix);
  return sign === "-" ? -1 * n : n;
}
function intStringify2(node2, radix, prefix) {
  const { value } = node2;
  if (intIdentify3(value)) {
    const str = value.toString(radix);
    return value < 0 ? "-" + prefix + str.substr(1) : prefix + str;
  }
  return stringifyNumber(node2);
}
var intBin = {
  identify: intIdentify3,
  default: true,
  tag: "tag:yaml.org,2002:int",
  format: "BIN",
  test: /^[-+]?0b[0-1_]+$/,
  resolve: (str, _onError, opt) => intResolve2(str, 2, 2, opt),
  stringify: (node2) => intStringify2(node2, 2, "0b")
};
var intOct2 = {
  identify: intIdentify3,
  default: true,
  tag: "tag:yaml.org,2002:int",
  format: "OCT",
  test: /^[-+]?0[0-7_]+$/,
  resolve: (str, _onError, opt) => intResolve2(str, 1, 8, opt),
  stringify: (node2) => intStringify2(node2, 8, "0")
};
var int2 = {
  identify: intIdentify3,
  default: true,
  tag: "tag:yaml.org,2002:int",
  test: /^[-+]?[0-9][0-9_]*$/,
  resolve: (str, _onError, opt) => intResolve2(str, 0, 10, opt),
  stringify: stringifyNumber
};
var intHex2 = {
  identify: intIdentify3,
  default: true,
  tag: "tag:yaml.org,2002:int",
  format: "HEX",
  test: /^[-+]?0x[0-9a-fA-F_]+$/,
  resolve: (str, _onError, opt) => intResolve2(str, 2, 16, opt),
  stringify: (node2) => intStringify2(node2, 16, "0x")
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/set.js
var YAMLSet = class _YAMLSet extends YAMLMap {
  constructor(schema4) {
    super(schema4);
    this.tag = _YAMLSet.tag;
  }
  add(key) {
    let pair;
    if (isPair(key))
      pair = key;
    else if (key && typeof key === "object" && "key" in key && "value" in key && key.value === null)
      pair = new Pair(key.key, null);
    else
      pair = new Pair(key, null);
    const prev = findPair(this.items, pair.key);
    if (!prev)
      this.items.push(pair);
  }
  /**
   * If `keepPair` is `true`, returns the Pair matching `key`.
   * Otherwise, returns the value of that Pair's key.
   */
  get(key, keepPair) {
    const pair = findPair(this.items, key);
    return !keepPair && isPair(pair) ? isScalar(pair.key) ? pair.key.value : pair.key : pair;
  }
  set(key, value) {
    if (typeof value !== "boolean")
      throw new Error(`Expected boolean value for set(key, value) in a YAML set, not ${typeof value}`);
    const prev = findPair(this.items, key);
    if (prev && !value) {
      this.items.splice(this.items.indexOf(prev), 1);
    } else if (!prev && value) {
      this.items.push(new Pair(key));
    }
  }
  toJSON(_, ctx) {
    return super.toJSON(_, ctx, Set);
  }
  toString(ctx, onComment, onChompKeep) {
    if (!ctx)
      return JSON.stringify(this);
    if (this.hasAllNullValues(true))
      return super.toString(Object.assign({}, ctx, { allNullValues: true }), onComment, onChompKeep);
    else
      throw new Error("Set items must all have null values");
  }
  static from(schema4, iterable, ctx) {
    const { replacer } = ctx;
    const set2 = new this(schema4);
    if (iterable && Symbol.iterator in Object(iterable))
      for (let value of iterable) {
        if (typeof replacer === "function")
          value = replacer.call(iterable, value, value);
        set2.items.push(createPair(value, null, ctx));
      }
    return set2;
  }
};
YAMLSet.tag = "tag:yaml.org,2002:set";
var set = {
  collection: "map",
  identify: (value) => value instanceof Set,
  nodeClass: YAMLSet,
  default: false,
  tag: "tag:yaml.org,2002:set",
  createNode: (schema4, iterable, ctx) => YAMLSet.from(schema4, iterable, ctx),
  resolve(map2, onError) {
    if (isMap(map2)) {
      if (map2.hasAllNullValues(true))
        return Object.assign(new YAMLSet(), map2);
      else
        onError("Set items must all have null values");
    } else
      onError("Expected a mapping for this tag");
    return map2;
  }
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/timestamp.js
function parseSexagesimal(str, asBigInt) {
  const sign = str[0];
  const parts = sign === "-" || sign === "+" ? str.substring(1) : str;
  const num = (n) => asBigInt ? BigInt(n) : Number(n);
  const res = parts.replace(/_/g, "").split(":").reduce((res2, p) => res2 * num(60) + num(p), num(0));
  return sign === "-" ? num(-1) * res : res;
}
function stringifySexagesimal(node2) {
  let { value } = node2;
  let num = (n) => n;
  if (typeof value === "bigint")
    num = (n) => BigInt(n);
  else if (isNaN(value) || !isFinite(value))
    return stringifyNumber(node2);
  let sign = "";
  if (value < 0) {
    sign = "-";
    value *= num(-1);
  }
  const _60 = num(60);
  const parts = [value % _60];
  if (value < 60) {
    parts.unshift(0);
  } else {
    value = (value - parts[0]) / _60;
    parts.unshift(value % _60);
    if (value >= 60) {
      value = (value - parts[0]) / _60;
      parts.unshift(value);
    }
  }
  return sign + parts.map((n) => String(n).padStart(2, "0")).join(":").replace(/000000\d*$/, "");
}
var intTime = {
  identify: (value) => typeof value === "bigint" || Number.isInteger(value),
  default: true,
  tag: "tag:yaml.org,2002:int",
  format: "TIME",
  test: /^[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+$/,
  resolve: (str, _onError, { intAsBigInt }) => parseSexagesimal(str, intAsBigInt),
  stringify: stringifySexagesimal
};
var floatTime = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  format: "TIME",
  test: /^[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\.[0-9_]*$/,
  resolve: (str) => parseSexagesimal(str, false),
  stringify: stringifySexagesimal
};
var timestamp = {
  identify: (value) => value instanceof Date,
  default: true,
  tag: "tag:yaml.org,2002:timestamp",
  // If the time zone is omitted, the timestamp is assumed to be specified in UTC. The time part
  // may be omitted altogether, resulting in a date format. In such a case, the time part is
  // assumed to be 00:00:00Z (start of day, UTC).
  test: RegExp("^([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})(?:(?:t|T|[ \\t]+)([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2}(\\.[0-9]+)?)(?:[ \\t]*(Z|[-+][012]?[0-9](?::[0-9]{2})?))?)?$"),
  resolve(str) {
    const match = str.match(timestamp.test);
    if (!match)
      throw new Error("!!timestamp expects a date, starting with yyyy-mm-dd");
    const [, year, month, day, hour, minute, second] = match.map(Number);
    const millisec = match[7] ? Number((match[7] + "00").substr(1, 3)) : 0;
    let date = Date.UTC(year, month - 1, day, hour || 0, minute || 0, second || 0, millisec);
    const tz = match[8];
    if (tz && tz !== "Z") {
      let d = parseSexagesimal(tz, false);
      if (Math.abs(d) < 30)
        d *= 60;
      date -= 6e4 * d;
    }
    return new Date(date);
  },
  stringify: ({ value }) => value?.toISOString().replace(/(T00:00:00)?\.000Z$/, "") ?? ""
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/schema.js
var schema3 = [
  map,
  seq,
  string,
  nullTag,
  trueTag,
  falseTag,
  intBin,
  intOct2,
  int2,
  intHex2,
  floatNaN2,
  floatExp2,
  float2,
  binary,
  merge,
  omap,
  pairs,
  set,
  intTime,
  floatTime,
  timestamp
];

// node_modules/yaml/browser/dist/schema/tags.js
var schemas = /* @__PURE__ */ new Map([
  ["core", schema],
  ["failsafe", [map, seq, string]],
  ["json", schema2],
  ["yaml11", schema3],
  ["yaml-1.1", schema3]
]);
var tagsByName = {
  binary,
  bool: boolTag,
  float,
  floatExp,
  floatNaN,
  floatTime,
  int,
  intHex,
  intOct,
  intTime,
  map,
  merge,
  null: nullTag,
  omap,
  pairs,
  seq,
  set,
  timestamp
};
var coreKnownTags = {
  "tag:yaml.org,2002:binary": binary,
  "tag:yaml.org,2002:merge": merge,
  "tag:yaml.org,2002:omap": omap,
  "tag:yaml.org,2002:pairs": pairs,
  "tag:yaml.org,2002:set": set,
  "tag:yaml.org,2002:timestamp": timestamp
};
function getTags(customTags, schemaName, addMergeTag) {
  const schemaTags = schemas.get(schemaName);
  if (schemaTags && !customTags) {
    return addMergeTag && !schemaTags.includes(merge) ? schemaTags.concat(merge) : schemaTags.slice();
  }
  let tags = schemaTags;
  if (!tags) {
    if (Array.isArray(customTags))
      tags = [];
    else {
      const keys = Array.from(schemas.keys()).filter((key) => key !== "yaml11").map((key) => JSON.stringify(key)).join(", ");
      throw new Error(`Unknown schema "${schemaName}"; use one of ${keys} or define customTags array`);
    }
  }
  if (Array.isArray(customTags)) {
    for (const tag of customTags)
      tags = tags.concat(tag);
  } else if (typeof customTags === "function") {
    tags = customTags(tags.slice());
  }
  if (addMergeTag)
    tags = tags.concat(merge);
  return tags.reduce((tags2, tag) => {
    const tagObj = typeof tag === "string" ? tagsByName[tag] : tag;
    if (!tagObj) {
      const tagName = JSON.stringify(tag);
      const keys = Object.keys(tagsByName).map((key) => JSON.stringify(key)).join(", ");
      throw new Error(`Unknown custom tag ${tagName}; use one of ${keys}`);
    }
    if (!tags2.includes(tagObj))
      tags2.push(tagObj);
    return tags2;
  }, []);
}

// node_modules/yaml/browser/dist/schema/Schema.js
var sortMapEntriesByKey = (a, b) => a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
var Schema = class _Schema {
  constructor({ compat, customTags, merge: merge2, resolveKnownTags, schema: schema4, sortMapEntries, toStringDefaults }) {
    this.compat = Array.isArray(compat) ? getTags(compat, "compat") : compat ? getTags(null, compat) : null;
    this.name = typeof schema4 === "string" && schema4 || "core";
    this.knownTags = resolveKnownTags ? coreKnownTags : {};
    this.tags = getTags(customTags, this.name, merge2);
    this.toStringOptions = toStringDefaults ?? null;
    Object.defineProperty(this, MAP, { value: map });
    Object.defineProperty(this, SCALAR, { value: string });
    Object.defineProperty(this, SEQ, { value: seq });
    this.sortMapEntries = typeof sortMapEntries === "function" ? sortMapEntries : sortMapEntries === true ? sortMapEntriesByKey : null;
  }
  clone() {
    const copy = Object.create(_Schema.prototype, Object.getOwnPropertyDescriptors(this));
    copy.tags = this.tags.slice();
    return copy;
  }
};

// node_modules/yaml/browser/dist/stringify/stringifyDocument.js
function stringifyDocument(doc, options) {
  const lines = [];
  let hasDirectives = options.directives === true;
  if (options.directives !== false && doc.directives) {
    const dir = doc.directives.toString(doc);
    if (dir) {
      lines.push(dir);
      hasDirectives = true;
    } else if (doc.directives.docStart)
      hasDirectives = true;
  }
  if (hasDirectives)
    lines.push("---");
  const ctx = createStringifyContext(doc, options);
  const { commentString } = ctx.options;
  if (doc.commentBefore) {
    if (lines.length !== 1)
      lines.unshift("");
    const cs = commentString(doc.commentBefore);
    lines.unshift(indentComment(cs, ""));
  }
  let chompKeep = false;
  let contentComment = null;
  if (doc.contents) {
    if (isNode(doc.contents)) {
      if (doc.contents.spaceBefore && hasDirectives)
        lines.push("");
      if (doc.contents.commentBefore) {
        const cs = commentString(doc.contents.commentBefore);
        lines.push(indentComment(cs, ""));
      }
      ctx.forceBlockIndent = !!doc.comment;
      contentComment = doc.contents.comment;
    }
    const onChompKeep = contentComment ? void 0 : () => chompKeep = true;
    let body = stringify(doc.contents, ctx, () => contentComment = null, onChompKeep);
    if (contentComment)
      body += lineComment(body, "", commentString(contentComment));
    if ((body[0] === "|" || body[0] === ">") && lines[lines.length - 1] === "---") {
      lines[lines.length - 1] = `--- ${body}`;
    } else
      lines.push(body);
  } else {
    lines.push(stringify(doc.contents, ctx));
  }
  if (doc.directives?.docEnd) {
    if (doc.comment) {
      const cs = commentString(doc.comment);
      if (cs.includes("\n")) {
        lines.push("...");
        lines.push(indentComment(cs, ""));
      } else {
        lines.push(`... ${cs}`);
      }
    } else {
      lines.push("...");
    }
  } else {
    let dc = doc.comment;
    if (dc && chompKeep)
      dc = dc.replace(/^\n+/, "");
    if (dc) {
      if ((!chompKeep || contentComment) && lines[lines.length - 1] !== "")
        lines.push("");
      lines.push(indentComment(commentString(dc), ""));
    }
  }
  return lines.join("\n") + "\n";
}

// node_modules/yaml/browser/dist/doc/Document.js
var Document = class _Document {
  constructor(value, replacer, options) {
    this.commentBefore = null;
    this.comment = null;
    this.errors = [];
    this.warnings = [];
    Object.defineProperty(this, NODE_TYPE, { value: DOC });
    let _replacer = null;
    if (typeof replacer === "function" || Array.isArray(replacer)) {
      _replacer = replacer;
    } else if (options === void 0 && replacer) {
      options = replacer;
      replacer = void 0;
    }
    const opt = Object.assign({
      intAsBigInt: false,
      keepSourceTokens: false,
      logLevel: "warn",
      prettyErrors: true,
      strict: true,
      stringKeys: false,
      uniqueKeys: true,
      version: "1.2"
    }, options);
    this.options = opt;
    let { version } = opt;
    if (options?._directives) {
      this.directives = options._directives.atDocument();
      if (this.directives.yaml.explicit)
        version = this.directives.yaml.version;
    } else
      this.directives = new Directives({ version });
    this.setSchema(version, options);
    this.contents = value === void 0 ? null : this.createNode(value, _replacer, options);
  }
  /**
   * Create a deep copy of this Document and its contents.
   *
   * Custom Node values that inherit from `Object` still refer to their original instances.
   */
  clone() {
    const copy = Object.create(_Document.prototype, {
      [NODE_TYPE]: { value: DOC }
    });
    copy.commentBefore = this.commentBefore;
    copy.comment = this.comment;
    copy.errors = this.errors.slice();
    copy.warnings = this.warnings.slice();
    copy.options = Object.assign({}, this.options);
    if (this.directives)
      copy.directives = this.directives.clone();
    copy.schema = this.schema.clone();
    copy.contents = isNode(this.contents) ? this.contents.clone(copy.schema) : this.contents;
    if (this.range)
      copy.range = this.range.slice();
    return copy;
  }
  /** Adds a value to the document. */
  add(value) {
    if (assertCollection(this.contents))
      this.contents.add(value);
  }
  /** Adds a value to the document. */
  addIn(path, value) {
    if (assertCollection(this.contents))
      this.contents.addIn(path, value);
  }
  /**
   * Create a new `Alias` node, ensuring that the target `node` has the required anchor.
   *
   * If `node` already has an anchor, `name` is ignored.
   * Otherwise, the `node.anchor` value will be set to `name`,
   * or if an anchor with that name is already present in the document,
   * `name` will be used as a prefix for a new unique anchor.
   * If `name` is undefined, the generated anchor will use 'a' as a prefix.
   */
  createAlias(node2, name2) {
    if (!node2.anchor) {
      const prev = anchorNames(this);
      node2.anchor = // eslint-disable-next-line @typescript-eslint/prefer-nullish-coalescing
      !name2 || prev.has(name2) ? findNewAnchor(name2 || "a", prev) : name2;
    }
    return new Alias(node2.anchor);
  }
  createNode(value, replacer, options) {
    let _replacer = void 0;
    if (typeof replacer === "function") {
      value = replacer.call({ "": value }, "", value);
      _replacer = replacer;
    } else if (Array.isArray(replacer)) {
      const keyToStr = (v) => typeof v === "number" || v instanceof String || v instanceof Number;
      const asStr = replacer.filter(keyToStr).map(String);
      if (asStr.length > 0)
        replacer = replacer.concat(asStr);
      _replacer = replacer;
    } else if (options === void 0 && replacer) {
      options = replacer;
      replacer = void 0;
    }
    const { aliasDuplicateObjects, anchorPrefix, flow, keepUndefined, onTagObj, tag } = options ?? {};
    const { onAnchor, setAnchors, sourceObjects } = createNodeAnchors(
      this,
      // eslint-disable-next-line @typescript-eslint/prefer-nullish-coalescing
      anchorPrefix || "a"
    );
    const ctx = {
      aliasDuplicateObjects: aliasDuplicateObjects ?? true,
      keepUndefined: keepUndefined ?? false,
      onAnchor,
      onTagObj,
      replacer: _replacer,
      schema: this.schema,
      sourceObjects
    };
    const node2 = createNode(value, tag, ctx);
    if (flow && isCollection(node2))
      node2.flow = true;
    setAnchors();
    return node2;
  }
  /**
   * Convert a key and a value into a `Pair` using the current schema,
   * recursively wrapping all values as `Scalar` or `Collection` nodes.
   */
  createPair(key, value, options = {}) {
    const k = this.createNode(key, null, options);
    const v = this.createNode(value, null, options);
    return new Pair(k, v);
  }
  /**
   * Removes a value from the document.
   * @returns `true` if the item was found and removed.
   */
  delete(key) {
    return assertCollection(this.contents) ? this.contents.delete(key) : false;
  }
  /**
   * Removes a value from the document.
   * @returns `true` if the item was found and removed.
   */
  deleteIn(path) {
    if (isEmptyPath(path)) {
      if (this.contents == null)
        return false;
      this.contents = null;
      return true;
    }
    return assertCollection(this.contents) ? this.contents.deleteIn(path) : false;
  }
  /**
   * Returns item at `key`, or `undefined` if not found. By default unwraps
   * scalar values from their surrounding node; to disable set `keepScalar` to
   * `true` (collections are always returned intact).
   */
  get(key, keepScalar) {
    return isCollection(this.contents) ? this.contents.get(key, keepScalar) : void 0;
  }
  /**
   * Returns item at `path`, or `undefined` if not found. By default unwraps
   * scalar values from their surrounding node; to disable set `keepScalar` to
   * `true` (collections are always returned intact).
   */
  getIn(path, keepScalar) {
    if (isEmptyPath(path))
      return !keepScalar && isScalar(this.contents) ? this.contents.value : this.contents;
    return isCollection(this.contents) ? this.contents.getIn(path, keepScalar) : void 0;
  }
  /**
   * Checks if the document includes a value with the key `key`.
   */
  has(key) {
    return isCollection(this.contents) ? this.contents.has(key) : false;
  }
  /**
   * Checks if the document includes a value at `path`.
   */
  hasIn(path) {
    if (isEmptyPath(path))
      return this.contents !== void 0;
    return isCollection(this.contents) ? this.contents.hasIn(path) : false;
  }
  /**
   * Sets a value in this document. For `!!set`, `value` needs to be a
   * boolean to add/remove the item from the set.
   */
  set(key, value) {
    if (this.contents == null) {
      this.contents = collectionFromPath(this.schema, [key], value);
    } else if (assertCollection(this.contents)) {
      this.contents.set(key, value);
    }
  }
  /**
   * Sets a value in this document. For `!!set`, `value` needs to be a
   * boolean to add/remove the item from the set.
   */
  setIn(path, value) {
    if (isEmptyPath(path)) {
      this.contents = value;
    } else if (this.contents == null) {
      this.contents = collectionFromPath(this.schema, Array.from(path), value);
    } else if (assertCollection(this.contents)) {
      this.contents.setIn(path, value);
    }
  }
  /**
   * Change the YAML version and schema used by the document.
   * A `null` version disables support for directives, explicit tags, anchors, and aliases.
   * It also requires the `schema` option to be given as a `Schema` instance value.
   *
   * Overrides all previously set schema options.
   */
  setSchema(version, options = {}) {
    if (typeof version === "number")
      version = String(version);
    let opt;
    switch (version) {
      case "1.1":
        if (this.directives)
          this.directives.yaml.version = "1.1";
        else
          this.directives = new Directives({ version: "1.1" });
        opt = { resolveKnownTags: false, schema: "yaml-1.1" };
        break;
      case "1.2":
      case "next":
        if (this.directives)
          this.directives.yaml.version = version;
        else
          this.directives = new Directives({ version });
        opt = { resolveKnownTags: true, schema: "core" };
        break;
      case null:
        if (this.directives)
          delete this.directives;
        opt = null;
        break;
      default: {
        const sv = JSON.stringify(version);
        throw new Error(`Expected '1.1', '1.2' or null as first argument, but found: ${sv}`);
      }
    }
    if (options.schema instanceof Object)
      this.schema = options.schema;
    else if (opt)
      this.schema = new Schema(Object.assign(opt, options));
    else
      throw new Error(`With a null YAML version, the { schema: Schema } option is required`);
  }
  // json & jsonArg are only used from toJSON()
  toJS({ json, jsonArg, mapAsMap, maxAliasCount, onAnchor, reviver } = {}) {
    const ctx = {
      anchors: /* @__PURE__ */ new Map(),
      doc: this,
      keep: !json,
      mapAsMap: mapAsMap === true,
      mapKeyWarned: false,
      maxAliasCount: typeof maxAliasCount === "number" ? maxAliasCount : 100
    };
    const res = toJS(this.contents, jsonArg ?? "", ctx);
    if (typeof onAnchor === "function")
      for (const { count, res: res2 } of ctx.anchors.values())
        onAnchor(res2, count);
    return typeof reviver === "function" ? applyReviver(reviver, { "": res }, "", res) : res;
  }
  /**
   * A JSON representation of the document `contents`.
   *
   * @param jsonArg Used by `JSON.stringify` to indicate the array index or
   *   property name.
   */
  toJSON(jsonArg, onAnchor) {
    return this.toJS({ json: true, jsonArg, mapAsMap: false, onAnchor });
  }
  /** A YAML representation of the document. */
  toString(options = {}) {
    if (this.errors.length > 0)
      throw new Error("Document with errors cannot be stringified");
    if ("indent" in options && (!Number.isInteger(options.indent) || Number(options.indent) <= 0)) {
      const s = JSON.stringify(options.indent);
      throw new Error(`"indent" option must be a positive integer, not ${s}`);
    }
    return stringifyDocument(this, options);
  }
};
function assertCollection(contents) {
  if (isCollection(contents))
    return true;
  throw new Error("Expected a YAML collection as document contents");
}

// node_modules/yaml/browser/dist/errors.js
var YAMLError = class extends Error {
  constructor(name2, pos, code, message) {
    super();
    this.name = name2;
    this.code = code;
    this.message = message;
    this.pos = pos;
  }
};
var YAMLParseError = class extends YAMLError {
  constructor(pos, code, message) {
    super("YAMLParseError", pos, code, message);
  }
};
var YAMLWarning = class extends YAMLError {
  constructor(pos, code, message) {
    super("YAMLWarning", pos, code, message);
  }
};
var prettifyError = (src, lc) => (error) => {
  if (error.pos[0] === -1)
    return;
  error.linePos = error.pos.map((pos) => lc.linePos(pos));
  const { line, col } = error.linePos[0];
  error.message += ` at line ${line}, column ${col}`;
  let ci = col - 1;
  let lineStr = src.substring(lc.lineStarts[line - 1], lc.lineStarts[line]).replace(/[\n\r]+$/, "");
  if (ci >= 60 && lineStr.length > 80) {
    const trimStart = Math.min(ci - 39, lineStr.length - 79);
    lineStr = "\u2026" + lineStr.substring(trimStart);
    ci -= trimStart - 1;
  }
  if (lineStr.length > 80)
    lineStr = lineStr.substring(0, 79) + "\u2026";
  if (line > 1 && /^ *$/.test(lineStr.substring(0, ci))) {
    let prev = src.substring(lc.lineStarts[line - 2], lc.lineStarts[line - 1]);
    if (prev.length > 80)
      prev = prev.substring(0, 79) + "\u2026\n";
    lineStr = prev + lineStr;
  }
  if (/[^ ]/.test(lineStr)) {
    let count = 1;
    const end = error.linePos[1];
    if (end?.line === line && end.col > col) {
      count = Math.max(1, Math.min(end.col - col, 80 - ci));
    }
    const pointer = " ".repeat(ci) + "^".repeat(count);
    error.message += `:

${lineStr}
${pointer}
`;
  }
};

// node_modules/yaml/browser/dist/compose/resolve-props.js
function resolveProps(tokens, { flow, indicator, next: next2, offset, onError, parentIndent, startOnNewline }) {
  let spaceBefore = false;
  let atNewline = startOnNewline;
  let hasSpace = startOnNewline;
  let comment = "";
  let commentSep = "";
  let hasNewline = false;
  let reqSpace = false;
  let tab = null;
  let anchor = null;
  let tag = null;
  let newlineAfterProp = null;
  let comma = null;
  let found = null;
  let start = null;
  for (const token of tokens) {
    if (reqSpace) {
      if (token.type !== "space" && token.type !== "newline" && token.type !== "comma")
        onError(token.offset, "MISSING_CHAR", "Tags and anchors must be separated from the next token by white space");
      reqSpace = false;
    }
    if (tab) {
      if (atNewline && token.type !== "comment" && token.type !== "newline") {
        onError(tab, "TAB_AS_INDENT", "Tabs are not allowed as indentation");
      }
      tab = null;
    }
    switch (token.type) {
      case "space":
        if (!flow && (indicator !== "doc-start" || next2?.type !== "flow-collection") && token.source.includes("	")) {
          tab = token;
        }
        hasSpace = true;
        break;
      case "comment": {
        if (!hasSpace)
          onError(token, "MISSING_CHAR", "Comments must be separated from other tokens by white space characters");
        const cb = token.source.substring(1) || " ";
        if (!comment)
          comment = cb;
        else
          comment += commentSep + cb;
        commentSep = "";
        atNewline = false;
        break;
      }
      case "newline":
        if (atNewline) {
          if (comment)
            comment += token.source;
          else if (!found || indicator !== "seq-item-ind")
            spaceBefore = true;
        } else
          commentSep += token.source;
        atNewline = true;
        hasNewline = true;
        if (anchor || tag)
          newlineAfterProp = token;
        hasSpace = true;
        break;
      case "anchor":
        if (anchor)
          onError(token, "MULTIPLE_ANCHORS", "A node can have at most one anchor");
        if (token.source.endsWith(":"))
          onError(token.offset + token.source.length - 1, "BAD_ALIAS", "Anchor ending in : is ambiguous", true);
        anchor = token;
        start ?? (start = token.offset);
        atNewline = false;
        hasSpace = false;
        reqSpace = true;
        break;
      case "tag": {
        if (tag)
          onError(token, "MULTIPLE_TAGS", "A node can have at most one tag");
        tag = token;
        start ?? (start = token.offset);
        atNewline = false;
        hasSpace = false;
        reqSpace = true;
        break;
      }
      case indicator:
        if (anchor || tag)
          onError(token, "BAD_PROP_ORDER", `Anchors and tags must be after the ${token.source} indicator`);
        if (found)
          onError(token, "UNEXPECTED_TOKEN", `Unexpected ${token.source} in ${flow ?? "collection"}`);
        found = token;
        atNewline = indicator === "seq-item-ind" || indicator === "explicit-key-ind";
        hasSpace = false;
        break;
      case "comma":
        if (flow) {
          if (comma)
            onError(token, "UNEXPECTED_TOKEN", `Unexpected , in ${flow}`);
          comma = token;
          atNewline = false;
          hasSpace = false;
          break;
        }
      // else fallthrough
      default:
        onError(token, "UNEXPECTED_TOKEN", `Unexpected ${token.type} token`);
        atNewline = false;
        hasSpace = false;
    }
  }
  const last = tokens[tokens.length - 1];
  const end = last ? last.offset + last.source.length : offset;
  if (reqSpace && next2 && next2.type !== "space" && next2.type !== "newline" && next2.type !== "comma" && (next2.type !== "scalar" || next2.source !== "")) {
    onError(next2.offset, "MISSING_CHAR", "Tags and anchors must be separated from the next token by white space");
  }
  if (tab && (atNewline && tab.indent <= parentIndent || next2?.type === "block-map" || next2?.type === "block-seq"))
    onError(tab, "TAB_AS_INDENT", "Tabs are not allowed as indentation");
  return {
    comma,
    found,
    spaceBefore,
    comment,
    hasNewline,
    anchor,
    tag,
    newlineAfterProp,
    end,
    start: start ?? end
  };
}

// node_modules/yaml/browser/dist/compose/util-contains-newline.js
function containsNewline(key) {
  if (!key)
    return null;
  switch (key.type) {
    case "alias":
    case "scalar":
    case "double-quoted-scalar":
    case "single-quoted-scalar":
      if (key.source.includes("\n"))
        return true;
      if (key.end) {
        for (const st of key.end)
          if (st.type === "newline")
            return true;
      }
      return false;
    case "flow-collection":
      for (const it of key.items) {
        for (const st of it.start)
          if (st.type === "newline")
            return true;
        if (it.sep) {
          for (const st of it.sep)
            if (st.type === "newline")
              return true;
        }
        if (containsNewline(it.key) || containsNewline(it.value))
          return true;
      }
      return false;
    default:
      return true;
  }
}

// node_modules/yaml/browser/dist/compose/util-flow-indent-check.js
function flowIndentCheck(indent, fc, onError) {
  if (fc?.type === "flow-collection") {
    const end = fc.end[0];
    if (end.indent === indent && (end.source === "]" || end.source === "}") && containsNewline(fc)) {
      const msg = "Flow end indicator should be more indented than parent";
      onError(end, "BAD_INDENT", msg, true);
    }
  }
}

// node_modules/yaml/browser/dist/compose/util-map-includes.js
function mapIncludes(ctx, items, search) {
  const { uniqueKeys } = ctx.options;
  if (uniqueKeys === false)
    return false;
  const isEqual = typeof uniqueKeys === "function" ? uniqueKeys : (a, b) => a === b || isScalar(a) && isScalar(b) && a.value === b.value;
  return items.some((pair) => isEqual(pair.key, search));
}

// node_modules/yaml/browser/dist/compose/resolve-block-map.js
var startColMsg = "All mapping items must start at the same column";
function resolveBlockMap({ composeNode: composeNode2, composeEmptyNode: composeEmptyNode2 }, ctx, bm, onError, tag) {
  const NodeClass = tag?.nodeClass ?? YAMLMap;
  const map2 = new NodeClass(ctx.schema);
  if (ctx.atRoot)
    ctx.atRoot = false;
  let offset = bm.offset;
  let commentEnd = null;
  for (const collItem of bm.items) {
    const { start, key, sep, value } = collItem;
    const keyProps = resolveProps(start, {
      indicator: "explicit-key-ind",
      next: key ?? sep?.[0],
      offset,
      onError,
      parentIndent: bm.indent,
      startOnNewline: true
    });
    const implicitKey = !keyProps.found;
    if (implicitKey) {
      if (key) {
        if (key.type === "block-seq")
          onError(offset, "BLOCK_AS_IMPLICIT_KEY", "A block sequence may not be used as an implicit map key");
        else if ("indent" in key && key.indent !== bm.indent)
          onError(offset, "BAD_INDENT", startColMsg);
      }
      if (!keyProps.anchor && !keyProps.tag && !sep) {
        commentEnd = keyProps.end;
        if (keyProps.comment) {
          if (map2.comment)
            map2.comment += "\n" + keyProps.comment;
          else
            map2.comment = keyProps.comment;
        }
        continue;
      }
      if (keyProps.newlineAfterProp || containsNewline(key)) {
        onError(key ?? start[start.length - 1], "MULTILINE_IMPLICIT_KEY", "Implicit keys need to be on a single line");
      }
    } else if (keyProps.found?.indent !== bm.indent) {
      onError(offset, "BAD_INDENT", startColMsg);
    }
    ctx.atKey = true;
    const keyStart = keyProps.end;
    const keyNode = key ? composeNode2(ctx, key, keyProps, onError) : composeEmptyNode2(ctx, keyStart, start, null, keyProps, onError);
    if (ctx.schema.compat)
      flowIndentCheck(bm.indent, key, onError);
    ctx.atKey = false;
    if (mapIncludes(ctx, map2.items, keyNode))
      onError(keyStart, "DUPLICATE_KEY", "Map keys must be unique");
    const valueProps = resolveProps(sep ?? [], {
      indicator: "map-value-ind",
      next: value,
      offset: keyNode.range[2],
      onError,
      parentIndent: bm.indent,
      startOnNewline: !key || key.type === "block-scalar"
    });
    offset = valueProps.end;
    if (valueProps.found) {
      if (implicitKey) {
        if (value?.type === "block-map" && !valueProps.hasNewline)
          onError(offset, "BLOCK_AS_IMPLICIT_KEY", "Nested mappings are not allowed in compact mappings");
        if (ctx.options.strict && keyProps.start < valueProps.found.offset - 1024)
          onError(keyNode.range, "KEY_OVER_1024_CHARS", "The : indicator must be at most 1024 chars after the start of an implicit block mapping key");
      }
      const valueNode = value ? composeNode2(ctx, value, valueProps, onError) : composeEmptyNode2(ctx, offset, sep, null, valueProps, onError);
      if (ctx.schema.compat)
        flowIndentCheck(bm.indent, value, onError);
      offset = valueNode.range[2];
      const pair = new Pair(keyNode, valueNode);
      if (ctx.options.keepSourceTokens)
        pair.srcToken = collItem;
      map2.items.push(pair);
    } else {
      if (implicitKey)
        onError(keyNode.range, "MISSING_CHAR", "Implicit map keys need to be followed by map values");
      if (valueProps.comment) {
        if (keyNode.comment)
          keyNode.comment += "\n" + valueProps.comment;
        else
          keyNode.comment = valueProps.comment;
      }
      const pair = new Pair(keyNode);
      if (ctx.options.keepSourceTokens)
        pair.srcToken = collItem;
      map2.items.push(pair);
    }
  }
  if (commentEnd && commentEnd < offset)
    onError(commentEnd, "IMPOSSIBLE", "Map comment with trailing content");
  map2.range = [bm.offset, offset, commentEnd ?? offset];
  return map2;
}

// node_modules/yaml/browser/dist/compose/resolve-block-seq.js
function resolveBlockSeq({ composeNode: composeNode2, composeEmptyNode: composeEmptyNode2 }, ctx, bs, onError, tag) {
  const NodeClass = tag?.nodeClass ?? YAMLSeq;
  const seq2 = new NodeClass(ctx.schema);
  if (ctx.atRoot)
    ctx.atRoot = false;
  if (ctx.atKey)
    ctx.atKey = false;
  let offset = bs.offset;
  let commentEnd = null;
  for (const { start, value } of bs.items) {
    const props = resolveProps(start, {
      indicator: "seq-item-ind",
      next: value,
      offset,
      onError,
      parentIndent: bs.indent,
      startOnNewline: true
    });
    if (!props.found) {
      if (props.anchor || props.tag || value) {
        if (value?.type === "block-seq")
          onError(props.end, "BAD_INDENT", "All sequence items must start at the same column");
        else
          onError(offset, "MISSING_CHAR", "Sequence item without - indicator");
      } else {
        commentEnd = props.end;
        if (props.comment)
          seq2.comment = props.comment;
        continue;
      }
    }
    const node2 = value ? composeNode2(ctx, value, props, onError) : composeEmptyNode2(ctx, props.end, start, null, props, onError);
    if (ctx.schema.compat)
      flowIndentCheck(bs.indent, value, onError);
    offset = node2.range[2];
    seq2.items.push(node2);
  }
  seq2.range = [bs.offset, offset, commentEnd ?? offset];
  return seq2;
}

// node_modules/yaml/browser/dist/compose/resolve-end.js
function resolveEnd(end, offset, reqSpace, onError) {
  let comment = "";
  if (end) {
    let hasSpace = false;
    let sep = "";
    for (const token of end) {
      const { source, type } = token;
      switch (type) {
        case "space":
          hasSpace = true;
          break;
        case "comment": {
          if (reqSpace && !hasSpace)
            onError(token, "MISSING_CHAR", "Comments must be separated from other tokens by white space characters");
          const cb = source.substring(1) || " ";
          if (!comment)
            comment = cb;
          else
            comment += sep + cb;
          sep = "";
          break;
        }
        case "newline":
          if (comment)
            sep += source;
          hasSpace = true;
          break;
        default:
          onError(token, "UNEXPECTED_TOKEN", `Unexpected ${type} at node end`);
      }
      offset += source.length;
    }
  }
  return { comment, offset };
}

// node_modules/yaml/browser/dist/compose/resolve-flow-collection.js
var blockMsg = "Block collections are not allowed within flow collections";
var isBlock = (token) => token && (token.type === "block-map" || token.type === "block-seq");
function resolveFlowCollection({ composeNode: composeNode2, composeEmptyNode: composeEmptyNode2 }, ctx, fc, onError, tag) {
  const isMap2 = fc.start.source === "{";
  const fcName = isMap2 ? "flow map" : "flow sequence";
  const NodeClass = tag?.nodeClass ?? (isMap2 ? YAMLMap : YAMLSeq);
  const coll = new NodeClass(ctx.schema);
  coll.flow = true;
  const atRoot = ctx.atRoot;
  if (atRoot)
    ctx.atRoot = false;
  if (ctx.atKey)
    ctx.atKey = false;
  let offset = fc.offset + fc.start.source.length;
  for (let i = 0; i < fc.items.length; ++i) {
    const collItem = fc.items[i];
    const { start, key, sep, value } = collItem;
    const props = resolveProps(start, {
      flow: fcName,
      indicator: "explicit-key-ind",
      next: key ?? sep?.[0],
      offset,
      onError,
      parentIndent: fc.indent,
      startOnNewline: false
    });
    if (!props.found) {
      if (!props.anchor && !props.tag && !sep && !value) {
        if (i === 0 && props.comma)
          onError(props.comma, "UNEXPECTED_TOKEN", `Unexpected , in ${fcName}`);
        else if (i < fc.items.length - 1)
          onError(props.start, "UNEXPECTED_TOKEN", `Unexpected empty item in ${fcName}`);
        if (props.comment) {
          if (coll.comment)
            coll.comment += "\n" + props.comment;
          else
            coll.comment = props.comment;
        }
        offset = props.end;
        continue;
      }
      if (!isMap2 && ctx.options.strict && containsNewline(key))
        onError(
          key,
          // checked by containsNewline()
          "MULTILINE_IMPLICIT_KEY",
          "Implicit keys of flow sequence pairs need to be on a single line"
        );
    }
    if (i === 0) {
      if (props.comma)
        onError(props.comma, "UNEXPECTED_TOKEN", `Unexpected , in ${fcName}`);
    } else {
      if (!props.comma)
        onError(props.start, "MISSING_CHAR", `Missing , between ${fcName} items`);
      if (props.comment) {
        let prevItemComment = "";
        loop: for (const st of start) {
          switch (st.type) {
            case "comma":
            case "space":
              break;
            case "comment":
              prevItemComment = st.source.substring(1);
              break loop;
            default:
              break loop;
          }
        }
        if (prevItemComment) {
          let prev = coll.items[coll.items.length - 1];
          if (isPair(prev))
            prev = prev.value ?? prev.key;
          if (prev.comment)
            prev.comment += "\n" + prevItemComment;
          else
            prev.comment = prevItemComment;
          props.comment = props.comment.substring(prevItemComment.length + 1);
        }
      }
    }
    if (!isMap2 && !sep && !props.found) {
      const valueNode = value ? composeNode2(ctx, value, props, onError) : composeEmptyNode2(ctx, props.end, sep, null, props, onError);
      coll.items.push(valueNode);
      offset = valueNode.range[2];
      if (isBlock(value))
        onError(valueNode.range, "BLOCK_IN_FLOW", blockMsg);
    } else {
      ctx.atKey = true;
      const keyStart = props.end;
      const keyNode = key ? composeNode2(ctx, key, props, onError) : composeEmptyNode2(ctx, keyStart, start, null, props, onError);
      if (isBlock(key))
        onError(keyNode.range, "BLOCK_IN_FLOW", blockMsg);
      ctx.atKey = false;
      const valueProps = resolveProps(sep ?? [], {
        flow: fcName,
        indicator: "map-value-ind",
        next: value,
        offset: keyNode.range[2],
        onError,
        parentIndent: fc.indent,
        startOnNewline: false
      });
      if (valueProps.found) {
        if (!isMap2 && !props.found && ctx.options.strict) {
          if (sep)
            for (const st of sep) {
              if (st === valueProps.found)
                break;
              if (st.type === "newline") {
                onError(st, "MULTILINE_IMPLICIT_KEY", "Implicit keys of flow sequence pairs need to be on a single line");
                break;
              }
            }
          if (props.start < valueProps.found.offset - 1024)
            onError(valueProps.found, "KEY_OVER_1024_CHARS", "The : indicator must be at most 1024 chars after the start of an implicit flow sequence key");
        }
      } else if (value) {
        if ("source" in value && value.source?.[0] === ":")
          onError(value, "MISSING_CHAR", `Missing space after : in ${fcName}`);
        else
          onError(valueProps.start, "MISSING_CHAR", `Missing , or : between ${fcName} items`);
      }
      const valueNode = value ? composeNode2(ctx, value, valueProps, onError) : valueProps.found ? composeEmptyNode2(ctx, valueProps.end, sep, null, valueProps, onError) : null;
      if (valueNode) {
        if (isBlock(value))
          onError(valueNode.range, "BLOCK_IN_FLOW", blockMsg);
      } else if (valueProps.comment) {
        if (keyNode.comment)
          keyNode.comment += "\n" + valueProps.comment;
        else
          keyNode.comment = valueProps.comment;
      }
      const pair = new Pair(keyNode, valueNode);
      if (ctx.options.keepSourceTokens)
        pair.srcToken = collItem;
      if (isMap2) {
        const map2 = coll;
        if (mapIncludes(ctx, map2.items, keyNode))
          onError(keyStart, "DUPLICATE_KEY", "Map keys must be unique");
        map2.items.push(pair);
      } else {
        const map2 = new YAMLMap(ctx.schema);
        map2.flow = true;
        map2.items.push(pair);
        const endRange = (valueNode ?? keyNode).range;
        map2.range = [keyNode.range[0], endRange[1], endRange[2]];
        coll.items.push(map2);
      }
      offset = valueNode ? valueNode.range[2] : valueProps.end;
    }
  }
  const expectedEnd = isMap2 ? "}" : "]";
  const [ce, ...ee] = fc.end;
  let cePos = offset;
  if (ce?.source === expectedEnd)
    cePos = ce.offset + ce.source.length;
  else {
    const name2 = fcName[0].toUpperCase() + fcName.substring(1);
    const msg = atRoot ? `${name2} must end with a ${expectedEnd}` : `${name2} in block collection must be sufficiently indented and end with a ${expectedEnd}`;
    onError(offset, atRoot ? "MISSING_CHAR" : "BAD_INDENT", msg);
    if (ce && ce.source.length !== 1)
      ee.unshift(ce);
  }
  if (ee.length > 0) {
    const end = resolveEnd(ee, cePos, ctx.options.strict, onError);
    if (end.comment) {
      if (coll.comment)
        coll.comment += "\n" + end.comment;
      else
        coll.comment = end.comment;
    }
    coll.range = [fc.offset, cePos, end.offset];
  } else {
    coll.range = [fc.offset, cePos, cePos];
  }
  return coll;
}

// node_modules/yaml/browser/dist/compose/compose-collection.js
function resolveCollection(CN2, ctx, token, onError, tagName, tag) {
  const coll = token.type === "block-map" ? resolveBlockMap(CN2, ctx, token, onError, tag) : token.type === "block-seq" ? resolveBlockSeq(CN2, ctx, token, onError, tag) : resolveFlowCollection(CN2, ctx, token, onError, tag);
  const Coll = coll.constructor;
  if (tagName === "!" || tagName === Coll.tagName) {
    coll.tag = Coll.tagName;
    return coll;
  }
  if (tagName)
    coll.tag = tagName;
  return coll;
}
function composeCollection(CN2, ctx, token, props, onError) {
  const tagToken = props.tag;
  const tagName = !tagToken ? null : ctx.directives.tagName(tagToken.source, (msg) => onError(tagToken, "TAG_RESOLVE_FAILED", msg));
  if (token.type === "block-seq") {
    const { anchor, newlineAfterProp: nl } = props;
    const lastProp = anchor && tagToken ? anchor.offset > tagToken.offset ? anchor : tagToken : anchor ?? tagToken;
    if (lastProp && (!nl || nl.offset < lastProp.offset)) {
      const message = "Missing newline after block sequence props";
      onError(lastProp, "MISSING_CHAR", message);
    }
  }
  const expType = token.type === "block-map" ? "map" : token.type === "block-seq" ? "seq" : token.start.source === "{" ? "map" : "seq";
  if (!tagToken || !tagName || tagName === "!" || tagName === YAMLMap.tagName && expType === "map" || tagName === YAMLSeq.tagName && expType === "seq") {
    return resolveCollection(CN2, ctx, token, onError, tagName);
  }
  let tag = ctx.schema.tags.find((t) => t.tag === tagName && t.collection === expType);
  if (!tag) {
    const kt = ctx.schema.knownTags[tagName];
    if (kt?.collection === expType) {
      ctx.schema.tags.push(Object.assign({}, kt, { default: false }));
      tag = kt;
    } else {
      if (kt) {
        onError(tagToken, "BAD_COLLECTION_TYPE", `${kt.tag} used for ${expType} collection, but expects ${kt.collection ?? "scalar"}`, true);
      } else {
        onError(tagToken, "TAG_RESOLVE_FAILED", `Unresolved tag: ${tagName}`, true);
      }
      return resolveCollection(CN2, ctx, token, onError, tagName);
    }
  }
  const coll = resolveCollection(CN2, ctx, token, onError, tagName, tag);
  const res = tag.resolve?.(coll, (msg) => onError(tagToken, "TAG_RESOLVE_FAILED", msg), ctx.options) ?? coll;
  const node2 = isNode(res) ? res : new Scalar(res);
  node2.range = coll.range;
  node2.tag = tagName;
  if (tag?.format)
    node2.format = tag.format;
  return node2;
}

// node_modules/yaml/browser/dist/compose/resolve-block-scalar.js
function resolveBlockScalar(ctx, scalar, onError) {
  const start = scalar.offset;
  const header = parseBlockScalarHeader(scalar, ctx.options.strict, onError);
  if (!header)
    return { value: "", type: null, comment: "", range: [start, start, start] };
  const type = header.mode === ">" ? Scalar.BLOCK_FOLDED : Scalar.BLOCK_LITERAL;
  const lines = scalar.source ? splitLines(scalar.source) : [];
  let chompStart = lines.length;
  for (let i = lines.length - 1; i >= 0; --i) {
    const content = lines[i][1];
    if (content === "" || content === "\r")
      chompStart = i;
    else
      break;
  }
  if (chompStart === 0) {
    const value2 = header.chomp === "+" && lines.length > 0 ? "\n".repeat(Math.max(1, lines.length - 1)) : "";
    let end2 = start + header.length;
    if (scalar.source)
      end2 += scalar.source.length;
    return { value: value2, type, comment: header.comment, range: [start, end2, end2] };
  }
  let trimIndent = scalar.indent + header.indent;
  let offset = scalar.offset + header.length;
  let contentStart = 0;
  for (let i = 0; i < chompStart; ++i) {
    const [indent, content] = lines[i];
    if (content === "" || content === "\r") {
      if (header.indent === 0 && indent.length > trimIndent)
        trimIndent = indent.length;
    } else {
      if (indent.length < trimIndent) {
        const message = "Block scalars with more-indented leading empty lines must use an explicit indentation indicator";
        onError(offset + indent.length, "MISSING_CHAR", message);
      }
      if (header.indent === 0)
        trimIndent = indent.length;
      contentStart = i;
      if (trimIndent === 0 && !ctx.atRoot) {
        const message = "Block scalar values in collections must be indented";
        onError(offset, "BAD_INDENT", message);
      }
      break;
    }
    offset += indent.length + content.length + 1;
  }
  for (let i = lines.length - 1; i >= chompStart; --i) {
    if (lines[i][0].length > trimIndent)
      chompStart = i + 1;
  }
  let value = "";
  let sep = "";
  let prevMoreIndented = false;
  for (let i = 0; i < contentStart; ++i)
    value += lines[i][0].slice(trimIndent) + "\n";
  for (let i = contentStart; i < chompStart; ++i) {
    let [indent, content] = lines[i];
    offset += indent.length + content.length + 1;
    const crlf = content[content.length - 1] === "\r";
    if (crlf)
      content = content.slice(0, -1);
    if (content && indent.length < trimIndent) {
      const src = header.indent ? "explicit indentation indicator" : "first line";
      const message = `Block scalar lines must not be less indented than their ${src}`;
      onError(offset - content.length - (crlf ? 2 : 1), "BAD_INDENT", message);
      indent = "";
    }
    if (type === Scalar.BLOCK_LITERAL) {
      value += sep + indent.slice(trimIndent) + content;
      sep = "\n";
    } else if (indent.length > trimIndent || content[0] === "	") {
      if (sep === " ")
        sep = "\n";
      else if (!prevMoreIndented && sep === "\n")
        sep = "\n\n";
      value += sep + indent.slice(trimIndent) + content;
      sep = "\n";
      prevMoreIndented = true;
    } else if (content === "") {
      if (sep === "\n")
        value += "\n";
      else
        sep = "\n";
    } else {
      value += sep + content;
      sep = " ";
      prevMoreIndented = false;
    }
  }
  switch (header.chomp) {
    case "-":
      break;
    case "+":
      for (let i = chompStart; i < lines.length; ++i)
        value += "\n" + lines[i][0].slice(trimIndent);
      if (value[value.length - 1] !== "\n")
        value += "\n";
      break;
    default:
      value += "\n";
  }
  const end = start + header.length + scalar.source.length;
  return { value, type, comment: header.comment, range: [start, end, end] };
}
function parseBlockScalarHeader({ offset, props }, strict, onError) {
  if (props[0].type !== "block-scalar-header") {
    onError(props[0], "IMPOSSIBLE", "Block scalar header not found");
    return null;
  }
  const { source } = props[0];
  const mode = source[0];
  let indent = 0;
  let chomp = "";
  let error = -1;
  for (let i = 1; i < source.length; ++i) {
    const ch = source[i];
    if (!chomp && (ch === "-" || ch === "+"))
      chomp = ch;
    else {
      const n = Number(ch);
      if (!indent && n)
        indent = n;
      else if (error === -1)
        error = offset + i;
    }
  }
  if (error !== -1)
    onError(error, "UNEXPECTED_TOKEN", `Block scalar header includes extra characters: ${source}`);
  let hasSpace = false;
  let comment = "";
  let length = source.length;
  for (let i = 1; i < props.length; ++i) {
    const token = props[i];
    switch (token.type) {
      case "space":
        hasSpace = true;
      // fallthrough
      case "newline":
        length += token.source.length;
        break;
      case "comment":
        if (strict && !hasSpace) {
          const message = "Comments must be separated from other tokens by white space characters";
          onError(token, "MISSING_CHAR", message);
        }
        length += token.source.length;
        comment = token.source.substring(1);
        break;
      case "error":
        onError(token, "UNEXPECTED_TOKEN", token.message);
        length += token.source.length;
        break;
      /* istanbul ignore next should not happen */
      default: {
        const message = `Unexpected token in block scalar header: ${token.type}`;
        onError(token, "UNEXPECTED_TOKEN", message);
        const ts = token.source;
        if (ts && typeof ts === "string")
          length += ts.length;
      }
    }
  }
  return { mode, indent, chomp, comment, length };
}
function splitLines(source) {
  const split = source.split(/\n( *)/);
  const first = split[0];
  const m = first.match(/^( *)/);
  const line0 = m?.[1] ? [m[1], first.slice(m[1].length)] : ["", first];
  const lines = [line0];
  for (let i = 1; i < split.length; i += 2)
    lines.push([split[i], split[i + 1]]);
  return lines;
}

// node_modules/yaml/browser/dist/compose/resolve-flow-scalar.js
function resolveFlowScalar(scalar, strict, onError) {
  const { offset, type, source, end } = scalar;
  let _type;
  let value;
  const _onError = (rel, code, msg) => onError(offset + rel, code, msg);
  switch (type) {
    case "scalar":
      _type = Scalar.PLAIN;
      value = plainValue(source, _onError);
      break;
    case "single-quoted-scalar":
      _type = Scalar.QUOTE_SINGLE;
      value = singleQuotedValue(source, _onError);
      break;
    case "double-quoted-scalar":
      _type = Scalar.QUOTE_DOUBLE;
      value = doubleQuotedValue(source, _onError);
      break;
    /* istanbul ignore next should not happen */
    default:
      onError(scalar, "UNEXPECTED_TOKEN", `Expected a flow scalar value, but found: ${type}`);
      return {
        value: "",
        type: null,
        comment: "",
        range: [offset, offset + source.length, offset + source.length]
      };
  }
  const valueEnd = offset + source.length;
  const re = resolveEnd(end, valueEnd, strict, onError);
  return {
    value,
    type: _type,
    comment: re.comment,
    range: [offset, valueEnd, re.offset]
  };
}
function plainValue(source, onError) {
  let badChar = "";
  switch (source[0]) {
    /* istanbul ignore next should not happen */
    case "	":
      badChar = "a tab character";
      break;
    case ",":
      badChar = "flow indicator character ,";
      break;
    case "%":
      badChar = "directive indicator character %";
      break;
    case "|":
    case ">": {
      badChar = `block scalar indicator ${source[0]}`;
      break;
    }
    case "@":
    case "`": {
      badChar = `reserved character ${source[0]}`;
      break;
    }
  }
  if (badChar)
    onError(0, "BAD_SCALAR_START", `Plain value cannot start with ${badChar}`);
  return unfoldLines(source);
}
function singleQuotedValue(source, onError) {
  if (source[source.length - 1] !== "'" || source.length === 1)
    onError(source.length, "MISSING_CHAR", "Missing closing 'quote");
  return unfoldLines(source.slice(1, -1)).replace(/''/g, "'");
}
function unfoldLines(source) {
  const line = /(.*?)\r?\n/sy;
  let match = line.exec(source);
  if (!match)
    return source;
  let trimEnd, trimBoth;
  try {
    trimEnd = new RegExp("(?<![ 	])[ 	]+$");
    trimBoth = new RegExp("^[ 	]+|(?<![ 	])[ 	]+$", "g");
  } catch {
    trimEnd = /[ \t]+$/;
    trimBoth = /^[ \t]+|[ \t]+$/g;
  }
  let res = match[1].replace(trimEnd, "");
  let sep = " ";
  let pos = line.lastIndex;
  while (match = line.exec(source)) {
    const lm = match[1].replace(trimBoth, "");
    if (lm === "") {
      if (sep === "\n")
        res += sep;
      else
        sep = "\n";
    } else {
      res += sep + lm;
      sep = " ";
    }
    pos = line.lastIndex;
  }
  const last = /[ \t]*(.*)/sy;
  last.lastIndex = pos;
  match = last.exec(source);
  return res + sep + (match?.[1] ?? "");
}
function doubleQuotedValue(source, onError) {
  let res = "";
  for (let i = 1; i < source.length - 1; ++i) {
    const ch = source[i];
    if (ch === "\r" && source[i + 1] === "\n")
      continue;
    if (ch === "\n") {
      const { fold, offset } = foldNewline(source, i);
      res += fold;
      i = offset;
    } else if (ch === "\\") {
      let next2 = source[++i];
      const cc = escapeCodes[next2];
      if (cc)
        res += cc;
      else if (next2 === "\n") {
        next2 = source[i + 1];
        while (next2 === " " || next2 === "	")
          next2 = source[++i + 1];
      } else if (next2 === "\r" && source[i + 1] === "\n") {
        next2 = source[++i + 1];
        while (next2 === " " || next2 === "	")
          next2 = source[++i + 1];
      } else if (next2 === "x" || next2 === "u" || next2 === "U") {
        const length = next2 === "x" ? 2 : next2 === "u" ? 4 : 8;
        res += parseCharCode(source, i + 1, length, onError);
        i += length;
      } else {
        const raw = source.substr(i - 1, 2);
        onError(i - 1, "BAD_DQ_ESCAPE", `Invalid escape sequence ${raw}`);
        res += raw;
      }
    } else if (ch === " " || ch === "	") {
      const wsStart = i;
      let next2 = source[i + 1];
      while (next2 === " " || next2 === "	")
        next2 = source[++i + 1];
      if (next2 !== "\n" && !(next2 === "\r" && source[i + 2] === "\n"))
        res += i > wsStart ? source.slice(wsStart, i + 1) : ch;
    } else {
      res += ch;
    }
  }
  if (source[source.length - 1] !== '"' || source.length === 1)
    onError(source.length, "MISSING_CHAR", 'Missing closing "quote');
  return res;
}
function foldNewline(source, offset) {
  let fold = "";
  let ch = source[offset + 1];
  while (ch === " " || ch === "	" || ch === "\n" || ch === "\r") {
    if (ch === "\r" && source[offset + 2] !== "\n")
      break;
    if (ch === "\n")
      fold += "\n";
    offset += 1;
    ch = source[offset + 1];
  }
  if (!fold)
    fold = " ";
  return { fold, offset };
}
var escapeCodes = {
  "0": "\0",
  // null character
  a: "\x07",
  // bell character
  b: "\b",
  // backspace
  e: "\x1B",
  // escape character
  f: "\f",
  // form feed
  n: "\n",
  // line feed
  r: "\r",
  // carriage return
  t: "	",
  // horizontal tab
  v: "\v",
  // vertical tab
  N: "\x85",
  // Unicode next line
  _: "\xA0",
  // Unicode non-breaking space
  L: "\u2028",
  // Unicode line separator
  P: "\u2029",
  // Unicode paragraph separator
  " ": " ",
  '"': '"',
  "/": "/",
  "\\": "\\",
  "	": "	"
};
function parseCharCode(source, offset, length, onError) {
  const cc = source.substr(offset, length);
  const ok = cc.length === length && /^[0-9a-fA-F]+$/.test(cc);
  const code = ok ? parseInt(cc, 16) : NaN;
  try {
    return String.fromCodePoint(code);
  } catch {
    const raw = source.substr(offset - 2, length + 2);
    onError(offset - 2, "BAD_DQ_ESCAPE", `Invalid escape sequence ${raw}`);
    return raw;
  }
}

// node_modules/yaml/browser/dist/compose/compose-scalar.js
function composeScalar(ctx, token, tagToken, onError) {
  const { value, type, comment, range } = token.type === "block-scalar" ? resolveBlockScalar(ctx, token, onError) : resolveFlowScalar(token, ctx.options.strict, onError);
  const tagName = tagToken ? ctx.directives.tagName(tagToken.source, (msg) => onError(tagToken, "TAG_RESOLVE_FAILED", msg)) : null;
  let tag;
  if (ctx.options.stringKeys && ctx.atKey) {
    tag = ctx.schema[SCALAR];
  } else if (tagName)
    tag = findScalarTagByName(ctx.schema, value, tagName, tagToken, onError);
  else if (token.type === "scalar")
    tag = findScalarTagByTest(ctx, value, token, onError);
  else
    tag = ctx.schema[SCALAR];
  let scalar;
  try {
    const res = tag.resolve(value, (msg) => onError(tagToken ?? token, "TAG_RESOLVE_FAILED", msg), ctx.options);
    scalar = isScalar(res) ? res : new Scalar(res);
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    onError(tagToken ?? token, "TAG_RESOLVE_FAILED", msg);
    scalar = new Scalar(value);
  }
  scalar.range = range;
  scalar.source = value;
  if (type)
    scalar.type = type;
  if (tagName)
    scalar.tag = tagName;
  if (tag.format)
    scalar.format = tag.format;
  if (comment)
    scalar.comment = comment;
  return scalar;
}
function findScalarTagByName(schema4, value, tagName, tagToken, onError) {
  if (tagName === "!")
    return schema4[SCALAR];
  const matchWithTest = [];
  for (const tag of schema4.tags) {
    if (!tag.collection && tag.tag === tagName) {
      if (tag.default && tag.test)
        matchWithTest.push(tag);
      else
        return tag;
    }
  }
  for (const tag of matchWithTest)
    if (tag.test?.test(value))
      return tag;
  const kt = schema4.knownTags[tagName];
  if (kt && !kt.collection) {
    schema4.tags.push(Object.assign({}, kt, { default: false, test: void 0 }));
    return kt;
  }
  onError(tagToken, "TAG_RESOLVE_FAILED", `Unresolved tag: ${tagName}`, tagName !== "tag:yaml.org,2002:str");
  return schema4[SCALAR];
}
function findScalarTagByTest({ atKey, directives, schema: schema4 }, value, token, onError) {
  const tag = schema4.tags.find((tag2) => (tag2.default === true || atKey && tag2.default === "key") && tag2.test?.test(value)) || schema4[SCALAR];
  if (schema4.compat) {
    const compat = schema4.compat.find((tag2) => tag2.default && tag2.test?.test(value)) ?? schema4[SCALAR];
    if (tag.tag !== compat.tag) {
      const ts = directives.tagString(tag.tag);
      const cs = directives.tagString(compat.tag);
      const msg = `Value may be parsed as either ${ts} or ${cs}`;
      onError(token, "TAG_RESOLVE_FAILED", msg, true);
    }
  }
  return tag;
}

// node_modules/yaml/browser/dist/compose/util-empty-scalar-position.js
function emptyScalarPosition(offset, before, pos) {
  if (before) {
    pos ?? (pos = before.length);
    for (let i = pos - 1; i >= 0; --i) {
      let st = before[i];
      switch (st.type) {
        case "space":
        case "comment":
        case "newline":
          offset -= st.source.length;
          continue;
      }
      st = before[++i];
      while (st?.type === "space") {
        offset += st.source.length;
        st = before[++i];
      }
      break;
    }
  }
  return offset;
}

// node_modules/yaml/browser/dist/compose/compose-node.js
var CN = { composeNode, composeEmptyNode };
function composeNode(ctx, token, props, onError) {
  const atKey = ctx.atKey;
  const { spaceBefore, comment, anchor, tag } = props;
  let node2;
  let isSrcToken = true;
  switch (token.type) {
    case "alias":
      node2 = composeAlias(ctx, token, onError);
      if (anchor || tag)
        onError(token, "ALIAS_PROPS", "An alias node must not specify any properties");
      break;
    case "scalar":
    case "single-quoted-scalar":
    case "double-quoted-scalar":
    case "block-scalar":
      node2 = composeScalar(ctx, token, tag, onError);
      if (anchor)
        node2.anchor = anchor.source.substring(1);
      break;
    case "block-map":
    case "block-seq":
    case "flow-collection":
      try {
        node2 = composeCollection(CN, ctx, token, props, onError);
        if (anchor)
          node2.anchor = anchor.source.substring(1);
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        onError(token, "RESOURCE_EXHAUSTION", message);
      }
      break;
    default: {
      const message = token.type === "error" ? token.message : `Unsupported token (type: ${token.type})`;
      onError(token, "UNEXPECTED_TOKEN", message);
      isSrcToken = false;
    }
  }
  node2 ?? (node2 = composeEmptyNode(ctx, token.offset, void 0, null, props, onError));
  if (anchor && node2.anchor === "")
    onError(anchor, "BAD_ALIAS", "Anchor cannot be an empty string");
  if (atKey && ctx.options.stringKeys && (!isScalar(node2) || typeof node2.value !== "string" || node2.tag && node2.tag !== "tag:yaml.org,2002:str")) {
    const msg = "With stringKeys, all keys must be strings";
    onError(tag ?? token, "NON_STRING_KEY", msg);
  }
  if (spaceBefore)
    node2.spaceBefore = true;
  if (comment) {
    if (token.type === "scalar" && token.source === "")
      node2.comment = comment;
    else
      node2.commentBefore = comment;
  }
  if (ctx.options.keepSourceTokens && isSrcToken)
    node2.srcToken = token;
  return node2;
}
function composeEmptyNode(ctx, offset, before, pos, { spaceBefore, comment, anchor, tag, end }, onError) {
  const token = {
    type: "scalar",
    offset: emptyScalarPosition(offset, before, pos),
    indent: -1,
    source: ""
  };
  const node2 = composeScalar(ctx, token, tag, onError);
  if (anchor) {
    node2.anchor = anchor.source.substring(1);
    if (node2.anchor === "")
      onError(anchor, "BAD_ALIAS", "Anchor cannot be an empty string");
  }
  if (spaceBefore)
    node2.spaceBefore = true;
  if (comment) {
    node2.comment = comment;
    node2.range[2] = end;
  }
  return node2;
}
function composeAlias({ options }, { offset, source, end }, onError) {
  const alias = new Alias(source.substring(1));
  if (alias.source === "")
    onError(offset, "BAD_ALIAS", "Alias cannot be an empty string");
  if (alias.source.endsWith(":"))
    onError(offset + source.length - 1, "BAD_ALIAS", "Alias ending in : is ambiguous", true);
  const valueEnd = offset + source.length;
  const re = resolveEnd(end, valueEnd, options.strict, onError);
  alias.range = [offset, valueEnd, re.offset];
  if (re.comment)
    alias.comment = re.comment;
  return alias;
}

// node_modules/yaml/browser/dist/compose/compose-doc.js
function composeDoc(options, directives, { offset, start, value, end }, onError) {
  const opts = Object.assign({ _directives: directives }, options);
  const doc = new Document(void 0, opts);
  const ctx = {
    atKey: false,
    atRoot: true,
    directives: doc.directives,
    options: doc.options,
    schema: doc.schema
  };
  const props = resolveProps(start, {
    indicator: "doc-start",
    next: value ?? end?.[0],
    offset,
    onError,
    parentIndent: 0,
    startOnNewline: true
  });
  if (props.found) {
    doc.directives.docStart = true;
    if (value && (value.type === "block-map" || value.type === "block-seq") && !props.hasNewline)
      onError(props.end, "MISSING_CHAR", "Block collection cannot start on same line with directives-end marker");
  }
  doc.contents = value ? composeNode(ctx, value, props, onError) : composeEmptyNode(ctx, props.end, start, null, props, onError);
  const contentEnd = doc.contents.range[2];
  const re = resolveEnd(end, contentEnd, false, onError);
  if (re.comment)
    doc.comment = re.comment;
  doc.range = [offset, contentEnd, re.offset];
  return doc;
}

// node_modules/yaml/browser/dist/compose/composer.js
function getErrorPos(src) {
  if (typeof src === "number")
    return [src, src + 1];
  if (Array.isArray(src))
    return src.length === 2 ? src : [src[0], src[1]];
  const { offset, source } = src;
  return [offset, offset + (typeof source === "string" ? source.length : 1)];
}
function parsePrelude(prelude) {
  let comment = "";
  let atComment = false;
  let afterEmptyLine = false;
  for (let i = 0; i < prelude.length; ++i) {
    const source = prelude[i];
    switch (source[0]) {
      case "#":
        comment += (comment === "" ? "" : afterEmptyLine ? "\n\n" : "\n") + (source.substring(1) || " ");
        atComment = true;
        afterEmptyLine = false;
        break;
      case "%":
        if (prelude[i + 1]?.[0] !== "#")
          i += 1;
        atComment = false;
        break;
      default:
        if (!atComment)
          afterEmptyLine = true;
        atComment = false;
    }
  }
  return { comment, afterEmptyLine };
}
var Composer = class {
  constructor(options = {}) {
    this.doc = null;
    this.atDirectives = false;
    this.prelude = [];
    this.errors = [];
    this.warnings = [];
    this.onError = (source, code, message, warning) => {
      const pos = getErrorPos(source);
      if (warning)
        this.warnings.push(new YAMLWarning(pos, code, message));
      else
        this.errors.push(new YAMLParseError(pos, code, message));
    };
    this.directives = new Directives({ version: options.version || "1.2" });
    this.options = options;
  }
  decorate(doc, afterDoc) {
    const { comment, afterEmptyLine } = parsePrelude(this.prelude);
    if (comment) {
      const dc = doc.contents;
      if (afterDoc) {
        doc.comment = doc.comment ? `${doc.comment}
${comment}` : comment;
      } else if (afterEmptyLine || doc.directives.docStart || !dc) {
        doc.commentBefore = comment;
      } else if (isCollection(dc) && !dc.flow && dc.items.length > 0) {
        let it = dc.items[0];
        if (isPair(it))
          it = it.key;
        const cb = it.commentBefore;
        it.commentBefore = cb ? `${comment}
${cb}` : comment;
      } else {
        const cb = dc.commentBefore;
        dc.commentBefore = cb ? `${comment}
${cb}` : comment;
      }
    }
    if (afterDoc) {
      for (let i = 0; i < this.errors.length; ++i)
        doc.errors.push(this.errors[i]);
      for (let i = 0; i < this.warnings.length; ++i)
        doc.warnings.push(this.warnings[i]);
    } else {
      doc.errors = this.errors;
      doc.warnings = this.warnings;
    }
    this.prelude = [];
    this.errors = [];
    this.warnings = [];
  }
  /**
   * Current stream status information.
   *
   * Mostly useful at the end of input for an empty stream.
   */
  streamInfo() {
    return {
      comment: parsePrelude(this.prelude).comment,
      directives: this.directives,
      errors: this.errors,
      warnings: this.warnings
    };
  }
  /**
   * Compose tokens into documents.
   *
   * @param forceDoc - If the stream contains no document, still emit a final document including any comments and directives that would be applied to a subsequent document.
   * @param endOffset - Should be set if `forceDoc` is also set, to set the document range end and to indicate errors correctly.
   */
  *compose(tokens, forceDoc = false, endOffset = -1) {
    for (const token of tokens)
      yield* this.next(token);
    yield* this.end(forceDoc, endOffset);
  }
  /** Advance the composer by one CST token. */
  *next(token) {
    switch (token.type) {
      case "directive":
        this.directives.add(token.source, (offset, message, warning) => {
          const pos = getErrorPos(token);
          pos[0] += offset;
          this.onError(pos, "BAD_DIRECTIVE", message, warning);
        });
        this.prelude.push(token.source);
        this.atDirectives = true;
        break;
      case "document": {
        const doc = composeDoc(this.options, this.directives, token, this.onError);
        if (this.atDirectives && !doc.directives.docStart)
          this.onError(token, "MISSING_CHAR", "Missing directives-end/doc-start indicator line");
        this.decorate(doc, false);
        if (this.doc)
          yield this.doc;
        this.doc = doc;
        this.atDirectives = false;
        break;
      }
      case "byte-order-mark":
      case "space":
        break;
      case "comment":
      case "newline":
        this.prelude.push(token.source);
        break;
      case "error": {
        const msg = token.source ? `${token.message}: ${JSON.stringify(token.source)}` : token.message;
        const error = new YAMLParseError(getErrorPos(token), "UNEXPECTED_TOKEN", msg);
        if (this.atDirectives || !this.doc)
          this.errors.push(error);
        else
          this.doc.errors.push(error);
        break;
      }
      case "doc-end": {
        if (!this.doc) {
          const msg = "Unexpected doc-end without preceding document";
          this.errors.push(new YAMLParseError(getErrorPos(token), "UNEXPECTED_TOKEN", msg));
          break;
        }
        this.doc.directives.docEnd = true;
        const end = resolveEnd(token.end, token.offset + token.source.length, this.doc.options.strict, this.onError);
        this.decorate(this.doc, true);
        if (end.comment) {
          const dc = this.doc.comment;
          this.doc.comment = dc ? `${dc}
${end.comment}` : end.comment;
        }
        this.doc.range[2] = end.offset;
        break;
      }
      default:
        this.errors.push(new YAMLParseError(getErrorPos(token), "UNEXPECTED_TOKEN", `Unsupported token ${token.type}`));
    }
  }
  /**
   * Call at end of input to yield any remaining document.
   *
   * @param forceDoc - If the stream contains no document, still emit a final document including any comments and directives that would be applied to a subsequent document.
   * @param endOffset - Should be set if `forceDoc` is also set, to set the document range end and to indicate errors correctly.
   */
  *end(forceDoc = false, endOffset = -1) {
    if (this.doc) {
      this.decorate(this.doc, true);
      yield this.doc;
      this.doc = null;
    } else if (forceDoc) {
      const opts = Object.assign({ _directives: this.directives }, this.options);
      const doc = new Document(void 0, opts);
      if (this.atDirectives)
        this.onError(endOffset, "MISSING_CHAR", "Missing directives-end indicator line");
      doc.range = [0, endOffset, endOffset];
      this.decorate(doc, false);
      yield doc;
    }
  }
};

// node_modules/yaml/browser/dist/parse/cst.js
var cst_exports = {};
__export(cst_exports, {
  BOM: () => BOM,
  DOCUMENT: () => DOCUMENT,
  FLOW_END: () => FLOW_END,
  SCALAR: () => SCALAR2,
  createScalarToken: () => createScalarToken,
  isCollection: () => isCollection2,
  isScalar: () => isScalar2,
  prettyToken: () => prettyToken,
  resolveAsScalar: () => resolveAsScalar,
  setScalarValue: () => setScalarValue,
  stringify: () => stringify2,
  tokenType: () => tokenType,
  visit: () => visit2
});

// node_modules/yaml/browser/dist/parse/cst-scalar.js
function resolveAsScalar(token, strict = true, onError) {
  if (token) {
    const _onError = (pos, code, message) => {
      const offset = typeof pos === "number" ? pos : Array.isArray(pos) ? pos[0] : pos.offset;
      if (onError)
        onError(offset, code, message);
      else
        throw new YAMLParseError([offset, offset + 1], code, message);
    };
    switch (token.type) {
      case "scalar":
      case "single-quoted-scalar":
      case "double-quoted-scalar":
        return resolveFlowScalar(token, strict, _onError);
      case "block-scalar":
        return resolveBlockScalar({ options: { strict } }, token, _onError);
    }
  }
  return null;
}
function createScalarToken(value, context) {
  const { implicitKey = false, indent, inFlow = false, offset = -1, type = "PLAIN" } = context;
  const source = stringifyString({ type, value }, {
    implicitKey,
    indent: indent > 0 ? " ".repeat(indent) : "",
    inFlow,
    options: { blockQuote: true, lineWidth: -1 }
  });
  const end = context.end ?? [
    { type: "newline", offset: -1, indent, source: "\n" }
  ];
  switch (source[0]) {
    case "|":
    case ">": {
      const he = source.indexOf("\n");
      const head = source.substring(0, he);
      const body = source.substring(he + 1) + "\n";
      const props = [
        { type: "block-scalar-header", offset, indent, source: head }
      ];
      if (!addEndtoBlockProps(props, end))
        props.push({ type: "newline", offset: -1, indent, source: "\n" });
      return { type: "block-scalar", offset, indent, props, source: body };
    }
    case '"':
      return { type: "double-quoted-scalar", offset, indent, source, end };
    case "'":
      return { type: "single-quoted-scalar", offset, indent, source, end };
    default:
      return { type: "scalar", offset, indent, source, end };
  }
}
function setScalarValue(token, value, context = {}) {
  let { afterKey = false, implicitKey = false, inFlow = false, type } = context;
  let indent = "indent" in token ? token.indent : null;
  if (afterKey && typeof indent === "number")
    indent += 2;
  if (!type)
    switch (token.type) {
      case "single-quoted-scalar":
        type = "QUOTE_SINGLE";
        break;
      case "double-quoted-scalar":
        type = "QUOTE_DOUBLE";
        break;
      case "block-scalar": {
        const header = token.props[0];
        if (header.type !== "block-scalar-header")
          throw new Error("Invalid block scalar header");
        type = header.source[0] === ">" ? "BLOCK_FOLDED" : "BLOCK_LITERAL";
        break;
      }
      default:
        type = "PLAIN";
    }
  const source = stringifyString({ type, value }, {
    implicitKey: implicitKey || indent === null,
    indent: indent !== null && indent > 0 ? " ".repeat(indent) : "",
    inFlow,
    options: { blockQuote: true, lineWidth: -1 }
  });
  switch (source[0]) {
    case "|":
    case ">":
      setBlockScalarValue(token, source);
      break;
    case '"':
      setFlowScalarValue(token, source, "double-quoted-scalar");
      break;
    case "'":
      setFlowScalarValue(token, source, "single-quoted-scalar");
      break;
    default:
      setFlowScalarValue(token, source, "scalar");
  }
}
function setBlockScalarValue(token, source) {
  const he = source.indexOf("\n");
  const head = source.substring(0, he);
  const body = source.substring(he + 1) + "\n";
  if (token.type === "block-scalar") {
    const header = token.props[0];
    if (header.type !== "block-scalar-header")
      throw new Error("Invalid block scalar header");
    header.source = head;
    token.source = body;
  } else {
    const { offset } = token;
    const indent = "indent" in token ? token.indent : -1;
    const props = [
      { type: "block-scalar-header", offset, indent, source: head }
    ];
    if (!addEndtoBlockProps(props, "end" in token ? token.end : void 0))
      props.push({ type: "newline", offset: -1, indent, source: "\n" });
    for (const key of Object.keys(token))
      if (key !== "type" && key !== "offset")
        delete token[key];
    Object.assign(token, { type: "block-scalar", indent, props, source: body });
  }
}
function addEndtoBlockProps(props, end) {
  if (end)
    for (const st of end)
      switch (st.type) {
        case "space":
        case "comment":
          props.push(st);
          break;
        case "newline":
          props.push(st);
          return true;
      }
  return false;
}
function setFlowScalarValue(token, source, type) {
  switch (token.type) {
    case "scalar":
    case "double-quoted-scalar":
    case "single-quoted-scalar":
      token.type = type;
      token.source = source;
      break;
    case "block-scalar": {
      const end = token.props.slice(1);
      let oa = source.length;
      if (token.props[0].type === "block-scalar-header")
        oa -= token.props[0].source.length;
      for (const tok of end)
        tok.offset += oa;
      delete token.props;
      Object.assign(token, { type, source, end });
      break;
    }
    case "block-map":
    case "block-seq": {
      const offset = token.offset + source.length;
      const nl = { type: "newline", offset, indent: token.indent, source: "\n" };
      delete token.items;
      Object.assign(token, { type, source, end: [nl] });
      break;
    }
    default: {
      const indent = "indent" in token ? token.indent : -1;
      const end = "end" in token && Array.isArray(token.end) ? token.end.filter((st) => st.type === "space" || st.type === "comment" || st.type === "newline") : [];
      for (const key of Object.keys(token))
        if (key !== "type" && key !== "offset")
          delete token[key];
      Object.assign(token, { type, indent, source, end });
    }
  }
}

// node_modules/yaml/browser/dist/parse/cst-stringify.js
var stringify2 = (cst) => "type" in cst ? stringifyToken(cst) : stringifyItem(cst);
function stringifyToken(token) {
  switch (token.type) {
    case "block-scalar": {
      let res = "";
      for (const tok of token.props)
        res += stringifyToken(tok);
      return res + token.source;
    }
    case "block-map":
    case "block-seq": {
      let res = "";
      for (const item of token.items)
        res += stringifyItem(item);
      return res;
    }
    case "flow-collection": {
      let res = token.start.source;
      for (const item of token.items)
        res += stringifyItem(item);
      for (const st of token.end)
        res += st.source;
      return res;
    }
    case "document": {
      let res = stringifyItem(token);
      if (token.end)
        for (const st of token.end)
          res += st.source;
      return res;
    }
    default: {
      let res = token.source;
      if ("end" in token && token.end)
        for (const st of token.end)
          res += st.source;
      return res;
    }
  }
}
function stringifyItem({ start, key, sep, value }) {
  let res = "";
  for (const st of start)
    res += st.source;
  if (key)
    res += stringifyToken(key);
  if (sep)
    for (const st of sep)
      res += st.source;
  if (value)
    res += stringifyToken(value);
  return res;
}

// node_modules/yaml/browser/dist/parse/cst-visit.js
var BREAK2 = Symbol("break visit");
var SKIP2 = Symbol("skip children");
var REMOVE2 = Symbol("remove item");
function visit2(cst, visitor) {
  if ("type" in cst && cst.type === "document")
    cst = { start: cst.start, value: cst.value };
  _visit(Object.freeze([]), cst, visitor);
}
visit2.BREAK = BREAK2;
visit2.SKIP = SKIP2;
visit2.REMOVE = REMOVE2;
visit2.itemAtPath = (cst, path) => {
  let item = cst;
  for (const [field, index] of path) {
    const tok = item?.[field];
    if (tok && "items" in tok) {
      item = tok.items[index];
    } else
      return void 0;
  }
  return item;
};
visit2.parentCollection = (cst, path) => {
  const parent = visit2.itemAtPath(cst, path.slice(0, -1));
  const field = path[path.length - 1][0];
  const coll = parent?.[field];
  if (coll && "items" in coll)
    return coll;
  throw new Error("Parent collection not found");
};
function _visit(path, item, visitor) {
  let ctrl = visitor(item, path);
  if (typeof ctrl === "symbol")
    return ctrl;
  for (const field of ["key", "value"]) {
    const token = item[field];
    if (token && "items" in token) {
      for (let i = 0; i < token.items.length; ++i) {
        const ci = _visit(Object.freeze(path.concat([[field, i]])), token.items[i], visitor);
        if (typeof ci === "number")
          i = ci - 1;
        else if (ci === BREAK2)
          return BREAK2;
        else if (ci === REMOVE2) {
          token.items.splice(i, 1);
          i -= 1;
        }
      }
      if (typeof ctrl === "function" && field === "key")
        ctrl = ctrl(item, path);
    }
  }
  return typeof ctrl === "function" ? ctrl(item, path) : ctrl;
}

// node_modules/yaml/browser/dist/parse/cst.js
var BOM = "\uFEFF";
var DOCUMENT = "";
var FLOW_END = "";
var SCALAR2 = "";
var isCollection2 = (token) => !!token && "items" in token;
var isScalar2 = (token) => !!token && (token.type === "scalar" || token.type === "single-quoted-scalar" || token.type === "double-quoted-scalar" || token.type === "block-scalar");
function prettyToken(token) {
  switch (token) {
    case BOM:
      return "<BOM>";
    case DOCUMENT:
      return "<DOC>";
    case FLOW_END:
      return "<FLOW_END>";
    case SCALAR2:
      return "<SCALAR>";
    default:
      return JSON.stringify(token);
  }
}
function tokenType(source) {
  switch (source) {
    case BOM:
      return "byte-order-mark";
    case DOCUMENT:
      return "doc-mode";
    case FLOW_END:
      return "flow-error-end";
    case SCALAR2:
      return "scalar";
    case "---":
      return "doc-start";
    case "...":
      return "doc-end";
    case "":
    case "\n":
    case "\r\n":
      return "newline";
    case "-":
      return "seq-item-ind";
    case "?":
      return "explicit-key-ind";
    case ":":
      return "map-value-ind";
    case "{":
      return "flow-map-start";
    case "}":
      return "flow-map-end";
    case "[":
      return "flow-seq-start";
    case "]":
      return "flow-seq-end";
    case ",":
      return "comma";
  }
  switch (source[0]) {
    case " ":
    case "	":
      return "space";
    case "#":
      return "comment";
    case "%":
      return "directive-line";
    case "*":
      return "alias";
    case "&":
      return "anchor";
    case "!":
      return "tag";
    case "'":
      return "single-quoted-scalar";
    case '"':
      return "double-quoted-scalar";
    case "|":
    case ">":
      return "block-scalar-header";
  }
  return null;
}

// node_modules/yaml/browser/dist/parse/lexer.js
function isEmpty(ch) {
  switch (ch) {
    case void 0:
    case " ":
    case "\n":
    case "\r":
    case "	":
      return true;
    default:
      return false;
  }
}
var hexDigits = new Set("0123456789ABCDEFabcdef");
var tagChars = new Set("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-#;/?:@&=+$_.!~*'()");
var flowIndicatorChars = new Set(",[]{}");
var invalidAnchorChars = new Set(" ,[]{}\n\r	");
var isNotAnchorChar = (ch) => !ch || invalidAnchorChars.has(ch);
var Lexer = class {
  constructor() {
    this.atEnd = false;
    this.blockScalarIndent = -1;
    this.blockScalarKeep = false;
    this.buffer = "";
    this.flowKey = false;
    this.flowLevel = 0;
    this.indentNext = 0;
    this.indentValue = 0;
    this.lineEndPos = null;
    this.next = null;
    this.pos = 0;
  }
  /**
   * Generate YAML tokens from the `source` string. If `incomplete`,
   * a part of the last line may be left as a buffer for the next call.
   *
   * @returns A generator of lexical tokens
   */
  *lex(source, incomplete = false) {
    if (source) {
      if (typeof source !== "string")
        throw TypeError("source is not a string");
      this.buffer = this.buffer ? this.buffer + source : source;
      this.lineEndPos = null;
    }
    this.atEnd = !incomplete;
    let next2 = this.next ?? "stream";
    while (next2 && (incomplete || this.hasChars(1)))
      next2 = yield* this.parseNext(next2);
  }
  atLineEnd() {
    let i = this.pos;
    let ch = this.buffer[i];
    while (ch === " " || ch === "	")
      ch = this.buffer[++i];
    if (!ch || ch === "#" || ch === "\n")
      return true;
    if (ch === "\r")
      return this.buffer[i + 1] === "\n";
    return false;
  }
  charAt(n) {
    return this.buffer[this.pos + n];
  }
  continueScalar(offset) {
    let ch = this.buffer[offset];
    if (this.indentNext > 0) {
      let indent = 0;
      while (ch === " ")
        ch = this.buffer[++indent + offset];
      if (ch === "\r") {
        const next2 = this.buffer[indent + offset + 1];
        if (next2 === "\n" || !next2 && !this.atEnd)
          return offset + indent + 1;
      }
      return ch === "\n" || indent >= this.indentNext || !ch && !this.atEnd ? offset + indent : -1;
    }
    if (ch === "-" || ch === ".") {
      const dt = this.buffer.substr(offset, 3);
      if ((dt === "---" || dt === "...") && isEmpty(this.buffer[offset + 3]))
        return -1;
    }
    return offset;
  }
  getLine() {
    let end = this.lineEndPos;
    if (typeof end !== "number" || end !== -1 && end < this.pos) {
      end = this.buffer.indexOf("\n", this.pos);
      this.lineEndPos = end;
    }
    if (end === -1)
      return this.atEnd ? this.buffer.substring(this.pos) : null;
    if (this.buffer[end - 1] === "\r")
      end -= 1;
    return this.buffer.substring(this.pos, end);
  }
  hasChars(n) {
    return this.pos + n <= this.buffer.length;
  }
  setNext(state) {
    this.buffer = this.buffer.substring(this.pos);
    this.pos = 0;
    this.lineEndPos = null;
    this.next = state;
    return null;
  }
  peek(n) {
    return this.buffer.substr(this.pos, n);
  }
  *parseNext(next2) {
    switch (next2) {
      case "stream":
        return yield* this.parseStream();
      case "line-start":
        return yield* this.parseLineStart();
      case "block-start":
        return yield* this.parseBlockStart();
      case "doc":
        return yield* this.parseDocument();
      case "flow":
        return yield* this.parseFlowCollection();
      case "quoted-scalar":
        return yield* this.parseQuotedScalar();
      case "block-scalar":
        return yield* this.parseBlockScalar();
      case "plain-scalar":
        return yield* this.parsePlainScalar();
    }
  }
  *parseStream() {
    let line = this.getLine();
    if (line === null)
      return this.setNext("stream");
    if (line[0] === BOM) {
      yield* this.pushCount(1);
      line = line.substring(1);
    }
    if (line[0] === "%") {
      let dirEnd = line.length;
      let cs = line.indexOf("#");
      while (cs !== -1) {
        const ch = line[cs - 1];
        if (ch === " " || ch === "	") {
          dirEnd = cs - 1;
          break;
        } else {
          cs = line.indexOf("#", cs + 1);
        }
      }
      while (true) {
        const ch = line[dirEnd - 1];
        if (ch === " " || ch === "	")
          dirEnd -= 1;
        else
          break;
      }
      const n = (yield* this.pushCount(dirEnd)) + (yield* this.pushSpaces(true));
      yield* this.pushCount(line.length - n);
      this.pushNewline();
      return "stream";
    }
    if (this.atLineEnd()) {
      const sp = yield* this.pushSpaces(true);
      yield* this.pushCount(line.length - sp);
      yield* this.pushNewline();
      return "stream";
    }
    yield DOCUMENT;
    return yield* this.parseLineStart();
  }
  *parseLineStart() {
    const ch = this.charAt(0);
    if (!ch && !this.atEnd)
      return this.setNext("line-start");
    if (ch === "-" || ch === ".") {
      if (!this.atEnd && !this.hasChars(4))
        return this.setNext("line-start");
      const s = this.peek(3);
      if ((s === "---" || s === "...") && isEmpty(this.charAt(3))) {
        yield* this.pushCount(3);
        this.indentValue = 0;
        this.indentNext = 0;
        return s === "---" ? "doc" : "stream";
      }
    }
    this.indentValue = yield* this.pushSpaces(false);
    if (this.indentNext > this.indentValue && !isEmpty(this.charAt(1)))
      this.indentNext = this.indentValue;
    return yield* this.parseBlockStart();
  }
  *parseBlockStart() {
    const [ch0, ch1] = this.peek(2);
    if (!ch1 && !this.atEnd)
      return this.setNext("block-start");
    if ((ch0 === "-" || ch0 === "?" || ch0 === ":") && isEmpty(ch1)) {
      const n = (yield* this.pushCount(1)) + (yield* this.pushSpaces(true));
      this.indentNext = this.indentValue + 1;
      this.indentValue += n;
      return "block-start";
    }
    return "doc";
  }
  *parseDocument() {
    yield* this.pushSpaces(true);
    const line = this.getLine();
    if (line === null)
      return this.setNext("doc");
    let n = yield* this.pushIndicators();
    switch (line[n]) {
      case "#":
        yield* this.pushCount(line.length - n);
      // fallthrough
      case void 0:
        yield* this.pushNewline();
        return yield* this.parseLineStart();
      case "{":
      case "[":
        yield* this.pushCount(1);
        this.flowKey = false;
        this.flowLevel = 1;
        return "flow";
      case "}":
      case "]":
        yield* this.pushCount(1);
        return "doc";
      case "*":
        yield* this.pushUntil(isNotAnchorChar);
        return "doc";
      case '"':
      case "'":
        return yield* this.parseQuotedScalar();
      case "|":
      case ">":
        n += yield* this.parseBlockScalarHeader();
        n += yield* this.pushSpaces(true);
        yield* this.pushCount(line.length - n);
        yield* this.pushNewline();
        return yield* this.parseBlockScalar();
      default:
        return yield* this.parsePlainScalar();
    }
  }
  *parseFlowCollection() {
    let nl, sp;
    let indent = -1;
    do {
      nl = yield* this.pushNewline();
      if (nl > 0) {
        sp = yield* this.pushSpaces(false);
        this.indentValue = indent = sp;
      } else {
        sp = 0;
      }
      sp += yield* this.pushSpaces(true);
    } while (nl + sp > 0);
    const line = this.getLine();
    if (line === null)
      return this.setNext("flow");
    if (indent !== -1 && indent < this.indentNext && line[0] !== "#" || indent === 0 && (line.startsWith("---") || line.startsWith("...")) && isEmpty(line[3])) {
      const atFlowEndMarker = indent === this.indentNext - 1 && this.flowLevel === 1 && (line[0] === "]" || line[0] === "}");
      if (!atFlowEndMarker) {
        this.flowLevel = 0;
        yield FLOW_END;
        return yield* this.parseLineStart();
      }
    }
    let n = 0;
    while (line[n] === ",") {
      n += yield* this.pushCount(1);
      n += yield* this.pushSpaces(true);
      this.flowKey = false;
    }
    n += yield* this.pushIndicators();
    switch (line[n]) {
      case void 0:
        return "flow";
      case "#":
        yield* this.pushCount(line.length - n);
        return "flow";
      case "{":
      case "[":
        yield* this.pushCount(1);
        this.flowKey = false;
        this.flowLevel += 1;
        return "flow";
      case "}":
      case "]":
        yield* this.pushCount(1);
        this.flowKey = true;
        this.flowLevel -= 1;
        return this.flowLevel ? "flow" : "doc";
      case "*":
        yield* this.pushUntil(isNotAnchorChar);
        return "flow";
      case '"':
      case "'":
        this.flowKey = true;
        return yield* this.parseQuotedScalar();
      case ":": {
        const next2 = this.charAt(1);
        if (this.flowKey || isEmpty(next2) || next2 === ",") {
          this.flowKey = false;
          yield* this.pushCount(1);
          yield* this.pushSpaces(true);
          return "flow";
        }
      }
      // fallthrough
      default:
        this.flowKey = false;
        return yield* this.parsePlainScalar();
    }
  }
  *parseQuotedScalar() {
    const quote = this.charAt(0);
    let end = this.buffer.indexOf(quote, this.pos + 1);
    if (quote === "'") {
      while (end !== -1 && this.buffer[end + 1] === "'")
        end = this.buffer.indexOf("'", end + 2);
    } else {
      while (end !== -1) {
        let n = 0;
        while (this.buffer[end - 1 - n] === "\\")
          n += 1;
        if (n % 2 === 0)
          break;
        end = this.buffer.indexOf('"', end + 1);
      }
    }
    const qb = this.buffer.substring(0, end);
    let nl = qb.indexOf("\n", this.pos);
    if (nl !== -1) {
      while (nl !== -1) {
        const cs = this.continueScalar(nl + 1);
        if (cs === -1)
          break;
        nl = qb.indexOf("\n", cs);
      }
      if (nl !== -1) {
        end = nl - (qb[nl - 1] === "\r" ? 2 : 1);
      }
    }
    if (end === -1) {
      if (!this.atEnd)
        return this.setNext("quoted-scalar");
      end = this.buffer.length;
    }
    yield* this.pushToIndex(end + 1, false);
    return this.flowLevel ? "flow" : "doc";
  }
  *parseBlockScalarHeader() {
    this.blockScalarIndent = -1;
    this.blockScalarKeep = false;
    let i = this.pos;
    while (true) {
      const ch = this.buffer[++i];
      if (ch === "+")
        this.blockScalarKeep = true;
      else if (ch > "0" && ch <= "9")
        this.blockScalarIndent = Number(ch) - 1;
      else if (ch !== "-")
        break;
    }
    return yield* this.pushUntil((ch) => isEmpty(ch) || ch === "#");
  }
  *parseBlockScalar() {
    let nl = this.pos - 1;
    let indent = 0;
    let ch;
    loop: for (let i2 = this.pos; ch = this.buffer[i2]; ++i2) {
      switch (ch) {
        case " ":
          indent += 1;
          break;
        case "\n":
          nl = i2;
          indent = 0;
          break;
        case "\r": {
          const next2 = this.buffer[i2 + 1];
          if (!next2 && !this.atEnd)
            return this.setNext("block-scalar");
          if (next2 === "\n")
            break;
        }
        // fallthrough
        default:
          break loop;
      }
    }
    if (!ch && !this.atEnd)
      return this.setNext("block-scalar");
    if (indent >= this.indentNext) {
      if (this.blockScalarIndent === -1)
        this.indentNext = indent;
      else {
        this.indentNext = this.blockScalarIndent + (this.indentNext === 0 ? 1 : this.indentNext);
      }
      do {
        const cs = this.continueScalar(nl + 1);
        if (cs === -1)
          break;
        nl = this.buffer.indexOf("\n", cs);
      } while (nl !== -1);
      if (nl === -1) {
        if (!this.atEnd)
          return this.setNext("block-scalar");
        nl = this.buffer.length;
      }
    }
    let i = nl + 1;
    ch = this.buffer[i];
    while (ch === " ")
      ch = this.buffer[++i];
    if (ch === "	") {
      while (ch === "	" || ch === " " || ch === "\r" || ch === "\n")
        ch = this.buffer[++i];
      nl = i - 1;
    } else if (!this.blockScalarKeep) {
      do {
        let i2 = nl - 1;
        let ch2 = this.buffer[i2];
        if (ch2 === "\r")
          ch2 = this.buffer[--i2];
        const lastChar = i2;
        while (ch2 === " ")
          ch2 = this.buffer[--i2];
        if (ch2 === "\n" && i2 >= this.pos && i2 + 1 + indent > lastChar)
          nl = i2;
        else
          break;
      } while (true);
    }
    yield SCALAR2;
    yield* this.pushToIndex(nl + 1, true);
    return yield* this.parseLineStart();
  }
  *parsePlainScalar() {
    const inFlow = this.flowLevel > 0;
    let end = this.pos - 1;
    let i = this.pos - 1;
    let ch;
    while (ch = this.buffer[++i]) {
      if (ch === ":") {
        const next2 = this.buffer[i + 1];
        if (isEmpty(next2) || inFlow && flowIndicatorChars.has(next2))
          break;
        end = i;
      } else if (isEmpty(ch)) {
        let next2 = this.buffer[i + 1];
        if (ch === "\r") {
          if (next2 === "\n") {
            i += 1;
            ch = "\n";
            next2 = this.buffer[i + 1];
          } else
            end = i;
        }
        if (next2 === "#" || inFlow && flowIndicatorChars.has(next2))
          break;
        if (ch === "\n") {
          const cs = this.continueScalar(i + 1);
          if (cs === -1)
            break;
          i = Math.max(i, cs - 2);
        }
      } else {
        if (inFlow && flowIndicatorChars.has(ch))
          break;
        end = i;
      }
    }
    if (!ch && !this.atEnd)
      return this.setNext("plain-scalar");
    yield SCALAR2;
    yield* this.pushToIndex(end + 1, true);
    return inFlow ? "flow" : "doc";
  }
  *pushCount(n) {
    if (n > 0) {
      yield this.buffer.substr(this.pos, n);
      this.pos += n;
      return n;
    }
    return 0;
  }
  *pushToIndex(i, allowEmpty) {
    const s = this.buffer.slice(this.pos, i);
    if (s) {
      yield s;
      this.pos += s.length;
      return s.length;
    } else if (allowEmpty)
      yield "";
    return 0;
  }
  *pushIndicators() {
    let n = 0;
    loop: while (true) {
      switch (this.charAt(0)) {
        case "!":
          n += yield* this.pushTag();
          n += yield* this.pushSpaces(true);
          continue loop;
        case "&":
          n += yield* this.pushUntil(isNotAnchorChar);
          n += yield* this.pushSpaces(true);
          continue loop;
        case "-":
        // this is an error
        case "?":
        // this is an error outside flow collections
        case ":": {
          const inFlow = this.flowLevel > 0;
          const ch1 = this.charAt(1);
          if (isEmpty(ch1) || inFlow && flowIndicatorChars.has(ch1)) {
            if (!inFlow)
              this.indentNext = this.indentValue + 1;
            else if (this.flowKey)
              this.flowKey = false;
            n += yield* this.pushCount(1);
            n += yield* this.pushSpaces(true);
            continue loop;
          }
        }
      }
      break loop;
    }
    return n;
  }
  *pushTag() {
    if (this.charAt(1) === "<") {
      let i = this.pos + 2;
      let ch = this.buffer[i];
      while (!isEmpty(ch) && ch !== ">")
        ch = this.buffer[++i];
      return yield* this.pushToIndex(ch === ">" ? i + 1 : i, false);
    } else {
      let i = this.pos + 1;
      let ch = this.buffer[i];
      while (ch) {
        if (tagChars.has(ch))
          ch = this.buffer[++i];
        else if (ch === "%" && hexDigits.has(this.buffer[i + 1]) && hexDigits.has(this.buffer[i + 2])) {
          ch = this.buffer[i += 3];
        } else
          break;
      }
      return yield* this.pushToIndex(i, false);
    }
  }
  *pushNewline() {
    const ch = this.buffer[this.pos];
    if (ch === "\n")
      return yield* this.pushCount(1);
    else if (ch === "\r" && this.charAt(1) === "\n")
      return yield* this.pushCount(2);
    else
      return 0;
  }
  *pushSpaces(allowTabs) {
    let i = this.pos - 1;
    let ch;
    do {
      ch = this.buffer[++i];
    } while (ch === " " || allowTabs && ch === "	");
    const n = i - this.pos;
    if (n > 0) {
      yield this.buffer.substr(this.pos, n);
      this.pos = i;
    }
    return n;
  }
  *pushUntil(test) {
    let i = this.pos;
    let ch = this.buffer[i];
    while (!test(ch))
      ch = this.buffer[++i];
    return yield* this.pushToIndex(i, false);
  }
};

// node_modules/yaml/browser/dist/parse/line-counter.js
var LineCounter = class {
  constructor() {
    this.lineStarts = [];
    this.addNewLine = (offset) => this.lineStarts.push(offset);
    this.linePos = (offset) => {
      let low = 0;
      let high = this.lineStarts.length;
      while (low < high) {
        const mid = low + high >> 1;
        if (this.lineStarts[mid] < offset)
          low = mid + 1;
        else
          high = mid;
      }
      if (this.lineStarts[low] === offset)
        return { line: low + 1, col: 1 };
      if (low === 0)
        return { line: 0, col: offset };
      const start = this.lineStarts[low - 1];
      return { line: low, col: offset - start + 1 };
    };
  }
};

// node_modules/yaml/browser/dist/parse/parser.js
function includesToken(list, type) {
  for (let i = 0; i < list.length; ++i)
    if (list[i].type === type)
      return true;
  return false;
}
function findNonEmptyIndex(list) {
  for (let i = 0; i < list.length; ++i) {
    switch (list[i].type) {
      case "space":
      case "comment":
      case "newline":
        break;
      default:
        return i;
    }
  }
  return -1;
}
function isFlowToken(token) {
  switch (token?.type) {
    case "alias":
    case "scalar":
    case "single-quoted-scalar":
    case "double-quoted-scalar":
    case "flow-collection":
      return true;
    default:
      return false;
  }
}
function getPrevProps(parent) {
  switch (parent.type) {
    case "document":
      return parent.start;
    case "block-map": {
      const it = parent.items[parent.items.length - 1];
      return it.sep ?? it.start;
    }
    case "block-seq":
      return parent.items[parent.items.length - 1].start;
    /* istanbul ignore next should not happen */
    default:
      return [];
  }
}
function getFirstKeyStartProps(prev) {
  if (prev.length === 0)
    return [];
  let i = prev.length;
  loop: while (--i >= 0) {
    switch (prev[i].type) {
      case "doc-start":
      case "explicit-key-ind":
      case "map-value-ind":
      case "seq-item-ind":
      case "newline":
        break loop;
    }
  }
  while (prev[++i]?.type === "space") {
  }
  return prev.splice(i, prev.length);
}
function arrayPushArray(target, source) {
  if (source.length < 1e5)
    Array.prototype.push.apply(target, source);
  else
    for (let i = 0; i < source.length; ++i)
      target.push(source[i]);
}
function fixFlowSeqItems(fc) {
  if (fc.start.type === "flow-seq-start") {
    for (const it of fc.items) {
      if (it.sep && !it.value && !includesToken(it.start, "explicit-key-ind") && !includesToken(it.sep, "map-value-ind")) {
        if (it.key)
          it.value = it.key;
        delete it.key;
        if (isFlowToken(it.value)) {
          if (it.value.end)
            arrayPushArray(it.value.end, it.sep);
          else
            it.value.end = it.sep;
        } else
          arrayPushArray(it.start, it.sep);
        delete it.sep;
      }
    }
  }
}
var Parser = class {
  /**
   * @param onNewLine - If defined, called separately with the start position of
   *   each new line (in `parse()`, including the start of input).
   */
  constructor(onNewLine) {
    this.atNewLine = true;
    this.atScalar = false;
    this.indent = 0;
    this.offset = 0;
    this.onKeyLine = false;
    this.stack = [];
    this.source = "";
    this.type = "";
    this.lexer = new Lexer();
    this.onNewLine = onNewLine;
  }
  /**
   * Parse `source` as a YAML stream.
   * If `incomplete`, a part of the last line may be left as a buffer for the next call.
   *
   * Errors are not thrown, but yielded as `{ type: 'error', message }` tokens.
   *
   * @returns A generator of tokens representing each directive, document, and other structure.
   */
  *parse(source, incomplete = false) {
    if (this.onNewLine && this.offset === 0)
      this.onNewLine(0);
    for (const lexeme of this.lexer.lex(source, incomplete))
      yield* this.next(lexeme);
    if (!incomplete)
      yield* this.end();
  }
  /**
   * Advance the parser by the `source` of one lexical token.
   */
  *next(source) {
    this.source = source;
    if (this.atScalar) {
      this.atScalar = false;
      yield* this.step();
      this.offset += source.length;
      return;
    }
    const type = tokenType(source);
    if (!type) {
      const message = `Not a YAML token: ${source}`;
      yield* this.pop({ type: "error", offset: this.offset, message, source });
      this.offset += source.length;
    } else if (type === "scalar") {
      this.atNewLine = false;
      this.atScalar = true;
      this.type = "scalar";
    } else {
      this.type = type;
      yield* this.step();
      switch (type) {
        case "newline":
          this.atNewLine = true;
          this.indent = 0;
          if (this.onNewLine)
            this.onNewLine(this.offset + source.length);
          break;
        case "space":
          if (this.atNewLine && source[0] === " ")
            this.indent += source.length;
          break;
        case "explicit-key-ind":
        case "map-value-ind":
        case "seq-item-ind":
          if (this.atNewLine)
            this.indent += source.length;
          break;
        case "doc-mode":
        case "flow-error-end":
          return;
        default:
          this.atNewLine = false;
      }
      this.offset += source.length;
    }
  }
  /** Call at end of input to push out any remaining constructions */
  *end() {
    while (this.stack.length > 0)
      yield* this.pop();
  }
  get sourceToken() {
    const st = {
      type: this.type,
      offset: this.offset,
      indent: this.indent,
      source: this.source
    };
    return st;
  }
  *step() {
    const top = this.peek(1);
    if (this.type === "doc-end" && top?.type !== "doc-end") {
      while (this.stack.length > 0)
        yield* this.pop();
      this.stack.push({
        type: "doc-end",
        offset: this.offset,
        source: this.source
      });
      return;
    }
    if (!top)
      return yield* this.stream();
    switch (top.type) {
      case "document":
        return yield* this.document(top);
      case "alias":
      case "scalar":
      case "single-quoted-scalar":
      case "double-quoted-scalar":
        return yield* this.scalar(top);
      case "block-scalar":
        return yield* this.blockScalar(top);
      case "block-map":
        return yield* this.blockMap(top);
      case "block-seq":
        return yield* this.blockSequence(top);
      case "flow-collection":
        return yield* this.flowCollection(top);
      case "doc-end":
        return yield* this.documentEnd(top);
    }
    yield* this.pop();
  }
  peek(n) {
    return this.stack[this.stack.length - n];
  }
  *pop(error) {
    const token = error ?? this.stack.pop();
    if (!token) {
      const message = "Tried to pop an empty stack";
      yield { type: "error", offset: this.offset, source: "", message };
    } else if (this.stack.length === 0) {
      yield token;
    } else {
      const top = this.peek(1);
      if (token.type === "block-scalar") {
        token.indent = "indent" in top ? top.indent : 0;
      } else if (token.type === "flow-collection" && top.type === "document") {
        token.indent = 0;
      }
      if (token.type === "flow-collection")
        fixFlowSeqItems(token);
      switch (top.type) {
        case "document":
          top.value = token;
          break;
        case "block-scalar":
          top.props.push(token);
          break;
        case "block-map": {
          const it = top.items[top.items.length - 1];
          if (it.value) {
            top.items.push({ start: [], key: token, sep: [] });
            this.onKeyLine = true;
            return;
          } else if (it.sep) {
            it.value = token;
          } else {
            Object.assign(it, { key: token, sep: [] });
            this.onKeyLine = !it.explicitKey;
            return;
          }
          break;
        }
        case "block-seq": {
          const it = top.items[top.items.length - 1];
          if (it.value)
            top.items.push({ start: [], value: token });
          else
            it.value = token;
          break;
        }
        case "flow-collection": {
          const it = top.items[top.items.length - 1];
          if (!it || it.value)
            top.items.push({ start: [], key: token, sep: [] });
          else if (it.sep)
            it.value = token;
          else
            Object.assign(it, { key: token, sep: [] });
          return;
        }
        /* istanbul ignore next should not happen */
        default:
          yield* this.pop();
          yield* this.pop(token);
      }
      if ((top.type === "document" || top.type === "block-map" || top.type === "block-seq") && (token.type === "block-map" || token.type === "block-seq")) {
        const last = token.items[token.items.length - 1];
        if (last && !last.sep && !last.value && last.start.length > 0 && findNonEmptyIndex(last.start) === -1 && (token.indent === 0 || last.start.every((st) => st.type !== "comment" || st.indent < token.indent))) {
          if (top.type === "document")
            top.end = last.start;
          else
            top.items.push({ start: last.start });
          token.items.splice(-1, 1);
        }
      }
    }
  }
  *stream() {
    switch (this.type) {
      case "directive-line":
        yield { type: "directive", offset: this.offset, source: this.source };
        return;
      case "byte-order-mark":
      case "space":
      case "comment":
      case "newline":
        yield this.sourceToken;
        return;
      case "doc-mode":
      case "doc-start": {
        const doc = {
          type: "document",
          offset: this.offset,
          start: []
        };
        if (this.type === "doc-start")
          doc.start.push(this.sourceToken);
        this.stack.push(doc);
        return;
      }
    }
    yield {
      type: "error",
      offset: this.offset,
      message: `Unexpected ${this.type} token in YAML stream`,
      source: this.source
    };
  }
  *document(doc) {
    if (doc.value)
      return yield* this.lineEnd(doc);
    switch (this.type) {
      case "doc-start": {
        if (findNonEmptyIndex(doc.start) !== -1) {
          yield* this.pop();
          yield* this.step();
        } else
          doc.start.push(this.sourceToken);
        return;
      }
      case "anchor":
      case "tag":
      case "space":
      case "comment":
      case "newline":
        doc.start.push(this.sourceToken);
        return;
    }
    const bv = this.startBlockValue(doc);
    if (bv)
      this.stack.push(bv);
    else {
      yield {
        type: "error",
        offset: this.offset,
        message: `Unexpected ${this.type} token in YAML document`,
        source: this.source
      };
    }
  }
  *scalar(scalar) {
    if (this.type === "map-value-ind") {
      const prev = getPrevProps(this.peek(2));
      const start = getFirstKeyStartProps(prev);
      let sep;
      if (scalar.end) {
        sep = scalar.end;
        sep.push(this.sourceToken);
        delete scalar.end;
      } else
        sep = [this.sourceToken];
      const map2 = {
        type: "block-map",
        offset: scalar.offset,
        indent: scalar.indent,
        items: [{ start, key: scalar, sep }]
      };
      this.onKeyLine = true;
      this.stack[this.stack.length - 1] = map2;
    } else
      yield* this.lineEnd(scalar);
  }
  *blockScalar(scalar) {
    switch (this.type) {
      case "space":
      case "comment":
      case "newline":
        scalar.props.push(this.sourceToken);
        return;
      case "scalar":
        scalar.source = this.source;
        this.atNewLine = true;
        this.indent = 0;
        if (this.onNewLine) {
          let nl = this.source.indexOf("\n") + 1;
          while (nl !== 0) {
            this.onNewLine(this.offset + nl);
            nl = this.source.indexOf("\n", nl) + 1;
          }
        }
        yield* this.pop();
        break;
      /* istanbul ignore next should not happen */
      default:
        yield* this.pop();
        yield* this.step();
    }
  }
  *blockMap(map2) {
    const it = map2.items[map2.items.length - 1];
    switch (this.type) {
      case "newline":
        this.onKeyLine = false;
        if (it.value) {
          const end = "end" in it.value ? it.value.end : void 0;
          const last = Array.isArray(end) ? end[end.length - 1] : void 0;
          if (last?.type === "comment")
            end?.push(this.sourceToken);
          else
            map2.items.push({ start: [this.sourceToken] });
        } else if (it.sep) {
          it.sep.push(this.sourceToken);
        } else {
          it.start.push(this.sourceToken);
        }
        return;
      case "space":
      case "comment":
        if (it.value) {
          map2.items.push({ start: [this.sourceToken] });
        } else if (it.sep) {
          it.sep.push(this.sourceToken);
        } else {
          if (this.atIndentedComment(it.start, map2.indent)) {
            const prev = map2.items[map2.items.length - 2];
            const end = prev?.value?.end;
            if (Array.isArray(end)) {
              arrayPushArray(end, it.start);
              end.push(this.sourceToken);
              map2.items.pop();
              return;
            }
          }
          it.start.push(this.sourceToken);
        }
        return;
    }
    if (this.indent >= map2.indent) {
      const atMapIndent = !this.onKeyLine && this.indent === map2.indent;
      const atNextItem = atMapIndent && (it.sep || it.explicitKey) && this.type !== "seq-item-ind";
      let start = [];
      if (atNextItem && it.sep && !it.value) {
        const nl = [];
        for (let i = 0; i < it.sep.length; ++i) {
          const st = it.sep[i];
          switch (st.type) {
            case "newline":
              nl.push(i);
              break;
            case "space":
              break;
            case "comment":
              if (st.indent > map2.indent)
                nl.length = 0;
              break;
            default:
              nl.length = 0;
          }
        }
        if (nl.length >= 2)
          start = it.sep.splice(nl[1]);
      }
      switch (this.type) {
        case "anchor":
        case "tag":
          if (atNextItem || it.value) {
            start.push(this.sourceToken);
            map2.items.push({ start });
            this.onKeyLine = true;
          } else if (it.sep) {
            it.sep.push(this.sourceToken);
          } else {
            it.start.push(this.sourceToken);
          }
          return;
        case "explicit-key-ind":
          if (!it.sep && !it.explicitKey) {
            it.start.push(this.sourceToken);
            it.explicitKey = true;
          } else if (atNextItem || it.value) {
            start.push(this.sourceToken);
            map2.items.push({ start, explicitKey: true });
          } else {
            this.stack.push({
              type: "block-map",
              offset: this.offset,
              indent: this.indent,
              items: [{ start: [this.sourceToken], explicitKey: true }]
            });
          }
          this.onKeyLine = true;
          return;
        case "map-value-ind":
          if (it.explicitKey) {
            if (!it.sep) {
              if (includesToken(it.start, "newline")) {
                Object.assign(it, { key: null, sep: [this.sourceToken] });
              } else {
                const start2 = getFirstKeyStartProps(it.start);
                this.stack.push({
                  type: "block-map",
                  offset: this.offset,
                  indent: this.indent,
                  items: [{ start: start2, key: null, sep: [this.sourceToken] }]
                });
              }
            } else if (it.value) {
              map2.items.push({ start: [], key: null, sep: [this.sourceToken] });
            } else if (includesToken(it.sep, "map-value-ind")) {
              this.stack.push({
                type: "block-map",
                offset: this.offset,
                indent: this.indent,
                items: [{ start, key: null, sep: [this.sourceToken] }]
              });
            } else if (isFlowToken(it.key) && !includesToken(it.sep, "newline")) {
              const start2 = getFirstKeyStartProps(it.start);
              const key = it.key;
              const sep = it.sep;
              sep.push(this.sourceToken);
              delete it.key;
              delete it.sep;
              this.stack.push({
                type: "block-map",
                offset: this.offset,
                indent: this.indent,
                items: [{ start: start2, key, sep }]
              });
            } else if (start.length > 0) {
              it.sep = it.sep.concat(start, this.sourceToken);
            } else {
              it.sep.push(this.sourceToken);
            }
          } else {
            if (!it.sep) {
              Object.assign(it, { key: null, sep: [this.sourceToken] });
            } else if (it.value || atNextItem) {
              map2.items.push({ start, key: null, sep: [this.sourceToken] });
            } else if (includesToken(it.sep, "map-value-ind")) {
              this.stack.push({
                type: "block-map",
                offset: this.offset,
                indent: this.indent,
                items: [{ start: [], key: null, sep: [this.sourceToken] }]
              });
            } else {
              it.sep.push(this.sourceToken);
            }
          }
          this.onKeyLine = true;
          return;
        case "alias":
        case "scalar":
        case "single-quoted-scalar":
        case "double-quoted-scalar": {
          const fs = this.flowScalar(this.type);
          if (atNextItem || it.value) {
            map2.items.push({ start, key: fs, sep: [] });
            this.onKeyLine = true;
          } else if (it.sep) {
            this.stack.push(fs);
          } else {
            Object.assign(it, { key: fs, sep: [] });
            this.onKeyLine = true;
          }
          return;
        }
        default: {
          const bv = this.startBlockValue(map2);
          if (bv) {
            if (bv.type === "block-seq") {
              if (!it.explicitKey && it.sep && !includesToken(it.sep, "newline")) {
                yield* this.pop({
                  type: "error",
                  offset: this.offset,
                  message: "Unexpected block-seq-ind on same line with key",
                  source: this.source
                });
                return;
              }
            } else if (atMapIndent) {
              map2.items.push({ start });
            }
            this.stack.push(bv);
            return;
          }
        }
      }
    }
    yield* this.pop();
    yield* this.step();
  }
  *blockSequence(seq2) {
    const it = seq2.items[seq2.items.length - 1];
    switch (this.type) {
      case "newline":
        if (it.value) {
          const end = "end" in it.value ? it.value.end : void 0;
          const last = Array.isArray(end) ? end[end.length - 1] : void 0;
          if (last?.type === "comment")
            end?.push(this.sourceToken);
          else
            seq2.items.push({ start: [this.sourceToken] });
        } else
          it.start.push(this.sourceToken);
        return;
      case "space":
      case "comment":
        if (it.value)
          seq2.items.push({ start: [this.sourceToken] });
        else {
          if (this.atIndentedComment(it.start, seq2.indent)) {
            const prev = seq2.items[seq2.items.length - 2];
            const end = prev?.value?.end;
            if (Array.isArray(end)) {
              arrayPushArray(end, it.start);
              end.push(this.sourceToken);
              seq2.items.pop();
              return;
            }
          }
          it.start.push(this.sourceToken);
        }
        return;
      case "anchor":
      case "tag":
        if (it.value || this.indent <= seq2.indent)
          break;
        it.start.push(this.sourceToken);
        return;
      case "seq-item-ind":
        if (this.indent !== seq2.indent)
          break;
        if (it.value || includesToken(it.start, "seq-item-ind"))
          seq2.items.push({ start: [this.sourceToken] });
        else
          it.start.push(this.sourceToken);
        return;
    }
    if (this.indent > seq2.indent) {
      const bv = this.startBlockValue(seq2);
      if (bv) {
        this.stack.push(bv);
        return;
      }
    }
    yield* this.pop();
    yield* this.step();
  }
  *flowCollection(fc) {
    const it = fc.items[fc.items.length - 1];
    if (this.type === "flow-error-end") {
      let top;
      do {
        yield* this.pop();
        top = this.peek(1);
      } while (top?.type === "flow-collection");
    } else if (fc.end.length === 0) {
      switch (this.type) {
        case "comma":
        case "explicit-key-ind":
          if (!it || it.sep)
            fc.items.push({ start: [this.sourceToken] });
          else
            it.start.push(this.sourceToken);
          return;
        case "map-value-ind":
          if (!it || it.value)
            fc.items.push({ start: [], key: null, sep: [this.sourceToken] });
          else if (it.sep)
            it.sep.push(this.sourceToken);
          else
            Object.assign(it, { key: null, sep: [this.sourceToken] });
          return;
        case "space":
        case "comment":
        case "newline":
        case "anchor":
        case "tag":
          if (!it || it.value)
            fc.items.push({ start: [this.sourceToken] });
          else if (it.sep)
            it.sep.push(this.sourceToken);
          else
            it.start.push(this.sourceToken);
          return;
        case "alias":
        case "scalar":
        case "single-quoted-scalar":
        case "double-quoted-scalar": {
          const fs = this.flowScalar(this.type);
          if (!it || it.value)
            fc.items.push({ start: [], key: fs, sep: [] });
          else if (it.sep)
            this.stack.push(fs);
          else
            Object.assign(it, { key: fs, sep: [] });
          return;
        }
        case "flow-map-end":
        case "flow-seq-end":
          fc.end.push(this.sourceToken);
          return;
      }
      const bv = this.startBlockValue(fc);
      if (bv)
        this.stack.push(bv);
      else {
        yield* this.pop();
        yield* this.step();
      }
    } else {
      const parent = this.peek(2);
      if (parent.type === "block-map" && (this.type === "map-value-ind" && parent.indent === fc.indent || this.type === "newline" && !parent.items[parent.items.length - 1].sep)) {
        yield* this.pop();
        yield* this.step();
      } else if (this.type === "map-value-ind" && parent.type !== "flow-collection") {
        const prev = getPrevProps(parent);
        const start = getFirstKeyStartProps(prev);
        fixFlowSeqItems(fc);
        const sep = fc.end.splice(1, fc.end.length);
        sep.push(this.sourceToken);
        const map2 = {
          type: "block-map",
          offset: fc.offset,
          indent: fc.indent,
          items: [{ start, key: fc, sep }]
        };
        this.onKeyLine = true;
        this.stack[this.stack.length - 1] = map2;
      } else {
        yield* this.lineEnd(fc);
      }
    }
  }
  flowScalar(type) {
    if (this.onNewLine) {
      let nl = this.source.indexOf("\n") + 1;
      while (nl !== 0) {
        this.onNewLine(this.offset + nl);
        nl = this.source.indexOf("\n", nl) + 1;
      }
    }
    return {
      type,
      offset: this.offset,
      indent: this.indent,
      source: this.source
    };
  }
  startBlockValue(parent) {
    switch (this.type) {
      case "alias":
      case "scalar":
      case "single-quoted-scalar":
      case "double-quoted-scalar":
        return this.flowScalar(this.type);
      case "block-scalar-header":
        return {
          type: "block-scalar",
          offset: this.offset,
          indent: this.indent,
          props: [this.sourceToken],
          source: ""
        };
      case "flow-map-start":
      case "flow-seq-start":
        return {
          type: "flow-collection",
          offset: this.offset,
          indent: this.indent,
          start: this.sourceToken,
          items: [],
          end: []
        };
      case "seq-item-ind":
        return {
          type: "block-seq",
          offset: this.offset,
          indent: this.indent,
          items: [{ start: [this.sourceToken] }]
        };
      case "explicit-key-ind": {
        this.onKeyLine = true;
        const prev = getPrevProps(parent);
        const start = getFirstKeyStartProps(prev);
        start.push(this.sourceToken);
        return {
          type: "block-map",
          offset: this.offset,
          indent: this.indent,
          items: [{ start, explicitKey: true }]
        };
      }
      case "map-value-ind": {
        this.onKeyLine = true;
        const prev = getPrevProps(parent);
        const start = getFirstKeyStartProps(prev);
        return {
          type: "block-map",
          offset: this.offset,
          indent: this.indent,
          items: [{ start, key: null, sep: [this.sourceToken] }]
        };
      }
    }
    return null;
  }
  atIndentedComment(start, indent) {
    if (this.type !== "comment")
      return false;
    if (this.indent <= indent)
      return false;
    return start.every((st) => st.type === "newline" || st.type === "space");
  }
  *documentEnd(docEnd) {
    if (this.type !== "doc-mode") {
      if (docEnd.end)
        docEnd.end.push(this.sourceToken);
      else
        docEnd.end = [this.sourceToken];
      if (this.type === "newline")
        yield* this.pop();
    }
  }
  *lineEnd(token) {
    switch (this.type) {
      case "comma":
      case "doc-start":
      case "doc-end":
      case "flow-seq-end":
      case "flow-map-end":
      case "map-value-ind":
        yield* this.pop();
        yield* this.step();
        break;
      case "newline":
        this.onKeyLine = false;
      // fallthrough
      case "space":
      case "comment":
      default:
        if (token.end)
          token.end.push(this.sourceToken);
        else
          token.end = [this.sourceToken];
        if (this.type === "newline")
          yield* this.pop();
    }
  }
};

// node_modules/yaml/browser/dist/public-api.js
function parseOptions(options) {
  const prettyErrors = options.prettyErrors !== false;
  const lineCounter = options.lineCounter || prettyErrors && new LineCounter() || null;
  return { lineCounter, prettyErrors };
}
function parseAllDocuments(source, options = {}) {
  const { lineCounter, prettyErrors } = parseOptions(options);
  const parser = new Parser(lineCounter?.addNewLine);
  const composer = new Composer(options);
  const docs = Array.from(composer.compose(parser.parse(source)));
  if (prettyErrors && lineCounter)
    for (const doc of docs) {
      doc.errors.forEach(prettifyError(source, lineCounter));
      doc.warnings.forEach(prettifyError(source, lineCounter));
    }
  if (docs.length > 0)
    return docs;
  return Object.assign([], { empty: true }, composer.streamInfo());
}
function parseDocument(source, options = {}) {
  const { lineCounter, prettyErrors } = parseOptions(options);
  const parser = new Parser(lineCounter?.addNewLine);
  const composer = new Composer(options);
  let doc = null;
  for (const _doc of composer.compose(parser.parse(source), true, source.length)) {
    if (!doc)
      doc = _doc;
    else if (doc.options.logLevel !== "silent") {
      doc.errors.push(new YAMLParseError(_doc.range.slice(0, 2), "MULTIPLE_DOCS", "Source contains multiple documents; please use YAML.parseAllDocuments()"));
      break;
    }
  }
  if (prettyErrors && lineCounter) {
    doc.errors.forEach(prettifyError(source, lineCounter));
    doc.warnings.forEach(prettifyError(source, lineCounter));
  }
  return doc;
}
function parse(src, reviver, options) {
  let _reviver = void 0;
  if (typeof reviver === "function") {
    _reviver = reviver;
  } else if (options === void 0 && reviver && typeof reviver === "object") {
    options = reviver;
  }
  const doc = parseDocument(src, options);
  if (!doc)
    return null;
  doc.warnings.forEach((warning) => warn(doc.options.logLevel, warning));
  if (doc.errors.length > 0) {
    if (doc.options.logLevel !== "silent")
      throw doc.errors[0];
    else
      doc.errors = [];
  }
  return doc.toJS(Object.assign({ reviver: _reviver }, options));
}
function stringify3(value, replacer, options) {
  let _replacer = null;
  if (typeof replacer === "function" || Array.isArray(replacer)) {
    _replacer = replacer;
  } else if (options === void 0 && replacer) {
    options = replacer;
  }
  if (typeof options === "string")
    options = options.length;
  if (typeof options === "number") {
    const indent = Math.round(options);
    options = indent < 1 ? void 0 : indent > 8 ? { indent: 8 } : { indent };
  }
  if (value === void 0) {
    const { keepUndefined } = options ?? replacer ?? {};
    if (!keepUndefined)
      return void 0;
  }
  if (isDocument(value) && !_replacer)
    return value.toString(options);
  return new Document(value, _replacer, options).toString(options);
}

// node_modules/yaml/browser/index.js
var browser_default = dist_exports;

// src/knowledge-notes.js
var name = (value) => {
  let text2 = String(value).replace(/<[^>]+>/g, "").replace(/[<>:"/\\|?*\[\]#^\x00-\x1f]/g, " ").replace(/\s+/g, " ").replace(/^[ .]+|[ .]+$/g, "").slice(0, 55);
  return !text2 || /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/i.test(text2) ? "\u672A\u547D\u540D" : text2;
};
var safePath = (path) => typeof path === "string" && !path.includes("\\") && !path.includes(":") && !path.startsWith("/") && path.split("/").every((p) => p && p !== "." && p !== "..") && path.endsWith(".md");
async function materializeKnowledge(store, data) {
  const { subject_id: subject, phase_id: phase, nodes } = data, chapter = data.edition_id != null, kind = chapter ? "chapters" : "knowledge", scope = `${subject}-${phase}${chapter ? "-" + data.edition_id : ""}`;
  const modern = (await store.json(".bank/config.json")).ui_layout === "teacher/v2";
  const root2 = chapter ? modern ? "\u8D44\u6599/\u6559\u6750\u76EE\u5F55" : "\u6559\u6750\u76EE\u5F55" : modern ? "\u8D44\u6599/\u77E5\u8BC6\u76EE\u5F55" : "\u77E5\u8BC6\u5E93/\u6807\u51C6\u77E5\u8BC6\u70B9";
  const labels = await store.json(".bank/catalog/names.json");
  const title = name(`${labels.phases?.[phase] || `\u5B66\u6BB5${phase}`} \xB7 ${labels.subjects?.[subject] || `\u5B66\u79D1${subject}`}${chapter ? " \xB7 " + (labels.editions?.[data.edition_id] || `\u6559\u6750\u7248\u672C${data.edition_id}`) : ""}`);
  const landing = chapter ? "\u6559\u6750\u76EE\u5F55" : "\u77E5\u8BC6\u6811";
  const base = `${root2}/${title}`, mapping = await store.json(".bank/ui-paths.json", { knowledge: {}, chapters: {} });
  mapping.knowledge ?? (mapping.knowledge = {});
  mapping.chapters ?? (mapping.chapters = {});
  const paths = { ...mapping[kind][scope] || {} }, byId = new Map(nodes.map((n) => [String(n.id), n]));
  for (const path of Object.values(paths)) if (!safePath(path)) throw Error("\u77E5\u8BC6\u76EE\u5F55\u8DEF\u5F84\u65E0\u6548\uFF0C\u8BF7\u68C0\u67E5 .bank/ui-paths.json\u3002");
  const reserved = new Set(Object.values(paths));
  reserved.add(`${base}/${landing}.md`);
  for (const n of nodes) {
    const key = String(n.id);
    if (paths[key]) continue;
    const ancestors = [];
    let parent = byId.get(String(n.parent_id));
    while (parent) {
      ancestors.unshift(name(parent.name));
      parent = byId.get(String(parent.parent_id));
    }
    const folder = [base, ...ancestors.slice(0, 2)].join("/"), stem = name(n.name);
    let path = `${folder}/${stem}.md`, i = 2;
    while (reserved.has(path) || await store.io.exists(path)) path = `${folder}/${stem}\uFF08${i++}\uFF09.md`;
    paths[key] = path;
    reserved.add(path);
  }
  mapping[kind][scope] = paths;
  await store.io.write(".bank/ui-paths.json", JSON.stringify(mapping, null, 2));
  const link = (n) => `[[${paths[String(n.id)].slice(0, -3)}|${name(n.name)}]]`;
  const create2 = async (path, text2) => {
    if (await store.io.exists(path)) return;
    await store.mkdir(path.slice(0, path.lastIndexOf("/")));
    await store.io.write(path, text2);
  };
  const children = /* @__PURE__ */ new Map();
  for (const n of nodes) {
    const p = String(n.parent_id);
    if (!children.has(p)) children.set(p, []);
    children.get(p).push(n);
  }
  for (const n of nodes) {
    const parent = byId.get(String(n.parent_id));
    const meta = { ...chapter ? { "\u7AE0\u8282\u7F16\u53F7": String(n.id), "\u6559\u6750\u7248\u672C\u7F16\u53F7": data.edition_id, "\u5E74\u7EA7\u7F16\u53F7": n.grade_id ?? null } : { "\u77E5\u8BC6\u8282\u70B9\u7F16\u53F7": String(n.id), "\u7CBE\u786E\u77E5\u8BC6\u7F16\u53F7": String(n.knowledge_id || "") }, "\u5B66\u79D1\u7F16\u53F7": subject, "\u5B66\u6BB5\u7F16\u53F7": phase, "\u5185\u5BB9\u7BA1\u7406": "\u7CFB\u7EDF\u751F\u6210" };
    const personal = modern ? "\u6559\u5B66\u7B14\u8BB0" : "\u77E5\u8BC6\u5E93/\u6211\u7684\u6559\u5B66\u7B14\u8BB0";
    await create2(paths[String(n.id)], `---
${browser_default.stringify(meta)}---

# ${n.name}

${parent ? "\u7236\u77E5\u8BC6\u70B9\uFF1A" + link(parent) + "\n\n" : ""}${(children.get(String(n.id)) || []).map((c) => "- " + link(c)).join("\n")}

\u4E2A\u4EBA\u7B14\u8BB0\uFF1A[[${personal}/${name(n.name)} \xB7 ${scope}|\u6211\u7684\u6559\u5B66\u7B14\u8BB0]]
`);
  }
  await create2(`${base}/${landing}.md`, `# ${title}${landing}

\u5171 ${nodes.length} \u4E2A${chapter ? "\u7AE0\u8282" : "\u77E5\u8BC6\u70B9"}\u3002\u70B9\u51FB\u5206\u7C7B\u9010\u7EA7\u6D4F\u89C8\u3002

${nodes.filter((n) => !byId.has(String(n.parent_id))).map((n) => "- " + link(n)).join("\n")}
`);
  return { nodes: nodes.length, path: `${base}/${landing}.md` };
}

// src/metadata-cache.js
var TTL = 24 * 60 * 60 * 1e3;
var publicNames = /* @__PURE__ */ new Set(["subjects", "phases", "grades", "editions", "chapters", "knowledge-points"]);
var canonical = (name2, params) => JSON.stringify([name2, Object.entries(params).filter(([, v]) => v != null && v !== "").map(([k, v]) => [k, String(v)]).sort(([a], [b]) => a.localeCompare(b))]);
var MetadataCache = class {
  constructor(io = null, { now = () => Date.now(), ttl = TTL } = {}) {
    this.io = io;
    this.now = now;
    this.ttl = ttl;
    this.entries = /* @__PURE__ */ new Map();
    this.pending = /* @__PURE__ */ new Map();
    this.writes = Promise.resolve();
  }
  fresh(entry) {
    return entry?.schema === "tizhuang.metadata-cache/v1" && Array.isArray(entry.data) && Number.isFinite(entry.fetched_at) && entry.fetched_at <= this.now() && this.now() - entry.fetched_at < this.ttl;
  }
  async path(key) {
    const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(key));
    return ".bank/cache/" + Array.from(new Uint8Array(bytes), (v) => v.toString(16).padStart(2, "0")).join("") + ".json";
  }
  seed(name2, params, data, date) {
    const key = canonical(name2, params), entry = { schema: "tizhuang.metadata-cache/v1", key, data, fetched_at: Date.parse(date) };
    if (this.fresh(entry) && !this.fresh(this.entries.get(key))) this.entries.set(key, entry);
  }
  async get(name2, params, loader, { force = false } = {}) {
    if (!publicNames.has(name2)) return loader();
    const key = canonical(name2, params);
    if (!force && this.fresh(this.entries.get(key))) return structuredClone(this.entries.get(key).data);
    if (this.pending.has(key)) return structuredClone(await this.pending.get(key));
    const load = async () => {
      let path;
      if (this.io) {
        path = await this.path(key);
        if (!force) try {
          if (await this.io.exists(path)) {
            const saved = JSON.parse(await this.io.read(path));
            if (saved.key === key && this.fresh(saved)) {
              this.entries.set(key, saved);
              return saved.data;
            }
          }
        } catch {
        }
      }
      const data = await loader();
      if (!Array.isArray(data)) throw Error("\u76EE\u5F55\u54CD\u5E94\u683C\u5F0F\u5F02\u5E38\uFF0C\u8BF7\u91CD\u65B0\u52A0\u8F7D\u76EE\u5F55\u3002");
      const entry = { schema: "tizhuang.metadata-cache/v1", key, fetched_at: this.now(), data: structuredClone(data) };
      this.entries.set(key, entry);
      if (this.entries.size > 48) this.entries.delete(this.entries.keys().next().value);
      if (this.io) {
        this.writes = this.writes.catch(() => {
        }).then(async () => {
          for (const directory of [".bank", ".bank/cache"]) if (!await this.io.exists(directory)) await this.io.mkdir(directory);
          await this.io.write(path, JSON.stringify(entry));
        });
        try {
          await this.writes;
        } catch {
        }
      }
      return data;
    };
    const work = load();
    this.pending.set(key, work);
    try {
      return structuredClone(await work);
    } finally {
      this.pending.delete(key);
    }
  }
};

// src/presentation.js
var hasImage = (q) => /!\[|<img\b/i.test(q.content || "");
function cleanTitle(value, kind = "\u9898\u76EE") {
  return String(value || "").replace(/!\[[^\]]*\]\([^\n]*?\)|!\[\[[^\]]+\]\]|<img\b[^>]*>/gi, " ").replace(/!\[[^\]]*\]\([^\n]*$|!\[[^\n]*$/g, " ").replace(/<[^>]+>|https?:\/\/\S+/g, " ").replace(/\\[\[\]()]/g, "").replace(/^网站题目[：:]\s*/, "").replace(/\s+/g, " ").trim().slice(0, 55) || `${kind}\uFF08\u89C1\u539F\u56FE\uFF09`;
}
function nativeTags(values) {
  if (typeof values === "string") values = values.split(/[,，\s]+/);
  return [...new Set((values || []).map((v) => String(v).trim().replace(/^#+/, "").replace(/[^\p{L}\p{N}_/\-]/gu, "_").replace(/[/_]+$/, "").replace(/^[/_]+/, "").replace(/\/+/g, "/")).filter(Boolean).map((v) => /^\d+$/.test(v) ? "\u6807\u7B7E/" + v : v))];
}
function enrichQuestion(q, nodes = []) {
  q.title = cleanTitle(q.title || q.content, q.type);
  q.tags = nativeTags(q.tags);
  q.knowledge_tree_ids = (q.knowledge_tree_ids || []).map(String);
  q.knowledge_ids = (q.knowledge_ids || []).map(String);
  const names = /* @__PURE__ */ new Map();
  for (const n of nodes) {
    const key = n.name.trim();
    names.set(key, [...names.get(key) || [], n]);
  }
  for (const name2 of typeof q.original_payload?.knowledges === "string" ? q.original_payload.knowledges.split(/[,，、]/) : []) {
    const matches = names.get(name2.trim()) || [];
    if (matches.length === 1 && !q.knowledge_tree_ids.includes(String(matches[0].id))) q.knowledge_tree_ids.push(String(matches[0].id));
  }
  for (const n of nodes) if (q.knowledge_tree_ids.includes(String(n.id))) {
    q.tags.push("\u8003\u70B9/" + n.name);
    if (n.knowledge_id != null && !q.knowledge_ids.includes(String(n.knowledge_id))) q.knowledge_ids.push(String(n.knowledge_id));
  }
  q.tags = nativeTags(q.tags);
  return q;
}
var fileName = (s) => String(s).replace(/[<>:"/\\|?*\x00-\x1f\[\]#^]/g, " ").replace(/\s+/g, " ").trim().replace(/[. ]+$/, "").slice(0, 55) || "\u9898\u76EE";
function groupFolder(q, names, knowledge = [], chapters = []) {
  const scope = q.subject_id && q.phase_id ? `${names.phases?.[q.phase_id] || "\u5B66\u6BB5" + q.phase_id} \xB7 ${names.subjects?.[q.subject_id] || "\u5B66\u79D1" + q.subject_id}` : "\u672A\u6307\u5B9A\u5B66\u79D1";
  let group = "\u5F85\u5206\u7C7B";
  if (q.knowledge_tree_ids?.length) {
    const map2 = new Map(knowledge.map((n2) => [String(n2.id), n2]));
    let n = map2.get(String(q.knowledge_tree_ids[0]));
    const seen = /* @__PURE__ */ new Set();
    while (n && map2.has(String(n.parent_id)) && !seen.has(String(n.id))) {
      seen.add(String(n.id));
      n = map2.get(String(n.parent_id));
    }
    if (n) group = n.name;
  } else if (q.chapter_ids?.length) {
    const n = chapters.find((n2) => String(n2.id) === String(q.chapter_ids[0]));
    if (n) group = (names.editions?.[q.edition_id] || "\u6559\u6750") + " \xB7 " + n.name;
  }
  return fileName(scope) + "/" + fileName(group);
}

// src/core.js
var BASE = "https://tizhuang.qcscience.cc/api";
var PROPS = { schema: "\u6570\u636E\u683C\u5F0F", id: "\u9898\u76EE\u7F16\u53F7", title: "\u9898\u76EE\u540D\u79F0", content_format: "\u6B63\u6587\u683C\u5F0F", status: "\u5BA1\u6838\u72B6\u6001", type: "\u9898\u578B", score: "\u5206\u503C", difficulty: "\u96BE\u5EA6", subject_id: "\u5B66\u79D1\u7F16\u53F7", phase_id: "\u5B66\u6BB5\u7F16\u53F7", grade_id: "\u5E74\u7EA7\u7F16\u53F7", edition_id: "\u6559\u6750\u7248\u672C\u7F16\u53F7", knowledge_tree_ids: "\u77E5\u8BC6\u8282\u70B9\u7F16\u53F7", knowledge_ids: "\u7CBE\u786E\u77E5\u8BC6\u7F16\u53F7", chapter_ids: "\u6559\u6750\u7AE0\u8282\u7F16\u53F7", tags: "\u6807\u7B7E", created_at: "\u521B\u5EFA\u65F6\u95F4", updated_at: "\u66F4\u65B0\u65F6\u95F4", source_kind: "\u6765\u6E90\u7C7B\u578B", source_provider: "\u6765\u6E90\u5E73\u53F0", source_external_id: "\u6765\u6E90\u9898\u53F7", source_label: "\u6765\u6E90\u8BF4\u660E" };
var scopeKeys = ["subject_id", "phase_id", "grade_id", "edition_id"];
function directoryNodes(scope, nodes) {
  return Array.isArray(nodes) ? scope.knowledge_tree_id && !scope.chapter_id ? { chapters: [], knowledge: nodes } : { chapters: nodes, knowledge: [] } : { chapters: nodes?.chapters || [], knowledge: nodes?.knowledge || [] };
}
function requireScope(s, nodes) {
  for (const k of ["subject_id", "phase_id"]) if (!Number.isSafeInteger(Number(s[k])) || Number(s[k]) <= 0) throw Error("\u8BF7\u9009\u62E9\u5B66\u79D1\u548C\u5B66\u6BB5\u3002");
  for (const k of ["edition_id", "grade_id", "chapter_id", "knowledge_tree_id"]) if (s[k] != null && s[k] !== "" && (!Number.isSafeInteger(Number(s[k])) || Number(s[k]) <= 0)) throw Error("\u7B5B\u9009\u7F16\u53F7\u65E0\u6548\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9\u3002");
  const { chapters, knowledge } = directoryNodes(s, nodes);
  if (s.chapter_id) {
    if (!s.edition_id) throw Error("\u9009\u62E9\u7AE0\u8282\u65F6\u9700\u8981\u6307\u5B9A\u6559\u6750\u7248\u672C\u3002");
    const node2 = chapters.find((n) => String(n.id) === String(s.chapter_id));
    if (!node2 || ["subject_id", "phase_id", "edition_id"].some((k) => String(node2[k]) !== String(s[k]))) throw Error("\u7AE0\u8282\u4E0D\u5C5E\u4E8E\u5F53\u524D\u6559\u6750\uFF0C\u8BF7\u91CD\u65B0\u52A0\u8F7D\u76EE\u5F55\u3002");
    if (s.grade_id && String(node2.grade_id) !== String(s.grade_id)) throw Error("\u7AE0\u8282\u4E0D\u5C5E\u4E8E\u6240\u9009\u5E74\u7EA7\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9\u3002");
  }
  if (s.knowledge_tree_id && !knowledge.some((n) => String(n.id) === String(s.knowledge_tree_id))) throw Error("\u77E5\u8BC6\u70B9\u4E0D\u5C5E\u4E8E\u5F53\u524D\u5B66\u79D1\u5B66\u6BB5\u7684\u77E5\u8BC6\u6811\u3002");
}
function queryFilters(s, nodes) {
  requireScope(s, nodes);
  if (s.chapter_id && s.knowledge_tree_id) throw Error("\u7AE0\u8282\u548C\u77E5\u8BC6\u70B9\u8BF7\u9009\u62E9\u5176\u4E2D\u4E00\u4E2A\uFF0C\u4E5F\u53EF\u4EE5\u90FD\u4E0D\u9009\u3002");
  const filters = {};
  for (const k of ["subject_id", "edition_id", "grade_id", "chapter_id", "knowledge_tree_id"]) if (s[k]) filters[k] = s[k];
  if (!s.chapter_id && !s.knowledge_tree_id) {
    const tree = validateKnowledge(directoryNodes(s, nodes).knowledge);
    const roots = tree.filter((n) => !n.parent_id).map((n) => n.id);
    if (!roots.length) throw Error("\u5F53\u524D\u5B66\u6BB5\u7684\u77E5\u8BC6\u76EE\u5F55\u5C1A\u672A\u52A0\u8F7D\uFF0C\u65E0\u6CD5\u786E\u5B9A\u53D6\u9898\u8303\u56F4\uFF0C\u8BF7\u91CD\u65B0\u52A0\u8F7D\u76EE\u5F55\u3002");
    filters.knowledge_tree_ids = roots;
  }
  return filters;
}
function validateKnowledge(nodes) {
  if (!Array.isArray(nodes) || nodes.length >= 5e3) throw Error("\u77E5\u8BC6\u6811\u4E0D\u5B8C\u6574\uFF0C\u505C\u6B62\u53D6\u9898\u3002");
  const map2 = /* @__PURE__ */ new Map();
  for (const n of nodes) {
    if (!Number.isSafeInteger(n.id) || n.id <= 0 || !n.name || map2.has(String(n.id))) throw Error("\u77E5\u8BC6\u6811\u6570\u636E\u4E0D\u4E00\u81F4\u3002");
    map2.set(String(n.id), n);
  }
  for (const n of nodes) {
    let p = n;
    const seen = /* @__PURE__ */ new Set();
    while (p) {
      if (seen.has(String(p.id))) throw Error("\u77E5\u8BC6\u6811\u5B58\u5728\u5FAA\u73AF\u3002");
      seen.add(String(p.id));
      if (p.parent_id && !map2.has(String(p.parent_id))) throw Error("\u77E5\u8BC6\u6811\u7F3A\u5C11\u7236\u8282\u70B9\u3002");
      p = map2.get(String(p.parent_id));
    }
  }
  return nodes;
}
function contextFromProperties(meta, path = "") {
  const id = (v) => Number.isSafeInteger(Number(v)) && Number(v) > 0 ? Number(v) : null;
  if (!meta || !id(meta["\u5B66\u79D1\u7F16\u53F7"]) || !id(meta["\u5B66\u6BB5\u7F16\u53F7"])) return null;
  const base = { subject_id: id(meta["\u5B66\u79D1\u7F16\u53F7"]), phase_id: id(meta["\u5B66\u6BB5\u7F16\u53F7"]) };
  if (id(meta["\u7AE0\u8282\u7F16\u53F7"]) && id(meta["\u6559\u6750\u7248\u672C\u7F16\u53F7"])) return { mode: "chapter", scope: { ...base, edition_id: id(meta["\u6559\u6750\u7248\u672C\u7F16\u53F7"]), chapter_id: id(meta["\u7AE0\u8282\u7F16\u53F7"]), grade_id: id(meta["\u5E74\u7EA7\u7F16\u53F7"]) }, path };
  if (!Array.isArray(meta["\u77E5\u8BC6\u8282\u70B9\u7F16\u53F7"]) && id(meta["\u77E5\u8BC6\u8282\u70B9\u7F16\u53F7"])) return { mode: "knowledge", scope: { ...base, knowledge_tree_id: id(meta["\u77E5\u8BC6\u8282\u70B9\u7F16\u53F7"]) }, path };
  return null;
}
function cursorKey(s) {
  return JSON.stringify(["subject_id", "phase_id", "edition_id", "chapter_id", "grade_id", "knowledge_tree_id"].map((k) => s[k] ?? null));
}
var ApiError = class extends Error {
  constructor(message, status, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
var RequestTimeout = class extends Error {
};
async function boundedRequest(transport, request, timeoutMs) {
  let timer;
  try {
    return await Promise.race([Promise.resolve().then(() => transport(request)), new Promise((_, reject) => {
      timer = setTimeout(() => reject(new RequestTimeout("request_timeout")), timeoutMs);
    })]);
  } finally {
    clearTimeout(timer);
  }
}
function validateChapters(nodes, s) {
  if (!Array.isArray(nodes) || nodes.length >= 1e3) throw Error("\u6559\u6750\u76EE\u5F55\u4E0D\u5B8C\u6574\uFF0C\u505C\u6B62\u53D6\u9898\u3002");
  const map2 = /* @__PURE__ */ new Map();
  for (const n of nodes) {
    if (!Number.isSafeInteger(n.id) || n.id <= 0 || !n.name || map2.has(String(n.id)) || ["subject_id", "phase_id", "edition_id"].some((k) => String(n[k]) !== String(s[k]))) throw Error("\u6559\u6750\u76EE\u5F55\u6570\u636E\u4E0D\u4E00\u81F4\u3002");
    map2.set(String(n.id), n);
  }
  for (const n of nodes) {
    let p = n;
    const seen = /* @__PURE__ */ new Set();
    while (p) {
      if (seen.has(String(p.id))) throw Error("\u6559\u6750\u76EE\u5F55\u5B58\u5728\u5FAA\u73AF\u3002");
      seen.add(String(p.id));
      if (p.parent_id && !map2.has(String(p.parent_id))) throw Error("\u6559\u6750\u76EE\u5F55\u7F3A\u5C11\u7236\u7AE0\u8282\u3002");
      p = map2.get(String(p.parent_id));
    }
  }
  return nodes;
}
var Api = class {
  constructor(transport, key, { cache = new MetadataCache(), timeouts = {}, scopedDirectories = false } = {}) {
    this.transport = transport;
    this.scopedDirectories = scopedDirectories;
    this.directoryPolicy = "unknown";
    this.key = key;
    this.cache = cache;
    this.timeouts = { metadata: 1e4, quota: 1e4, questions: 35e3, ...timeouts };
  }
  async get(route, params = {}, paid = false) {
    const protectedRoute = route === "/v1/quota" || route === "/v1/questions" || route.startsWith("/v1/local-bank/meta/") || route === "/v1/local-bank/directory-quota";
    const key = protectedRoute ? this.key()?.trim() : null;
    if (protectedRoute && !key) throw Error("\u8BF7\u5148\u5728\u63D2\u4EF6\u8BBE\u7F6E\u4E2D\u586B\u5199\u81EA\u5DF1\u7684\u9898\u5E84 API Key\u3002");
    const url = new URL(BASE + route);
    for (const [k, v] of Object.entries(params)) if (v !== null && v !== void 0 && v !== "") for (const item of Array.isArray(v) ? v : [v]) url.searchParams.append(k, String(item));
    const timeout = paid ? this.timeouts.questions : route === "/v1/quota" ? this.timeouts.quota : this.timeouts.metadata;
    let r;
    try {
      r = await boundedRequest(this.transport, { url: url.href, method: "GET", headers: key ? { "X-API-Key": key } : {}, throw: false }, timeout);
    } catch (error) {
      if (error instanceof RequestTimeout) throw new ApiError(paid ? "\u53D6\u9898\u7B49\u5F85\u8D85\u65F6\uFF0C\u53EF\u80FD\u5DF2\u7ECF\u6263\u989D\u3002\u8BF7\u5237\u65B0\u989D\u5EA6\u786E\u8BA4\u540E\u518D\u51B3\u5B9A\u662F\u5426\u91CD\u65B0\u83B7\u53D6\uFF1B\u4E0D\u4F1A\u81EA\u52A8\u91CD\u8BD5\u3002" : `${route === "/v1/quota" ? "\u989D\u5EA6\u67E5\u8BE2" : "\u76EE\u5F55\u52A0\u8F7D"}\u8D85\u8FC7 ${timeout / 1e3} \u79D2\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002\u53EF\u4EE5\u7EE7\u7EED\u5207\u6362\u9009\u62E9\u3002`, 0, "request_timeout");
      throw Error(paid ? "\u53D6\u9898\u8BF7\u6C42\u672A\u6536\u5230\u786E\u5B9A\u7ED3\u679C\uFF0C\u53EF\u80FD\u5DF2\u7ECF\u6263\u989D\u3002\u8BF7\u5237\u65B0\u989D\u5EA6\u540E\u518D\u51B3\u5B9A\u662F\u5426\u91CD\u65B0\u83B7\u53D6\u3002" : "\u7F51\u7EDC\u8FDE\u63A5\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002");
    }
    let code = "";
    try {
      code = r.json?.detail?.code || r.json?.code || "";
    } catch {
    }
    if (code === "directory_scope_limit") throw new ApiError("\u76EE\u5F55\u8303\u56F4\u989D\u5EA6\u5DF2\u7528\u5B8C\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\u589E\u52A0\uFF1B\u5DF2\u5F00\u901A\u7684\u5B66\u6BB5\u548C\u5B66\u79D1\u53EF\u7EE7\u7EED\u4F7F\u7528\u3002", r.status, code);
    if (r.status === 401 || r.status === 403) throw new ApiError("\u51ED\u8BC1\u65E0\u6548\u6216\u65E0\u8BBF\u95EE\u6743\u9650\uFF0C\u8BF7\u68C0\u67E5\u81EA\u5DF1\u7684 API Key\u3002", r.status, code);
    if (r.status === 429) throw new ApiError(code === "query_concurrency_limit" ? "\u7F51\u7AD9\u6B63\u5728\u5904\u7406\u4F60\u7684\u53E6\u4E00\u6761\u67E5\u9898\u8BF7\u6C42\uFF0C\u8BF7\u7A0D\u540E\u624B\u52A8\u91CD\u8BD5\u3002" : "\u989D\u5EA6\u4E0D\u8DB3\u6216\u8BF7\u6C42\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF7\u5237\u65B0\u989D\u5EA6\uFF1B\u4E0D\u4F1A\u81EA\u52A8\u91CD\u8BD5\u3002", r.status, code);
    if (r.status < 200 || r.status >= 300) {
      let msg = code === "query_timeout" || r.status === 504 ? "\u67E5\u9898\u8D85\u65F6\uFF0C\u7F51\u7AD9\u6CA1\u6709\u8FD4\u56DE\u9898\u76EE\u3002" : r.status === 400 || r.status === 422 ? "\u53D6\u9898\u6761\u4EF6\u65E0\u6548\uFF0C\u8BF7\u91CD\u65B0\u52A0\u8F7D\u76EE\u5F55\u5E76\u68C0\u67E5\u6559\u6750\u3001\u7AE0\u8282\u3002" : `\u7F51\u7AD9\u67E5\u8BE2\u5931\u8D25\uFF08HTTP ${r.status}\uFF09\u3002`;
      throw new ApiError(msg + (paid ? " \u4F1A\u5237\u65B0\u989D\u5EA6\u6838\u5BF9\uFF0C\u4E0D\u4F1A\u81EA\u52A8\u91CD\u8BD5\u3002" : ""), r.status, code);
    }
    try {
      return r.json;
    } catch {
      throw Error(paid ? "\u53D6\u9898\u54CD\u5E94\u65E0\u6CD5\u8BFB\u53D6\uFF0C\u8BF7\u5148\u5237\u65B0\u989D\u5EA6\u786E\u8BA4\u6263\u51CF\u3002" : "\u7F51\u7AD9\u6570\u636E\u65E0\u6CD5\u8BFB\u53D6\u3002");
    }
  }
  async directoryCapabilities(force = false) {
    if (force) this.directoryCheck = null;
    if (!this.directoryCheck) this.directoryCheck = (async () => {
      try {
        const data = await this.get("/v1/local-bank/capabilities");
        if (data?.directory_quota !== true) throw Error("\u76EE\u5F55\u989D\u5EA6\u670D\u52A1\u54CD\u5E94\u65E0\u6548");
        this.directoryPolicy = "enabled";
        return true;
      } catch (error) {
        if (error.status === 404) {
          this.directoryPolicy = "legacy";
          return false;
        }
        this.directoryCheck = null;
        throw error;
      }
    })();
    return this.directoryCheck;
  }
  async meta(name2, params = {}, options = {}) {
    const scoped = this.scopedDirectories && ["chapters", "knowledge-points"].includes(name2);
    const enabled = scoped ? await this.directoryCapabilities(options.force) : false;
    if (enabled) {
      if (!this.key()?.trim()) throw Error("\u8BF7\u5148\u8BBE\u7F6E\u81EA\u5DF1\u7684\u9898\u5E84 API Key\u3002\u76EE\u5F55\u6309\u5B66\u6BB5\u548C\u5B66\u79D1\u5F00\u901A\uFF0C\u6BCF\u4E2A\u8D26\u53F7\u9ED8\u8BA4 5 \u4E2A\u3002");
      return this.get("/v1/local-bank/meta/" + name2, params);
    }
    return this.cache.get(name2, params, () => this.get("/v1/meta/" + name2, params), options);
  }
  directoryQuota() {
    return this.get("/v1/local-bank/directory-quota");
  }
  quota() {
    return this.get("/v1/quota");
  }
  async questions(s, nodes, count, options = {}) {
    const filters = queryFilters(s, nodes);
    if (!Number.isInteger(count) || count < 1 || count > 20) throw Error("\u6BCF\u6B21\u83B7\u53D6\u9898\u6570\u987B\u4E3A 1 \u5230 20\u3002");
    const quota = await this.quota();
    options.onQuota?.(quota);
    if (!Number.isFinite(quota.remaining) || quota.remaining < count) throw Error(`\u4ECA\u65E5\u5269\u4F59\u989D\u5EA6\u4E0D\u8DB3 ${count} \u9898\u3002`);
    const data = await this.get("/v1/questions", { ...filters, limit: count, offset: options.offset || 0, random_order: false }, true);
    if (!data || !Array.isArray(data.items) || data.items.length > count) throw Error("\u53D6\u9898\u54CD\u5E94\u5F02\u5E38\uFF0C\u53EF\u80FD\u5DF2\u6263\u989D\u3002\u8BF7\u5237\u65B0\u989D\u5EA6\u786E\u8BA4\u3002");
    return data;
  }
};
function redacted(raw, solutions) {
  const clone2 = JSON.parse(JSON.stringify(raw));
  function walk(q) {
    if (!solutions) for (const k of ["answer", "answer_html", "analysis", "analysis_html"]) q[k] = "";
    for (const c of q.subquestions || []) walk(c);
  }
  walk(clone2);
  return clone2;
}
function questionFrom(raw, s, solutions, toMarkdown) {
  if (raw.id == null || String(raw.subject_id) !== String(s.subject_id)) throw Error("\u8FD4\u56DE\u9898\u76EE\u7684\u7F16\u53F7\u6216\u5B66\u79D1\u65E0\u6548\uFF1B\u4FDD\u7559\u7ED3\u679C\u4F9B\u6838\u67E5\uFF0C\u4E0D\u81EA\u52A8\u4FDD\u5B58\u3002");
  const source = redacted(raw, solutions);
  function parts(v) {
    const opts = v.options_html && Object.keys(v.options_html).length ? v.options_html : v.options || {};
    return [toMarkdown(v.title_html || v.title || "") + Object.entries(opts).map(([k, t]) => "\n\n" + k + ". " + toMarkdown(String(t))).join(""), toMarkdown(v.answer_html || v.answer || ""), toMarkdown(v.analysis_html || v.analysis || "")];
  }
  const [content, answer, analysis] = parts(source);
  const sections = { content, answer, analysis };
  for (const [i, c] of (source.subquestions || []).entries()) {
    const p = parts(c);
    for (const [j, k] of ["content", "answer", "analysis"].entries()) if (p[j]) sections[k] += `

#### \uFF08${i + 1}\uFF09

${p[j]}`;
  }
  if (!sections.content.trim() || Object.values(sections).some((x) => x.includes("<!-- bank:"))) throw Error("\u9898\u76EE\u6B63\u6587\u65E0\u6548\u3002");
  const now = (/* @__PURE__ */ new Date()).toISOString();
  return { schema: "tizhuang.question/v1", id: crypto.randomUUID(), title: cleanTitle(toMarkdown(raw.title || raw.title_html || "\u7F51\u7AD9\u9898\u76EE"), raw.question_type || "\u9898\u76EE"), ...sections, content_format: "markdown", status: "draft", type: raw.question_type || "\u672A\u5206\u7C7B", score: 5, difficulty: raw.difficulty ?? null, subject_id: Number(s.subject_id), phase_id: Number(s.phase_id), grade_id: raw.grade_id ?? null, edition_id: s.edition_id ? Number(s.edition_id) : null, knowledge_tree_ids: s.knowledge_tree_id ? [String(s.knowledge_tree_id)] : [], knowledge_ids: [], chapter_ids: s.chapter_id ? [String(s.chapter_id)] : [], tags: ["\u7F51\u7AD9\u9898\u76EE"], source: { kind: "website", provider: "tizhuang", external_id: String(raw.id), label: raw.source || "\u9898\u5E84\u7F51\u7AD9" }, assets: [], created_at: now, updated_at: now, original_payload: source };
}
function noteText(q, assetDir = "\u9644\u4EF6", path = "\u9898\u76EE\u5E93/\u9898\u76EE.md") {
  const fields = {};
  for (const [key, value] of Object.entries(q)) if (PROPS[key]) fields[PROPS[key]] = key === "status" ? value === "reviewed" ? "\u5DF2\u6838\u5BF9" : "\u5F85\u6838\u5BF9" : value;
  for (const k of ["kind", "provider", "external_id", "label"]) fields[PROPS["source_" + k]] = q.source[k] || "";
  delete fields["\u6807\u7B7E"];
  fields.tags = nativeTags(q.tags);
  if (q.search_text) fields["\u68C0\u7D22\u6587\u5B57"] = q.search_text;
  let text2 = "---\n" + browser_default.stringify(fields, { version: "1.1" }) + "---\n\n";
  const prefix = "../".repeat(path.split("/").length - 1) + assetDir + "/";
  for (const [key, label2] of [["content", "\u9898\u76EE"], ["answer", "\u7B54\u6848"], ["analysis", "\u89E3\u6790"]]) text2 += `## ${label2}

<!-- bank:${key}:start -->
${q[key].replaceAll("Assets/", prefix)}
<!-- bank:${key}:end -->

`;
  return text2;
}
function readNote(text2) {
  const m = text2.match(/^\uFEFF?---\r?\n([\s\S]*?)\r?\n---\r?\n/);
  if (!m) throw Error("\u9898\u76EE\u6587\u4EF6\u7F3A\u5C11\u5C5E\u6027\u3002");
  const fields = browser_default.parse(m[1]);
  const reverse = Object.fromEntries(Object.entries(PROPS).map(([k, v]) => [v, k]));
  const q = Object.fromEntries(Object.entries(fields).map(([k, v]) => [reverse[k] || k, v]));
  q.tags = nativeTags(Object.hasOwn(fields, "tags") ? fields.tags : fields["\u6807\u7B7E"]);
  q.status = { "\u5F85\u6838\u5BF9": "draft", "\u5DF2\u6838\u5BF9": "reviewed" }[q.status] || q.status || "draft";
  q.search_text = fields["\u68C0\u7D22\u6587\u5B57"] || fields.search_text || "";
  for (const key of ["knowledge_tree_ids", "knowledge_ids", "chapter_ids"]) q[key] = (q[key] || []).map(String);
  for (const k of ["content", "answer", "analysis"]) {
    const pattern = new RegExp(`<!-- bank:${k}:start -->\\r?\\n([\\s\\S]*?)\\r?\\n<!-- bank:${k}:end -->`, "g");
    const all = [...text2.matchAll(pattern)];
    if (all.length !== 1) throw Error("\u9898\u76EE\u533A\u5757\u6807\u8BB0\u7F3A\u5931\u6216\u91CD\u590D\u3002");
    q[k] = all[0][1].replace(/(?:\.\.\/)+(?:资料\/)?(?:附件|Assets)\//g, "Assets/");
  }
  q.source = { kind: q.source_kind, provider: q.source_provider, external_id: String(q.source_external_id || ""), label: q.source_label || "" };
  return q;
}
var safeName = (s) => String(s).replace(/[<>:"/\\|?*\x00-\x1f\[\]#^]/g, " ").replace(/\s+/g, " ").trim().replace(/[. ]+$/, "").slice(0, 80) || "\u7F51\u7AD9\u9898\u76EE";
async function hash(bytes) {
  return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))).map((x) => x.toString(16).padStart(2, "0")).join("");
}
async function localize(q, transport, document2) {
  const pending = /* @__PURE__ */ new Map();
  const downloaded = [];
  let total = 0;
  const references = [];
  for (const k of ["content", "answer", "analysis"]) {
    const matches = [...q[k].matchAll(/!\[[^\]]*\]\(([^\s)]+)(?:\s+"[^"]*")?\)/g), ...q[k].matchAll(/<img\b[^>]*\bsrc=["']([^"']+)["'][^>]*>/gi)];
    for (const m of matches) {
      let url = m[1];
      if (document2) {
        const el = document2.createElement("textarea");
        el.innerHTML = url;
        url = el.value;
      }
      references.push([m[1], url]);
      if (pending.has(url)) continue;
      let u;
      try {
        u = new URL(url);
      } catch {
        throw Error("\u56FE\u7247\u5730\u5740\u4E0D\u53D7\u652F\u6301\uFF0C\u505C\u6B62\u4FDD\u5B58\u3002");
      }
      if (u.protocol !== "https:" || u.username || u.password || u.port || /^(localhost|127\.|10\.|192\.168\.|169\.254\.|\[|172\.(1[6-9]|2\d|3[01])\.)/i.test(u.hostname)) throw Error("\u56FE\u7247\u5730\u5740\u4E0D\u53D7\u652F\u6301\uFF0C\u505C\u6B62\u4FDD\u5B58\u3002");
      let r;
      try {
        r = await boundedRequest(transport, { url: u.href, method: "GET", headers: {}, throw: false }, 2e4);
      } catch (error) {
        if (error instanceof RequestTimeout) throw Error("\u56FE\u7247\u4E0B\u8F7D\u8D85\u8FC7 20 \u79D2\uFF0C\u8BF7\u91CD\u8BD5\u4FDD\u5B58\uFF0C\u65E0\u9700\u91CD\u65B0\u83B7\u53D6\u9898\u76EE\u3002");
        throw error;
      }
      const mime = (r.headers["content-type"] || r.headers["Content-Type"] || "").split(";")[0].toLowerCase();
      const ext = { "image/png": ".png", "image/jpeg": ".jpg", "image/gif": ".gif", "image/webp": ".webp" }[mime];
      if (r.status !== 200 || !ext || r.arrayBuffer.byteLength > 10 * 1024 * 1024) throw Error("\u56FE\u7247\u4E0B\u8F7D\u5931\u8D25\u6216\u683C\u5F0F/\u5927\u5C0F\u4E0D\u53D7\u652F\u6301\uFF0C\u8BF7\u91CD\u8BD5\u4FDD\u5B58\u3002");
      total += r.arrayBuffer.byteLength;
      if (total > 40 * 1024 * 1024) throw Error("\u5355\u9898\u9644\u4EF6\u8D85\u8FC7 40 MB\u3002");
      const sha = await hash(r.arrayBuffer);
      const path = `Assets/${sha}${ext}`;
      pending.set(url, path);
      downloaded.push({ path, sha256: sha, data: r.arrayBuffer });
    }
  }
  const copy = structuredClone(q);
  for (const k of ["content", "answer", "analysis"]) for (const [original, url] of references) copy[k] = copy[k].replaceAll(original, pending.get(url));
  if (["content", "answer", "analysis"].some((k) => /!\[[^\]]*\]\((?!Assets\/)/.test(copy[k]))) throw Error("\u9898\u76EE\u5305\u542B\u672A\u5F52\u6863\u56FE\u7247\uFF0C\u505C\u6B62\u4FDD\u5B58\u3002");
  copy.assets = downloaded.map(({ path, sha256 }) => ({ path, sha256 }));
  return { question: copy, downloaded };
}
var Store = class {
  constructor(io) {
    this.io = io;
    this.busy = false;
    this.directoryQueue = Promise.resolve();
    this.materializedTrees = /* @__PURE__ */ new Set();
  }
  async mkdir(path) {
    let p = "";
    for (const part of path.split("/")) {
      p = p ? `${p}/${part}` : part;
      if (!await this.io.exists(p)) await this.io.mkdir(p);
    }
  }
  // Persist a downloaded knowledge tree so classification, filtering and the onboarding guide see it.
  // An existing snapshot is teacher-owned (saved questions are validated against it): never overwrite it.
  async saveTaxonomy(subject, phase, nodes) {
    await this.init();
    const path = `.bank/taxonomy/${subject}-${phase}.json`;
    const exists = await this.io.exists(path);
    if (!exists) {
      validateKnowledge(nodes);
      await this.io.write(path, JSON.stringify({ schema: "tizhuang.taxonomy/v1", subject_id: subject, phase_id: phase, downloaded_at: (/* @__PURE__ */ new Date()).toISOString(), nodes }, null, 2));
    }
    await this.syncKnowledgeDirectories();
    return !exists;
  }
  async syncKnowledgeDirectories() {
    const task = this.directoryQueue.catch(() => {
    }).then(async () => {
      for (const path of [...await this.files(".bank/taxonomy", ".json"), ...await this.files(".bank/textbooks", ".json")]) {
        if (this.materializedTrees.has(path)) continue;
        const data = await this.json(path);
        if (path.startsWith(".bank/textbooks/")) validateChapters(data.nodes, data);
        else validateKnowledge(data.nodes);
        if (!Number.isSafeInteger(data.subject_id) || data.subject_id <= 0 || !Number.isSafeInteger(data.phase_id) || data.phase_id <= 0) throw Error("\u77E5\u8BC6\u6811\u5B66\u79D1\u5B66\u6BB5\u65E0\u6548\u3002");
        await materializeKnowledge(this, data);
        this.materializedTrees.add(path);
      }
    });
    this.directoryQueue = task;
    return task;
  }
  async saveTextbook(scope, nodes) {
    await this.init();
    validateChapters(nodes, scope);
    const path = `.bank/textbooks/${scope.subject_id}-${scope.phase_id}-${scope.edition_id}.json`;
    if (!await this.io.exists(path)) await this.io.write(path, JSON.stringify({ schema: "tizhuang.textbook/v1", subject_id: scope.subject_id, phase_id: scope.phase_id, edition_id: scope.edition_id, downloaded_at: (/* @__PURE__ */ new Date()).toISOString(), nodes }, null, 2));
    await this.syncKnowledgeDirectories();
  }
  async init() {
    if (await this.io.exists("Questions")) throw Error("\u68C0\u6D4B\u5230\u65E7\u7248\u82F1\u6587\u9898\u5E93\uFF0C\u8BF7\u5148\u4F7F\u7528\u672C\u5730 skill \u8FC1\u79FB\u4E2D\u6587\u76EE\u5F55\u3002");
    if (await this.io.exists(".bank/config.json")) {
      const cfg = JSON.parse(await this.io.read(".bank/config.json"));
      if (cfg.schema !== "tizhuang.bank/v1") throw Error("\u672C\u5730\u9898\u5E93\u683C\u5F0F\u4E0D\u517C\u5BB9\u3002");
    }
    const modern = !await this.io.exists(".bank/config.json") || JSON.parse(await this.io.read(".bank/config.json")).ui_layout === "teacher/v2";
    this.assetDir = modern ? "\u8D44\u6599/\u9644\u4EF6" : "\u9644\u4EF6";
    for (const p of ["\u9898\u76EE\u5E93", this.assetDir, ".bank/records", ".bank/textbooks", ".bank/taxonomy", modern ? "\u6559\u5B66\u7B14\u8BB0" : "\u77E5\u8BC6\u5E93/\u6211\u7684\u6559\u5B66\u7B14\u8BB0", modern ? "\u8D44\u6599/\u6559\u6750\u76EE\u5F55" : "\u6559\u6750\u76EE\u5F55", "\u8BD5\u5377", "\u5F85\u6574\u7406"]) await this.mkdir(p);
    if (!await this.io.exists(".bank/config.json")) await this.io.write(".bank/config.json", JSON.stringify({ schema: "tizhuang.bank/v1", ui_layout: modern ? "teacher/v2" : "zh-CN/v1", created_at: (/* @__PURE__ */ new Date()).toISOString() }, null, 2));
    if (!modern && !await this.io.exists("\u9898\u5E93\u5165\u53E3.md")) await this.io.write("\u9898\u5E93\u5165\u53E3.md", "# \u6211\u7684\u6559\u5E08\u9898\u5E93\n\n- [[\u9898\u76EE\u5BFC\u822A|\u6D4F\u89C8\u9898\u76EE]]\n- \u4F7F\u7528\u5DE6\u4FA7\u4E66\u5E93\u56FE\u6807\u6253\u5F00\u9898\u5E93\u9996\u9875\u3002\n- \u5728 Agent \u4E2D\u4F7F\u7528 tizhuang-local-bank \u68C0\u7D22\u3001\u7EC4\u5377\u3002\n");
  }
  async files(folder, extension = ".md") {
    if (!await this.io.exists(folder)) return [];
    const listing = await this.io.list(folder);
    const all = listing.files.filter((p) => p.endsWith(extension));
    for (const p of listing.folders || []) all.push(...await this.files(p, extension));
    return [...new Set(all)];
  }
  async existing() {
    const rows = [];
    for (const path of await this.files("\u9898\u76EE\u5E93")) rows.push({ path, q: readNote(await this.io.read(path)) });
    return rows;
  }
  async json(path, fallback = {}) {
    return await this.io.exists(path) ? JSON.parse(await this.io.read(path)) : fallback;
  }
  async saveCatalog(data) {
    await this.mkdir(".bank/catalog");
    const names = await this.json(".bank/catalog/names.json", { subjects: {}, phases: {}, editions: {} });
    for (const [key, rows] of Object.entries(data)) for (const n of rows) names[key][n.id] = n.name;
    await this.io.write(".bank/catalog/names.json", JSON.stringify(names));
  }
  async save(q, nodes, downloads) {
    if (this.busy) throw Error("\u6B63\u5728\u4FDD\u5B58\uFF0C\u8BF7\u7B49\u5F85\u5B8C\u6210\u3002");
    this.busy = true;
    try {
      await this.init();
      const requested = { subject_id: q.subject_id, phase_id: q.phase_id, edition_id: q.edition_id, chapter_id: q.chapter_ids[0], knowledge_tree_id: q.knowledge_tree_ids[0], grade_id: null };
      const directory = directoryNodes(requested, nodes);
      requireScope(requested, directory);
      validateKnowledge(directory.knowledge);
      validateChapters(directory.chapters, q);
      const rows = await this.existing();
      for (const old of rows) {
        const sameScope = scopeKeys.every((k) => String(old.q[k] ?? null) === String(q[k] ?? null));
        if (sameScope && old.q.content.trim() === q.content.trim()) return { action: "duplicate", path: old.path };
        if (old.q.source.provider === q.source.provider && old.q.source.external_id === q.source.external_id && old.q.content !== q.content) throw Error("\u540C\u6765\u6E90\u9898\u76EE\u6B63\u6587\u5DF2\u6709\u4E0D\u540C\u7248\u672C\uFF0C\u8BF7\u4EBA\u5DE5\u5904\u7406\uFF1B\u4E0D\u4F1A\u8986\u76D6\u672C\u5730\u6587\u4EF6\u3002");
      }
      const tree = (await this.json(`.bank/taxonomy/${q.subject_id}-${q.phase_id}.json`)).nodes || directory.knowledge;
      enrichQuestion(q, tree);
      q.title = cleanTitle(q.title, q.type);
      const modern = this.assetDir === "\u8D44\u6599/\u9644\u4EF6";
      const folder = modern ? "\u9898\u76EE\u5E93/" + groupFolder(q, await this.json(".bank/catalog/names.json"), tree, directory.chapters) : "\u9898\u76EE\u5E93";
      await this.mkdir(folder);
      const stem = (hasImage(q) ? "\u56FE \xB7 " : "") + safeName(q.title);
      let path = `${folder}/${stem}.md`;
      let suffix = 2;
      while (await this.io.exists(path)) path = `${folder}/${stem}\uFF08${suffix++}\uFF09.md`;
      if (await this.io.exists(`.bank/records/${q.id}.json`)) throw Error("\u6765\u6E90\u8BB0\u5F55\u7F16\u53F7\u51B2\u7A81\uFF0C\u505C\u6B62\u4FDD\u5B58\u3002");
      for (const a of downloads) {
        if (await hash(a.data) !== a.sha256 || a.path !== `Assets/${a.sha256}${a.path.slice(a.path.lastIndexOf("."))}`) throw Error("\u9644\u4EF6\u6821\u9A8C\u5931\u8D25\u3002");
        const local = this.assetDir + "/" + a.path.split("/").pop();
        if (await this.io.exists(local)) {
          if (await hash(await this.io.readBinary(local)) !== a.sha256) throw Error("\u5DF2\u6709\u9644\u4EF6\u635F\u574F\u3002");
        } else await this.io.writeBinary(local, a.data);
      }
      for (const [kind, list] of [["knowledge", directory.knowledge], ["chapter", directory.chapters]]) {
        if (!list.length) continue;
        const knowledge = kind === "knowledge";
        const snapshot = knowledge ? `.bank/taxonomy/${q.subject_id}-${q.phase_id}.json` : `.bank/textbooks/${q.subject_id}-${q.phase_id}-${q.edition_id}.json`;
        if (await this.io.exists(snapshot)) {
          const saved = JSON.parse(await this.io.read(snapshot));
          if (saved.subject_id !== q.subject_id || saved.phase_id !== q.phase_id) throw Error("\u5DF2\u6709\u76EE\u5F55\u5B66\u79D1\u5B66\u6BB5\u4E0D\u4E00\u81F4\u3002");
          if (knowledge) validateKnowledge(saved.nodes);
          else validateChapters(saved.nodes, q);
          requireScope(requested, { ...directory, [knowledge ? "knowledge" : "chapters"]: saved.nodes });
        } else await this.io.write(snapshot, JSON.stringify({ schema: knowledge ? "tizhuang.taxonomy/v1" : "tizhuang.textbook/v1", subject_id: q.subject_id, phase_id: q.phase_id, ...knowledge ? {} : { edition_id: q.edition_id }, downloaded_at: (/* @__PURE__ */ new Date()).toISOString(), nodes: list }, null, 2));
      }
      await this.io.write(`.bank/records/${q.id}.json`, JSON.stringify(q, null, 2));
      await this.io.write(path, noteText(q, this.assetDir, path));
      rows.push({ path, q });
      if (!modern) await this.io.write("\u7F51\u7AD9\u53D6\u9898\u5BFC\u822A.md", "# \u7F51\u7AD9\u53D6\u9898\u5BFC\u822A\n\n" + rows.map(({ path: path2, q: q2 }) => `- [[${path2.slice(0, -3)}|${safeName(q2.title)}]]`).join("\n") + "\n");
      return { action: "created", path };
    } finally {
      this.busy = false;
    }
  }
};

// src/directory-navigation.js
var same = (a, b) => String(a ?? "") === String(b ?? "");
var bases = { chapter: ["\u8D44\u6599/\u6559\u6750\u76EE\u5F55", "\u6559\u6750\u76EE\u5F55"], knowledge: ["\u8D44\u6599/\u77E5\u8BC6\u76EE\u5F55", "\u77E5\u8BC6\u5E93/\u6807\u51C6\u77E5\u8BC6\u70B9", "\u77E5\u8BC6\u5E93"] };
async function findDirectoryTarget(plugin, scope, kind, sourcePath = "") {
  const { app, store } = plugin, roots = bases[kind];
  if (!roots) throw Error("\u672A\u77E5\u76EE\u5F55\u7C7B\u578B");
  const paths = app.vault.getMarkdownFiles ? app.vault.getMarkdownFiles().map((f) => f.path) : (await Promise.all(roots.map((p) => store.files(p)))).flat();
  const listed = new Set(paths), candidates = [...new Set([sourcePath, ...paths].filter((p) => p && p.endsWith(".md") && !p.startsWith(".")))];
  const nodeId = scope[kind === "chapter" ? "chapter_id" : "knowledge_tree_id"];
  let related;
  for (const path of candidates) {
    const file = app.vault.getAbstractFileByPath(path);
    if (!file || !listed.has(path) && !await store.io.exists(path)) continue;
    let properties = app.metadataCache.getFileCache(file)?.frontmatter;
    if (!properties && roots.some((r) => path.startsWith(r + "/"))) {
      try {
        const text2 = await store.io.read(path), match = text2.match(/^\uFEFF?---\r?\n([\s\S]*?)\r?\n---\r?\n/);
        if (match) properties = browser_default.parse(match[1]);
      } catch {
        continue;
      }
    }
    const context = contextFromProperties(properties, path);
    if (context?.mode !== kind || !same(context.scope.subject_id, scope.subject_id) || !same(context.scope.phase_id, scope.phase_id)) continue;
    if (kind === "chapter" && scope.edition_id && !same(context.scope.edition_id, scope.edition_id)) continue;
    if (nodeId && same(context.scope[kind === "chapter" ? "chapter_id" : "knowledge_tree_id"], nodeId)) return { file, exact: true };
    related ?? (related = path);
  }
  if (related) {
    const parts = related.split("/");
    for (let n = parts.length - 1; n > 0; n--) {
      const candidate = parts.slice(0, n).join("/") + "/" + (kind === "chapter" ? "\u6559\u6750\u76EE\u5F55.md" : "\u77E5\u8BC6\u6811.md");
      if (await store.io.exists(candidate)) return { file: app.vault.getAbstractFileByPath(candidate), exact: !nodeId };
    }
  }
  for (const base of roots) {
    const path = base + "/" + (kind === "chapter" ? "\u6559\u6750\u5BFC\u822A.md" : "\u77E5\u8BC6\u5E93\u5BFC\u822A.md");
    if (await store.io.exists(path)) return { file: app.vault.getAbstractFileByPath(path), exact: !nodeId };
  }
  throw Error("\u672C\u5730\u5C1A\u672A\u4E0B\u8F7D\u8FD9\u7C7B\u76EE\u5F55\uFF0C\u53EF\u5148\u4F7F\u7528\u4E0B\u65B9\u7B5B\u9009\uFF0C\u6216\u901A\u8FC7\u672C\u5730\u9898\u5E93 skill \u4E0B\u8F7D\u6559\u6750\uFF0F\u77E5\u8BC6\u6811\u3002");
}
async function openDirectory(plugin, view, kind) {
  const { file, exact } = await findDirectoryTarget(plugin, view.scope, kind, view.sourcePath);
  if (!file) throw Error("\u76EE\u5F55\u6587\u4EF6\u5DF2\u88AB\u79FB\u52A8\uFF0C\u8BF7\u5237\u65B0\u540E\u91CD\u8BD5\u3002");
  const workspace = plugin.app.workspace;
  plugin.routingDirectory = true;
  try {
    const existing = workspace.getLeavesOfType("markdown").find((leaf2) => leaf2.view?.file?.path === file.path);
    const leaf = existing || workspace.getLeaf?.("tab");
    if (leaf?.openFile) {
      await leaf.openFile(file, { active: true });
      await workspace.revealLeaf(leaf);
    } else await workspace.openLinkText(file.path, "", "tab");
    let explorer = workspace.getLeavesOfType("file-explorer")[0];
    if (!explorer && workspace.getLeftLeaf) {
      explorer = workspace.getLeftLeaf(false);
      await explorer?.setViewState({ type: "file-explorer", active: true });
    }
    if (explorer) {
      await workspace.revealLeaf(explorer);
      await explorer.loadIfDeferred?.();
      if (typeof explorer.view?.revealInFolder === "function") await explorer.view.revealInFolder(file);
    }
    view.say(exact ? "\u5DF2\u6253\u5F00\u5DE6\u4FA7\u76EE\u5F55\uFF0C\u5F53\u524D\u7B5B\u9009\u6761\u4EF6\u4FDD\u7559\u3002" : "\u8BE5\u8282\u70B9\u5C1A\u672A\u4E0B\u8F7D\uFF0C\u5DF2\u6253\u5F00\u672C\u5730\u76EE\u5F55\uFF1B\u5F53\u524D\u7B5B\u9009\u6761\u4EF6\u4FDD\u7559\u3002");
  } finally {
    plugin.routingDirectory = false;
  }
}

// src/assets/tizhuang-logo.svg
var tizhuang_logo_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="145 12 290 205" aria-hidden="true" focusable="false">\r\n  <g fill="currentColor" font-family="Noto Serif SC, Songti SC, STSong, SimSun, serif" font-size="150" font-weight="800" text-anchor="middle" shape-rendering="geometricPrecision">\r\n    <text x="230" y="169">\u9898</text>\r\n    <text x="352" y="184">\u5E84</text>\r\n  </g>\r\n</svg>\r\n';

// src/brand.js
function renderBrand(parent) {
  const brand = document.createElement("div");
  brand.className = "tz-brand";
  const mark = document.createElement("span");
  mark.className = "tz-brand-mark";
  mark.setAttribute("aria-hidden", "true");
  mark.innerHTML = tizhuang_logo_default;
  const title = document.createElement("h2");
  title.textContent = "\u672C\u5730\u9898\u5E93";
  brand.append(mark, title);
  parent.append(brand);
  return brand;
}

// src/website-paper-standards.json
var website_paper_standards_default = {
  source: "question-service/site/app/builder/paperStandards.ts",
  sha256: "19562d607380bdecf7b2575f32e3707274f7967c45bf946d7f579a073d793046",
  defaults: {
    questionCount: 20,
    durationMinutes: 45
  },
  standards: [
    {
      phaseId: 1,
      subjectId: 1,
      questionCount: 20,
      durationMinutes: 40
    },
    {
      phaseId: 1,
      subjectId: 2,
      questionCount: 25,
      durationMinutes: 40
    },
    {
      phaseId: 1,
      subjectId: 3,
      questionCount: 25,
      durationMinutes: 40
    },
    {
      phaseId: 1,
      subjectId: 10,
      questionCount: 20,
      durationMinutes: 40
    },
    {
      phaseId: 1,
      subjectId: 11,
      questionCount: 20,
      durationMinutes: 40
    },
    {
      phaseId: 2,
      subjectId: 1,
      questionCount: 20,
      durationMinutes: 60
    },
    {
      phaseId: 2,
      subjectId: 2,
      questionCount: 20,
      durationMinutes: 60
    },
    {
      phaseId: 2,
      subjectId: 3,
      questionCount: 25,
      durationMinutes: 60
    },
    {
      phaseId: 2,
      subjectId: 4,
      questionCount: 25,
      durationMinutes: 45
    },
    {
      phaseId: 2,
      subjectId: 5,
      questionCount: 25,
      durationMinutes: 45
    },
    {
      phaseId: 2,
      subjectId: 7,
      questionCount: 25,
      durationMinutes: 45
    },
    {
      phaseId: 2,
      subjectId: 8,
      questionCount: 20,
      durationMinutes: 60
    },
    {
      phaseId: 2,
      subjectId: 9,
      questionCount: 20,
      durationMinutes: 60
    },
    {
      phaseId: 2,
      subjectId: 11,
      questionCount: 20,
      durationMinutes: 45
    },
    {
      phaseId: 3,
      subjectId: 1,
      questionCount: 22,
      durationMinutes: 90
    },
    {
      phaseId: 3,
      subjectId: 2,
      questionCount: 22,
      durationMinutes: 90
    },
    {
      phaseId: 3,
      subjectId: 3,
      questionCount: 25,
      durationMinutes: 90
    },
    {
      phaseId: 3,
      subjectId: 4,
      questionCount: 25,
      durationMinutes: 75
    },
    {
      phaseId: 3,
      subjectId: 5,
      questionCount: 25,
      durationMinutes: 75
    },
    {
      phaseId: 3,
      subjectId: 6,
      questionCount: 25,
      durationMinutes: 75
    },
    {
      phaseId: 3,
      subjectId: 7,
      questionCount: 20,
      durationMinutes: 75
    },
    {
      phaseId: 3,
      subjectId: 8,
      questionCount: 20,
      durationMinutes: 75
    },
    {
      phaseId: 3,
      subjectId: 9,
      questionCount: 20,
      durationMinutes: 75
    }
  ]
};

// src/paper-basket.js
var BASKET_PATH = ".bank/paper-basket.json";
var scoreValue = (value) => {
  if (value === "" || value == null || typeof value === "boolean") throw Error("\u8BF7\u586B\u5199\u5206\u503C");
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0 || n > 1e3) throw Error("\u6BCF\u9898\u5206\u503C\u4E3A 0\u20141000 \u5206");
  return Math.round(n * 100) / 100;
};
var suggestedDuration = (q) => (website_paper_standards_default.standards.find((s) => s.phaseId === q?.phase_id && s.subjectId === q?.subject_id) || website_paper_standards_default.defaults).durationMinutes;
var PaperBasket = class {
  constructor(store) {
    this.store = store;
    this.data = { schema: "tizhuang.paper-basket/v1", title: "\u6211\u7684\u7EC3\u4E60\u5377", duration_minutes: 45, answer_space_mm: 25, revision: 0, items: [] };
    this.queue = Promise.resolve();
    this.busy = false;
  }
  async load() {
    const data = await this.store.json(BASKET_PATH, null);
    if (data) {
      if (data.schema !== "tizhuang.paper-basket/v1" || !Array.isArray(data.items) || data.items.length > 200 || data.items.some((i) => !i.question_id) || new Set(data.items.map((i) => i.question_id)).size !== data.items.length) throw Error("\u7EC4\u5377\u7BEE\u8BB0\u5F55\u635F\u574F\uFF0C\u8BF7\u4FDD\u7559\u6587\u4EF6\u5E76\u4EA4\u7ED9 Agent \u4FEE\u590D");
      for (const i of data.items) i.score = scoreValue(i.score);
      this.data = { ...this.data, ...data };
    }
    return this;
  }
  has(id) {
    return this.data.items.some((i) => i.question_id === id);
  }
  total() {
    return Math.round(this.data.items.reduce((s, i) => s + i.score, 0) * 100) / 100;
  }
  save() {
    this.data.revision++;
    delete this.data.request_id;
    delete this.data.last_result;
    this.data.updated_at = (/* @__PURE__ */ new Date()).toISOString();
    const snapshot = JSON.stringify(this.data, null, 2);
    this.queue = this.queue.catch(() => {
    }).then(async () => {
      await this.store.mkdir(".bank");
      await this.store.io.write(BASKET_PATH, snapshot);
    });
    return this.queue;
  }
  async add(questions) {
    if (this.busy) throw Error("\u6B63\u5728\u751F\u6210\uFF0C\u8BF7\u7A0D\u5019");
    const fresh = questions.filter((q) => !this.has(q.id));
    if (this.data.items.length + fresh.length > 200) throw Error("\u6BCF\u4EFD\u8BD5\u5377\u6700\u591A 200 \u9053\u9898");
    if (!this.data.items.length && fresh.length && !this.data.duration_custom) this.data.duration_minutes = suggestedDuration(fresh[0]);
    for (const q of fresh) this.data.items.push({ question_id: q.id, score: scoreValue(q.score ?? 5) });
    await this.save();
  }
  async remove(id) {
    if (this.busy) throw Error("\u6B63\u5728\u751F\u6210\uFF0C\u8BF7\u7A0D\u5019");
    this.data.items = this.data.items.filter((i) => i.question_id !== id);
    await this.save();
  }
  async move(id, target) {
    if (this.busy) throw Error("\u6B63\u5728\u751F\u6210\uFF0C\u8BF7\u7A0D\u5019");
    const from = this.data.items.findIndex((i) => i.question_id === id);
    if (from < 0 || target < 0 || target >= this.data.items.length || from === target) return;
    const [item] = this.data.items.splice(from, 1);
    this.data.items.splice(target, 0, item);
    await this.save();
  }
  async score(id, value) {
    if (this.busy) throw Error("\u6B63\u5728\u751F\u6210\uFF0C\u8BF7\u7A0D\u5019");
    const n = scoreValue(value), item = this.data.items.find((i) => i.question_id === id);
    if (item) {
      item.score = n;
      await this.save();
    }
  }
  async settings(values) {
    if (this.busy) throw Error("\u6B63\u5728\u751F\u6210\uFF0C\u8BF7\u7A0D\u5019");
    if (values.title != null && (!values.title.trim() || values.title.length > 120)) throw Error("\u8BF7\u586B\u5199 1\u2014120 \u5B57\u7684\u8BD5\u5377\u6807\u9898");
    for (const [key, min, max] of [["duration_minutes", 1, 600], ["answer_space_mm", 0, 100]]) if (values[key] != null && (!Number.isInteger(values[key]) || values[key] < min || values[key] > max)) throw Error(key === "duration_minutes" ? "\u8003\u8BD5\u65F6\u957F\u4E3A 1\u2014600 \u5206\u949F" : "\u4F5C\u7B54\u7559\u767D\u4E3A 0\u2014100 \u6BEB\u7C73");
    Object.assign(this.data, values);
    await this.save();
  }
  async clear() {
    if (this.busy) throw Error("\u6B63\u5728\u751F\u6210\uFF0C\u8BF7\u7A0D\u5019");
    this.data.items = [];
    await this.save();
  }
  async generate(plugin, confirmed = false) {
    var _a;
    if (this.busy) throw Error("\u6B63\u5728\u751F\u6210\uFF0C\u8BF7\u7A0D\u5019");
    if (!this.data.items.length) throw Error("\u8BF7\u5148\u52A0\u5165\u9898\u76EE");
    this.busy = true;
    try {
      await this.queue;
      if (this.data.output_version !== 1) {
        delete this.data.request_id;
        delete this.data.last_result;
        this.data.output_version = 1;
      }
      (_a = this.data).request_id || (_a.request_id = crypto.randomUUID().replaceAll("-", ""));
      const request = { output_version: 1, schema: this.data.schema, title: this.data.title, duration_minutes: this.data.duration_minutes, answer_space_mm: this.data.answer_space_mm, request_id: this.data.request_id, items: structuredClone(this.data.items) };
      const path = ".bank/paper-requests/" + request.request_id + ".json";
      await this.store.mkdir(".bank/paper-requests");
      const text2 = JSON.stringify(request, null, 2);
      if (await this.store.io.exists(path) && await this.store.io.read(path) !== text2) throw Error("\u751F\u6210\u8BF7\u6C42\u5185\u5BB9\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u8C03\u6574\u7EC4\u5377\u7BEE\u540E\u91CD\u8BD5");
      await this.store.io.write(path, text2);
      await this.store.io.write(BASKET_PATH, JSON.stringify(this.data, null, 2));
      const base = plugin.app.vault.adapter.getBasePath?.();
      if (!base) throw Error("\u7EC4\u5377\u9700\u8981\u7535\u8111\u4E0A\u7684\u672C\u5730\u4ED3\u5E93");
      const result = await plugin.runLocal("paper", ["--basket", base + "/" + path, ...confirmed ? ["--confirm-reviewed"] : []]);
      this.data.last_result = result;
      await this.store.io.write(BASKET_PATH, JSON.stringify(this.data, null, 2));
      return result;
    } finally {
      this.busy = false;
    }
  }
};

// src/main.js
var import_obsidian5 = require("obsidian");

// node_modules/dompurify/dist/purify.es.mjs
function _OverloadYield(e, d) {
  this.v = e, this.k = d;
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
function _arrayWithHoles(r) {
  if (Array.isArray(r)) return r;
}
function _iterableToArrayLimit(r, l) {
  var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (null != t) {
    var e, n, i, u, a = [], f = true, o = false;
    try {
      if (i = (t = t.call(r)).next, 0 === l) {
        if (Object(t) !== t) return;
        f = false;
      } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = true) ;
    } catch (r2) {
      o = true, n = r2;
    } finally {
      try {
        if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;
      } finally {
        if (o) throw n;
      }
    }
    return a;
  }
}
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _slicedToArray(r, e) {
  return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function AsyncGenerator(e) {
  var t, n;
  function resume(t2, n2) {
    try {
      var r = e[t2](n2), o = r.value, u = o instanceof _OverloadYield;
      Promise.resolve(u ? o.v : o).then(function(n3) {
        if (u) {
          var i = "return" === t2 && o.k ? t2 : "next";
          if (!o.k || n3.done) return resume(i, n3);
          n3 = e[i](n3).value;
        }
        settle(!!r.done, n3);
      }, function(e2) {
        resume("throw", e2);
      });
    } catch (e2) {
      settle(2, e2);
    }
  }
  function settle(e2, r) {
    2 === e2 ? t.reject(r) : t.resolve({
      value: r,
      done: e2
    }), (t = t.next) ? resume(t.key, t.arg) : n = null;
  }
  this._invoke = function(e2, r) {
    return new Promise(function(o, u) {
      var i = {
        key: e2,
        arg: r,
        resolve: o,
        reject: u,
        next: null
      };
      n ? n = n.next = i : (t = n = i, resume(e2, r));
    });
  }, "function" != typeof e.return && (this.return = void 0);
}
AsyncGenerator.prototype["function" == typeof Symbol && Symbol.asyncIterator || "@@asyncIterator"] = function() {
  return this;
}, AsyncGenerator.prototype.next = function(e) {
  return this._invoke("next", e);
}, AsyncGenerator.prototype.throw = function(e) {
  return this._invoke("throw", e);
}, AsyncGenerator.prototype.return = function(e) {
  return this._invoke("return", e);
};
var entries = Object.entries;
var setPrototypeOf = Object.setPrototypeOf;
var isFrozen = Object.isFrozen;
var getPrototypeOf = Object.getPrototypeOf;
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var freeze = Object.freeze;
var seal = Object.seal;
var create = Object.create;
var _ref = typeof Reflect !== "undefined" && Reflect;
var apply = _ref.apply;
var construct = _ref.construct;
if (!freeze) freeze = function freeze2(x) {
  return x;
};
if (!seal) seal = function seal2(x) {
  return x;
};
if (!apply) apply = function apply2(func, thisArg) {
  for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) args[_key - 2] = arguments[_key];
  return func.apply(thisArg, args);
};
if (!construct) construct = function construct2(Func) {
  for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) args[_key2 - 1] = arguments[_key2];
  return new Func(...args);
};
var arrayForEach = unapply(Array.prototype.forEach);
Array.prototype.indexOf;
var arrayLastIndexOf = unapply(Array.prototype.lastIndexOf);
var arrayPop = unapply(Array.prototype.pop);
var arrayPush = unapply(Array.prototype.push);
Array.prototype.slice;
var arraySplice = unapply(Array.prototype.splice);
var arrayIsArray = Array.isArray;
var stringToLowerCase = unapply(String.prototype.toLowerCase);
var stringToString = unapply(String.prototype.toString);
var stringMatch = unapply(String.prototype.match);
var stringReplace = unapply(String.prototype.replace);
var stringIndexOf = unapply(String.prototype.indexOf);
var stringTrim = unapply(String.prototype.trim);
var numberToString = unapply(Number.prototype.toString);
var booleanToString = unapply(Boolean.prototype.toString);
var bigintToString = typeof BigInt === "undefined" ? null : unapply(BigInt.prototype.toString);
var symbolToString = typeof Symbol === "undefined" ? null : unapply(Symbol.prototype.toString);
var objectHasOwnProperty = unapply(Object.prototype.hasOwnProperty);
var objectToString = unapply(Object.prototype.toString);
var regExpTest = unapply(RegExp.prototype.test);
var typeErrorCreate = unconstruct(TypeError);
function unapply(func) {
  return function(thisArg) {
    if (thisArg instanceof RegExp) thisArg.lastIndex = 0;
    for (var _len3 = arguments.length, args = new Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) args[_key3 - 1] = arguments[_key3];
    return apply(func, thisArg, args);
  };
}
function unconstruct(Func) {
  return function() {
    for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) args[_key4] = arguments[_key4];
    return construct(Func, args);
  };
}
function addToSet(set2, array) {
  let transformCaseFunc = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : stringToLowerCase;
  if (setPrototypeOf) setPrototypeOf(set2, null);
  if (!arrayIsArray(array)) return set2;
  let l = array.length;
  while (l--) {
    let element = array[l];
    if (typeof element === "string") {
      const lcElement = transformCaseFunc(element);
      if (lcElement !== element) {
        if (!isFrozen(array)) array[l] = lcElement;
        element = lcElement;
      }
    }
    set2[element] = true;
  }
  return set2;
}
function cleanArray(array) {
  for (let index = 0; index < array.length; index++) if (!objectHasOwnProperty(array, index)) array[index] = null;
  return array;
}
function clone(object) {
  const newObject = create(null);
  for (const _ref2 of entries(object)) {
    var _ref3 = _slicedToArray(_ref2, 2);
    const property = _ref3[0];
    const value = _ref3[1];
    if (objectHasOwnProperty(object, property)) {
      if (arrayIsArray(value)) newObject[property] = cleanArray(value);
      else if (value && typeof value === "object" && value.constructor === Object) newObject[property] = clone(value);
      else newObject[property] = value;
    }
  }
  return newObject;
}
function stringifyValue(value) {
  switch (typeof value) {
    case "string":
      return value;
    case "number":
      return numberToString(value);
    case "boolean":
      return booleanToString(value);
    case "bigint":
      return bigintToString ? bigintToString(value) : "0";
    case "symbol":
      return symbolToString ? symbolToString(value) : "Symbol()";
    case "undefined":
      return objectToString(value);
    case "function":
    case "object": {
      if (value === null) return objectToString(value);
      const valueAsRecord = value;
      const valueToString = lookupGetter(valueAsRecord, "toString");
      if (typeof valueToString === "function") {
        const stringified = valueToString(valueAsRecord);
        return typeof stringified === "string" ? stringified : objectToString(stringified);
      }
      return objectToString(value);
    }
    default:
      return objectToString(value);
  }
}
function lookupGetter(object, prop) {
  while (object !== null) {
    const desc = getOwnPropertyDescriptor(object, prop);
    if (desc) {
      if (desc.get) return unapply(desc.get);
      if (typeof desc.value === "function") return unapply(desc.value);
    }
    object = getPrototypeOf(object);
  }
  function fallbackValue() {
    return null;
  }
  return fallbackValue;
}
function isRegex(value) {
  try {
    regExpTest(value, "");
    return true;
  } catch (_unused) {
    return false;
  }
}
var html$1 = freeze([
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "big",
  "blink",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "content",
  "data",
  "datalist",
  "dd",
  "decorator",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "element",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "menuitem",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "pre",
  "progress",
  "q",
  "rp",
  "rt",
  "ruby",
  "s",
  "samp",
  "search",
  "section",
  "select",
  "shadow",
  "slot",
  "small",
  "source",
  "spacer",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "template",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
]);
var svg$1 = freeze([
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "enterkeyhint",
  "exportparts",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "inputmode",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "part",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern"
]);
var svgFilters = freeze([
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feDropShadow",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
]);
var svgDisallowed = freeze([
  "animate",
  "color-profile",
  "cursor",
  "discard",
  "font-face",
  "font-face-format",
  "font-face-name",
  "font-face-src",
  "font-face-uri",
  "foreignobject",
  "hatch",
  "hatchpath",
  "mesh",
  "meshgradient",
  "meshpatch",
  "meshrow",
  "missing-glyph",
  "script",
  "set",
  "solidcolor",
  "unknown",
  "use"
]);
var mathMl$1 = freeze([
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover",
  "mprescripts"
]);
var mathMlDisallowed = freeze([
  "maction",
  "maligngroup",
  "malignmark",
  "mlongdiv",
  "mscarries",
  "mscarry",
  "msgroup",
  "mstack",
  "msline",
  "msrow",
  "semantics",
  "annotation",
  "annotation-xml",
  "mprescripts",
  "none"
]);
var text = freeze(["#text"]);
var html = freeze([
  "accept",
  "action",
  "align",
  "alt",
  "autocapitalize",
  "autocomplete",
  "autopictureinpicture",
  "autoplay",
  "background",
  "bgcolor",
  "border",
  "capture",
  "cellpadding",
  "cellspacing",
  "checked",
  "cite",
  "class",
  "clear",
  "color",
  "cols",
  "colspan",
  "command",
  "commandfor",
  "controls",
  "controlslist",
  "coords",
  "crossorigin",
  "datetime",
  "decoding",
  "default",
  "dir",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "download",
  "draggable",
  "enctype",
  "enterkeyhint",
  "exportparts",
  "face",
  "for",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "id",
  "inert",
  "inputmode",
  "integrity",
  "ismap",
  "kind",
  "label",
  "lang",
  "list",
  "loading",
  "loop",
  "low",
  "max",
  "maxlength",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nonce",
  "noshade",
  "novalidate",
  "nowrap",
  "open",
  "optimum",
  "part",
  "pattern",
  "placeholder",
  "playsinline",
  "popover",
  "popovertarget",
  "popovertargetaction",
  "poster",
  "preload",
  "pubdate",
  "radiogroup",
  "readonly",
  "rel",
  "required",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "spellcheck",
  "scope",
  "selected",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "srclang",
  "start",
  "src",
  "srcset",
  "step",
  "style",
  "summary",
  "tabindex",
  "title",
  "translate",
  "type",
  "usemap",
  "valign",
  "value",
  "width",
  "wrap",
  "xmlns"
]);
var svg = freeze([
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "amplitude",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "exponent",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "intercept",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "mask-type",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "pointer-events",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "slope",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "tablevalues",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-orientation",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "vector-effect",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
]);
var mathMl = freeze([
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnalign",
  "columnlines",
  "columnspacing",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lquote",
  "lspace",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
]);
var xml = freeze([
  "xlink:href",
  "xml:id",
  "xlink:title",
  "xml:space",
  "xmlns:xlink"
]);
var MUSTACHE_EXPR = seal(/{{[\w\W]*|^[\w\W]*}}/g);
var ERB_EXPR = seal(/<%[\w\W]*|^[\w\W]*%>/g);
var TMPLIT_EXPR = seal(/\${[\w\W]*/g);
var DATA_ATTR = seal(/^data-[\-\w.\u00B7-\uFFFF]+$/);
var ARIA_ATTR = seal(/^aria-[\-\w]+$/);
var IS_ALLOWED_URI = seal(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i);
var IS_SCRIPT_OR_DATA = seal(/^(?:\w+script|data):/i);
var ATTR_WHITESPACE = seal(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g);
var DOCTYPE_NAME = seal(/^html$/i);
var CUSTOM_ELEMENT = seal(/^[a-z][.\w]*(-[.\w]+)+$/i);
var ELEMENT_MARKUP_PROBE = seal(/<[/\w!]/g);
var COMMENT_MARKUP_PROBE = seal(/<[/\w]/g);
var FALLBACK_TAG_CLOSE = seal(/<\/no(script|embed|frames)/i);
var SELF_CLOSING_TAG = seal(/\/>/i);
var NODE_TYPE2 = {
  element: 1,
  attribute: 2,
  text: 3,
  cdataSection: 4,
  entityReference: 5,
  entityNode: 6,
  processingInstruction: 7,
  comment: 8,
  document: 9,
  documentType: 10,
  documentFragment: 11,
  notation: 12
};
var LITERAL_TEXT_ELEMENT_NAMES = [
  "style",
  "script",
  "xmp",
  "iframe",
  "noembed",
  "noframes",
  "plaintext",
  "noscript"
];
var LITERAL_TEXT_ELEMENTS = freeze(addToSet({}, LITERAL_TEXT_ELEMENT_NAMES));
var LITERAL_TEXT_CLOSE = (function() {
  const map2 = {};
  arrayForEach(LITERAL_TEXT_ELEMENT_NAMES, (name2) => {
    map2[name2] = seal(new RegExp("</" + name2 + "(?=[\\t\\n\\f\\r />])", "i"));
  });
  return freeze(map2);
})();
var getGlobal = function getGlobal2() {
  return typeof window === "undefined" ? null : window;
};
var _createTrustedTypesPolicy = function _createTrustedTypesPolicy2(trustedTypes, purifyHostElement) {
  if (typeof trustedTypes !== "object" || typeof trustedTypes.createPolicy !== "function") return null;
  let suffix = null;
  const ATTR_NAME = "data-tt-policy-suffix";
  if (purifyHostElement && purifyHostElement.hasAttribute(ATTR_NAME)) suffix = purifyHostElement.getAttribute(ATTR_NAME);
  const policyName = "dompurify" + (suffix ? "#" + suffix : "");
  try {
    return trustedTypes.createPolicy(policyName, {
      createHTML(html2) {
        return html2;
      },
      createScriptURL(scriptUrl) {
        return scriptUrl;
      }
    });
  } catch (_) {
    console.warn("TrustedTypes policy " + policyName + " could not be created.");
    return null;
  }
};
var _createHooksMap = function _createHooksMap2() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
var _resolveSetOption = function _resolveSetOption2(cfg, key, fallback, options) {
  return objectHasOwnProperty(cfg, key) && arrayIsArray(cfg[key]) ? addToSet(options.base ? clone(options.base) : {}, cfg[key], options.transform) : fallback;
};
var _resolveObjectOption = function _resolveObjectOption2(cfg, key, makeFallback) {
  const value = objectHasOwnProperty(cfg, key) ? cfg[key] : void 0;
  return value && typeof value === "object" ? clone(value) : makeFallback();
};
function createDOMPurify() {
  let window2 = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : getGlobal();
  const DOMPurify = (root2) => createDOMPurify(root2);
  DOMPurify.version = "3.4.16";
  DOMPurify.removed = [];
  if (!window2 || !window2.document || window2.document.nodeType !== NODE_TYPE2.document || !window2.Element) {
    DOMPurify.isSupported = false;
    return DOMPurify;
  }
  let document2 = window2.document;
  const originalDocument = document2;
  const currentScript = originalDocument.currentScript;
  window2.DocumentFragment;
  const HTMLTemplateElement = window2.HTMLTemplateElement, Node2 = window2.Node, Element = window2.Element, NodeFilter = window2.NodeFilter;
  window2.NamedNodeMap === void 0 && (window2.NamedNodeMap || window2.MozNamedAttrMap);
  window2.HTMLFormElement;
  const DOMParser = window2.DOMParser, trustedTypes = window2.trustedTypes;
  const ElementPrototype = Element.prototype;
  const cloneNode = lookupGetter(ElementPrototype, "cloneNode");
  const remove2 = lookupGetter(ElementPrototype, "remove");
  const removeAttributeNode = lookupGetter(ElementPrototype, "removeAttributeNode");
  const getNextSibling = lookupGetter(ElementPrototype, "nextSibling");
  const getChildNodes = lookupGetter(ElementPrototype, "childNodes");
  const getParentNode = lookupGetter(ElementPrototype, "parentNode");
  const getShadowRoot = lookupGetter(ElementPrototype, "shadowRoot");
  const getAttributes = lookupGetter(ElementPrototype, "attributes");
  const getNodeType = Node2 && Node2.prototype ? lookupGetter(Node2.prototype, "nodeType") : null;
  const getNodeName = Node2 && Node2.prototype ? lookupGetter(Node2.prototype, "nodeName") : null;
  const getOwnerDocument = Node2 && Node2.prototype ? lookupGetter(Node2.prototype, "ownerDocument") : null;
  const _readNodeType = function _readNodeType2(node2) {
    return getNodeType ? getNodeType(node2) : node2.nodeType;
  };
  const _readNodeName = function _readNodeName2(node2) {
    return getNodeName ? getNodeName(node2) : node2.nodeName;
  };
  if (typeof HTMLTemplateElement === "function") {
    const template = document2.createElement("template");
    if (template.content && template.content.ownerDocument) document2 = template.content.ownerDocument;
  }
  let trustedTypesPolicy;
  let emptyHTML = "";
  let defaultTrustedTypesPolicy;
  let defaultTrustedTypesPolicyResolved = false;
  let IN_TRUSTED_TYPES_POLICY = 0;
  const _assertNotInTrustedTypesPolicy = function _assertNotInTrustedTypesPolicy2() {
    if (IN_TRUSTED_TYPES_POLICY > 0) throw typeErrorCreate('A configured TRUSTED_TYPES_POLICY callback (createHTML or createScriptURL) must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose callbacks wrap DOMPurify as TRUSTED_TYPES_POLICY; see the "DOMPurify and Trusted Types" section of the README.');
  };
  const _createTrustedHTML = function _createTrustedHTML2(html2) {
    _assertNotInTrustedTypesPolicy();
    IN_TRUSTED_TYPES_POLICY++;
    try {
      return trustedTypesPolicy.createHTML(html2);
    } finally {
      IN_TRUSTED_TYPES_POLICY--;
    }
  };
  const _createTrustedScriptURL = function _createTrustedScriptURL2(scriptUrl) {
    _assertNotInTrustedTypesPolicy();
    IN_TRUSTED_TYPES_POLICY++;
    try {
      return trustedTypesPolicy.createScriptURL(scriptUrl);
    } finally {
      IN_TRUSTED_TYPES_POLICY--;
    }
  };
  const _getDefaultTrustedTypesPolicy = function _getDefaultTrustedTypesPolicy2() {
    if (!defaultTrustedTypesPolicyResolved) {
      defaultTrustedTypesPolicy = _createTrustedTypesPolicy(trustedTypes, currentScript);
      defaultTrustedTypesPolicyResolved = true;
    }
    return defaultTrustedTypesPolicy;
  };
  const _document = document2, implementation = _document.implementation, createNodeIterator = _document.createNodeIterator, createDocumentFragment = _document.createDocumentFragment, getElementsByTagName = _document.getElementsByTagName;
  const importNode = originalDocument.importNode;
  let hooks = _createHooksMap();
  DOMPurify.isSupported = typeof entries === "function" && typeof getParentNode === "function" && implementation && implementation.createHTMLDocument !== void 0;
  const MUSTACHE_EXPR$1 = MUSTACHE_EXPR, ERB_EXPR$1 = ERB_EXPR, TMPLIT_EXPR$1 = TMPLIT_EXPR, DATA_ATTR$1 = DATA_ATTR, ARIA_ATTR$1 = ARIA_ATTR, IS_SCRIPT_OR_DATA$1 = IS_SCRIPT_OR_DATA, ATTR_WHITESPACE$1 = ATTR_WHITESPACE, CUSTOM_ELEMENT$1 = CUSTOM_ELEMENT;
  let IS_ALLOWED_URI$1 = IS_ALLOWED_URI;
  let ALLOWED_TAGS = null;
  const DEFAULT_ALLOWED_TAGS = addToSet({}, [
    ...html$1,
    ...svg$1,
    ...svgFilters,
    ...mathMl$1,
    ...text
  ]);
  let ALLOWED_ATTR = null;
  const DEFAULT_ALLOWED_ATTR = addToSet({}, [
    ...html,
    ...svg,
    ...mathMl,
    ...xml
  ]);
  let CUSTOM_ELEMENT_HANDLING = Object.seal(create(null, {
    tagNameCheck: {
      writable: true,
      configurable: false,
      enumerable: true,
      value: null
    },
    attributeNameCheck: {
      writable: true,
      configurable: false,
      enumerable: true,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: true,
      configurable: false,
      enumerable: true,
      value: false
    }
  }));
  let FORBID_TAGS = null;
  let FORBID_ATTR = null;
  const EXTRA_ELEMENT_HANDLING = Object.seal(create(null, {
    tagCheck: {
      writable: true,
      configurable: false,
      enumerable: true,
      value: null
    },
    attributeCheck: {
      writable: true,
      configurable: false,
      enumerable: true,
      value: null
    }
  }));
  let ALLOW_ARIA_ATTR = true;
  let ALLOW_DATA_ATTR = true;
  let ALLOW_UNKNOWN_PROTOCOLS = false;
  let ALLOW_SELF_CLOSE_IN_ATTR = true;
  let SAFE_FOR_TEMPLATES = false;
  let SAFE_FOR_XML = true;
  let WHOLE_DOCUMENT = false;
  let SET_CONFIG = false;
  let SET_CONFIG_ALLOWED_TAGS = null;
  let SET_CONFIG_ALLOWED_ATTR = null;
  let FORCE_BODY = false;
  let RETURN_DOM = false;
  let RETURN_DOM_FRAGMENT = false;
  let RETURN_TRUSTED_TYPE = false;
  let SANITIZE_DOM = true;
  let SANITIZE_NAMED_PROPS = false;
  const SANITIZE_NAMED_PROPS_PREFIX = "user-content-";
  let KEEP_CONTENT = true;
  let IN_PLACE = false;
  let USE_PROFILES = {};
  let FORBID_CONTENTS = null;
  const DEFAULT_FORBID_CONTENTS = addToSet({}, [
    "annotation-xml",
    "audio",
    "colgroup",
    "desc",
    "foreignobject",
    "head",
    "iframe",
    "math",
    "mi",
    "mn",
    "mo",
    "ms",
    "mtext",
    "noembed",
    "noframes",
    "noscript",
    "plaintext",
    "script",
    "selectedcontent",
    "style",
    "svg",
    "template",
    "thead",
    "title",
    "video",
    "xmp"
  ]);
  let DATA_URI_TAGS = null;
  const DEFAULT_DATA_URI_TAGS = addToSet({}, [
    "audio",
    "video",
    "img",
    "source",
    "image",
    "track"
  ]);
  let URI_SAFE_ATTRIBUTES = null;
  const DEFAULT_URI_SAFE_ATTRIBUTES = addToSet({}, [
    "alt",
    "class",
    "for",
    "id",
    "label",
    "name",
    "pattern",
    "placeholder",
    "role",
    "summary",
    "title",
    "value",
    "style",
    "xmlns"
  ]);
  const MATHML_NAMESPACE = "http://www.w3.org/1998/Math/MathML";
  const SVG_NAMESPACE = "http://www.w3.org/2000/svg";
  const HTML_NAMESPACE = "http://www.w3.org/1999/xhtml";
  let NAMESPACE = HTML_NAMESPACE;
  let IS_EMPTY_INPUT = false;
  let ALLOWED_NAMESPACES = null;
  const DEFAULT_ALLOWED_NAMESPACES = addToSet({}, [
    MATHML_NAMESPACE,
    SVG_NAMESPACE,
    HTML_NAMESPACE
  ], stringToString);
  const DEFAULT_MATHML_TEXT_INTEGRATION_POINTS = freeze([
    "mi",
    "mo",
    "mn",
    "ms",
    "mtext"
  ]);
  let MATHML_TEXT_INTEGRATION_POINTS = addToSet({}, DEFAULT_MATHML_TEXT_INTEGRATION_POINTS);
  const DEFAULT_HTML_INTEGRATION_POINTS = freeze(["annotation-xml"]);
  let HTML_INTEGRATION_POINTS = addToSet({}, DEFAULT_HTML_INTEGRATION_POINTS);
  const COMMON_SVG_AND_HTML_ELEMENTS = addToSet({}, [
    "title",
    "style",
    "font",
    "a",
    "script"
  ]);
  let PARSER_MEDIA_TYPE = null;
  const SUPPORTED_PARSER_MEDIA_TYPES = ["application/xhtml+xml", "text/html"];
  const DEFAULT_PARSER_MEDIA_TYPE = "text/html";
  let transformCaseFunc = null;
  let CONFIG = null;
  const formElement = document2.createElement("form");
  const isRegexOrFunction = function isRegexOrFunction2(testValue) {
    return testValue instanceof RegExp || testValue instanceof Function;
  };
  const _parseConfig = function _parseConfig2() {
    let cfg = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (CONFIG && CONFIG === cfg) return;
    if (!cfg || typeof cfg !== "object") cfg = {};
    cfg = clone(cfg);
    PARSER_MEDIA_TYPE = SUPPORTED_PARSER_MEDIA_TYPES.indexOf(cfg.PARSER_MEDIA_TYPE) === -1 ? DEFAULT_PARSER_MEDIA_TYPE : cfg.PARSER_MEDIA_TYPE;
    transformCaseFunc = PARSER_MEDIA_TYPE === "application/xhtml+xml" ? stringToString : stringToLowerCase;
    ALLOWED_TAGS = _resolveSetOption(cfg, "ALLOWED_TAGS", DEFAULT_ALLOWED_TAGS, { transform: transformCaseFunc });
    ALLOWED_ATTR = _resolveSetOption(cfg, "ALLOWED_ATTR", DEFAULT_ALLOWED_ATTR, { transform: transformCaseFunc });
    ALLOWED_NAMESPACES = _resolveSetOption(cfg, "ALLOWED_NAMESPACES", DEFAULT_ALLOWED_NAMESPACES, { transform: stringToString });
    URI_SAFE_ATTRIBUTES = _resolveSetOption(cfg, "ADD_URI_SAFE_ATTR", DEFAULT_URI_SAFE_ATTRIBUTES, {
      transform: transformCaseFunc,
      base: DEFAULT_URI_SAFE_ATTRIBUTES
    });
    DATA_URI_TAGS = _resolveSetOption(cfg, "ADD_DATA_URI_TAGS", DEFAULT_DATA_URI_TAGS, {
      transform: transformCaseFunc,
      base: DEFAULT_DATA_URI_TAGS
    });
    FORBID_CONTENTS = _resolveSetOption(cfg, "FORBID_CONTENTS", DEFAULT_FORBID_CONTENTS, { transform: transformCaseFunc });
    FORBID_TAGS = _resolveSetOption(cfg, "FORBID_TAGS", clone({}), { transform: transformCaseFunc });
    FORBID_ATTR = _resolveSetOption(cfg, "FORBID_ATTR", clone({}), { transform: transformCaseFunc });
    USE_PROFILES = objectHasOwnProperty(cfg, "USE_PROFILES") ? cfg.USE_PROFILES && typeof cfg.USE_PROFILES === "object" ? clone(cfg.USE_PROFILES) : cfg.USE_PROFILES : false;
    ALLOW_ARIA_ATTR = cfg.ALLOW_ARIA_ATTR !== false;
    ALLOW_DATA_ATTR = cfg.ALLOW_DATA_ATTR !== false;
    ALLOW_UNKNOWN_PROTOCOLS = cfg.ALLOW_UNKNOWN_PROTOCOLS || false;
    ALLOW_SELF_CLOSE_IN_ATTR = cfg.ALLOW_SELF_CLOSE_IN_ATTR !== false;
    SAFE_FOR_TEMPLATES = cfg.SAFE_FOR_TEMPLATES || false;
    SAFE_FOR_XML = cfg.SAFE_FOR_XML !== false;
    WHOLE_DOCUMENT = cfg.WHOLE_DOCUMENT || false;
    RETURN_DOM = cfg.RETURN_DOM || false;
    RETURN_DOM_FRAGMENT = cfg.RETURN_DOM_FRAGMENT || false;
    RETURN_TRUSTED_TYPE = cfg.RETURN_TRUSTED_TYPE || false;
    FORCE_BODY = cfg.FORCE_BODY || false;
    SANITIZE_DOM = cfg.SANITIZE_DOM !== false;
    SANITIZE_NAMED_PROPS = cfg.SANITIZE_NAMED_PROPS || false;
    KEEP_CONTENT = cfg.KEEP_CONTENT !== false;
    IN_PLACE = cfg.IN_PLACE || false;
    IS_ALLOWED_URI$1 = isRegex(cfg.ALLOWED_URI_REGEXP) ? cfg.ALLOWED_URI_REGEXP : IS_ALLOWED_URI;
    NAMESPACE = typeof cfg.NAMESPACE === "string" ? cfg.NAMESPACE : HTML_NAMESPACE;
    MATHML_TEXT_INTEGRATION_POINTS = _resolveObjectOption(cfg, "MATHML_TEXT_INTEGRATION_POINTS", () => addToSet({}, DEFAULT_MATHML_TEXT_INTEGRATION_POINTS));
    HTML_INTEGRATION_POINTS = _resolveObjectOption(cfg, "HTML_INTEGRATION_POINTS", () => addToSet({}, DEFAULT_HTML_INTEGRATION_POINTS));
    const customElementHandling = _resolveObjectOption(cfg, "CUSTOM_ELEMENT_HANDLING", () => create(null));
    CUSTOM_ELEMENT_HANDLING = create(null);
    if (objectHasOwnProperty(customElementHandling, "tagNameCheck") && isRegexOrFunction(customElementHandling.tagNameCheck)) CUSTOM_ELEMENT_HANDLING.tagNameCheck = customElementHandling.tagNameCheck;
    if (objectHasOwnProperty(customElementHandling, "attributeNameCheck") && isRegexOrFunction(customElementHandling.attributeNameCheck)) CUSTOM_ELEMENT_HANDLING.attributeNameCheck = customElementHandling.attributeNameCheck;
    if (objectHasOwnProperty(customElementHandling, "allowCustomizedBuiltInElements") && typeof customElementHandling.allowCustomizedBuiltInElements === "boolean") CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements = customElementHandling.allowCustomizedBuiltInElements;
    seal(CUSTOM_ELEMENT_HANDLING);
    if (SAFE_FOR_TEMPLATES) ALLOW_DATA_ATTR = false;
    if (RETURN_DOM_FRAGMENT) RETURN_DOM = true;
    if (USE_PROFILES) {
      ALLOWED_TAGS = addToSet({}, text);
      ALLOWED_ATTR = create(null);
      if (USE_PROFILES.html === true) {
        addToSet(ALLOWED_TAGS, html$1);
        addToSet(ALLOWED_ATTR, html);
      }
      if (USE_PROFILES.svg === true) {
        addToSet(ALLOWED_TAGS, svg$1);
        addToSet(ALLOWED_ATTR, svg);
        addToSet(ALLOWED_ATTR, xml);
      }
      if (USE_PROFILES.svgFilters === true) {
        addToSet(ALLOWED_TAGS, svgFilters);
        addToSet(ALLOWED_ATTR, svg);
        addToSet(ALLOWED_ATTR, xml);
      }
      if (USE_PROFILES.mathMl === true) {
        addToSet(ALLOWED_TAGS, mathMl$1);
        addToSet(ALLOWED_ATTR, mathMl);
        addToSet(ALLOWED_ATTR, xml);
      }
    }
    EXTRA_ELEMENT_HANDLING.tagCheck = null;
    EXTRA_ELEMENT_HANDLING.attributeCheck = null;
    if (objectHasOwnProperty(cfg, "ADD_TAGS")) {
      if (typeof cfg.ADD_TAGS === "function") EXTRA_ELEMENT_HANDLING.tagCheck = cfg.ADD_TAGS;
      else if (arrayIsArray(cfg.ADD_TAGS)) {
        if (ALLOWED_TAGS === DEFAULT_ALLOWED_TAGS) ALLOWED_TAGS = clone(ALLOWED_TAGS);
        addToSet(ALLOWED_TAGS, cfg.ADD_TAGS, transformCaseFunc);
      }
    }
    if (objectHasOwnProperty(cfg, "ADD_ATTR")) {
      if (typeof cfg.ADD_ATTR === "function") EXTRA_ELEMENT_HANDLING.attributeCheck = cfg.ADD_ATTR;
      else if (arrayIsArray(cfg.ADD_ATTR)) {
        if (ALLOWED_ATTR === DEFAULT_ALLOWED_ATTR) ALLOWED_ATTR = clone(ALLOWED_ATTR);
        addToSet(ALLOWED_ATTR, cfg.ADD_ATTR, transformCaseFunc);
      }
    }
    if (objectHasOwnProperty(cfg, "ADD_FORBID_CONTENTS") && arrayIsArray(cfg.ADD_FORBID_CONTENTS)) {
      if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) FORBID_CONTENTS = clone(FORBID_CONTENTS);
      addToSet(FORBID_CONTENTS, cfg.ADD_FORBID_CONTENTS, transformCaseFunc);
    }
    if (KEEP_CONTENT) ALLOWED_TAGS["#text"] = true;
    if (WHOLE_DOCUMENT) addToSet(ALLOWED_TAGS, [
      "html",
      "head",
      "body"
    ]);
    if (ALLOWED_TAGS.table) {
      addToSet(ALLOWED_TAGS, ["tbody"]);
      delete FORBID_TAGS.tbody;
    }
    if (cfg.TRUSTED_TYPES_POLICY) {
      if (typeof cfg.TRUSTED_TYPES_POLICY.createHTML !== "function") throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
      if (typeof cfg.TRUSTED_TYPES_POLICY.createScriptURL !== "function") throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
      const previousTrustedTypesPolicy = trustedTypesPolicy;
      trustedTypesPolicy = cfg.TRUSTED_TYPES_POLICY;
      try {
        emptyHTML = _createTrustedHTML("");
      } catch (error) {
        trustedTypesPolicy = previousTrustedTypesPolicy;
        throw error;
      }
    } else if (cfg.TRUSTED_TYPES_POLICY === null) {
      trustedTypesPolicy = void 0;
      emptyHTML = "";
    } else {
      if (trustedTypesPolicy === void 0) trustedTypesPolicy = _getDefaultTrustedTypesPolicy();
      if (trustedTypesPolicy && typeof emptyHTML === "string") emptyHTML = _createTrustedHTML("");
    }
    if (freeze) freeze(cfg);
    CONFIG = cfg;
  };
  const ALL_SVG_TAGS = addToSet({}, [
    ...svg$1,
    ...svgFilters,
    ...svgDisallowed
  ]);
  const ALL_MATHML_TAGS = addToSet({}, [...mathMl$1, ...mathMlDisallowed]);
  const _checkSvgNamespace = function _checkSvgNamespace2(tagName, parent, parentTagName) {
    if (parent.namespaceURI === HTML_NAMESPACE) return tagName === "svg";
    if (parent.namespaceURI === MATHML_NAMESPACE) return tagName === "svg" && (parentTagName === "annotation-xml" || MATHML_TEXT_INTEGRATION_POINTS[parentTagName]);
    return Boolean(ALL_SVG_TAGS[tagName]);
  };
  const _checkMathMlNamespace = function _checkMathMlNamespace2(tagName, parent, parentTagName) {
    if (parent.namespaceURI === HTML_NAMESPACE) return tagName === "math";
    if (parent.namespaceURI === SVG_NAMESPACE) return tagName === "math" && HTML_INTEGRATION_POINTS[parentTagName];
    return Boolean(ALL_MATHML_TAGS[tagName]);
  };
  const _checkHtmlNamespace = function _checkHtmlNamespace2(tagName, parent, parentTagName) {
    if (parent.namespaceURI === SVG_NAMESPACE && !HTML_INTEGRATION_POINTS[parentTagName]) return false;
    if (parent.namespaceURI === MATHML_NAMESPACE && !MATHML_TEXT_INTEGRATION_POINTS[parentTagName]) return false;
    return !ALL_MATHML_TAGS[tagName] && (COMMON_SVG_AND_HTML_ELEMENTS[tagName] || !ALL_SVG_TAGS[tagName]);
  };
  const _checkValidNamespace = function _checkValidNamespace2(element) {
    let parent = getParentNode(element);
    if (!parent || !parent.tagName) parent = {
      namespaceURI: NAMESPACE,
      tagName: "template"
    };
    const tagName = stringToLowerCase(element.tagName);
    const parentTagName = stringToLowerCase(parent.tagName);
    if (!ALLOWED_NAMESPACES[element.namespaceURI]) return false;
    if (element.namespaceURI === SVG_NAMESPACE) return _checkSvgNamespace(tagName, parent, parentTagName);
    if (element.namespaceURI === MATHML_NAMESPACE) return _checkMathMlNamespace(tagName, parent, parentTagName);
    if (element.namespaceURI === HTML_NAMESPACE) return _checkHtmlNamespace(tagName, parent, parentTagName);
    if (PARSER_MEDIA_TYPE === "application/xhtml+xml" && ALLOWED_NAMESPACES[element.namespaceURI]) return true;
    return false;
  };
  const _forceRemove = function _forceRemove2(node2) {
    arrayPush(DOMPurify.removed, { element: node2 });
    try {
      getParentNode(node2).removeChild(node2);
    } catch (_) {
      remove2(node2);
      if (!getParentNode(node2)) throw typeErrorCreate("a node selected for removal could not be detached from its tree and cannot be safely returned; refusing to sanitize in place");
    }
  };
  const _stripAttributeNode = function _stripAttributeNode2(element, attribute, name2) {
    try {
      removeAttributeNode(element, attribute);
    } catch (_) {
      try {
        element.removeAttribute(name2);
      } catch (_2) {
      }
    }
  };
  const _neutralizeRoot = function _neutralizeRoot2(root2) {
    _neutralizeSubtree(root2);
    const childNodes = getChildNodes(root2);
    if (childNodes) {
      const snapshot = [];
      arrayForEach(childNodes, (child) => {
        arrayPush(snapshot, child);
      });
      arrayForEach(snapshot, (child) => {
        try {
          remove2(child);
        } catch (_) {
        }
      });
    }
    const attributes = getAttributes(root2);
    if (attributes) for (let i = attributes.length - 1; i >= 0; --i) {
      const attribute = attributes[i];
      const name2 = attribute && attribute.name;
      if (typeof name2 === "string") _stripAttributeNode(root2, attribute, name2);
    }
  };
  const _removeAttribute = function _removeAttribute2(name2, element, attr) {
    if (!attr) try {
      attr = element.getAttributeNode(name2);
    } catch (_) {
      attr = null;
    }
    arrayPush(DOMPurify.removed, {
      attribute: attr || null,
      from: element
    });
    try {
      if (attr) removeAttributeNode(element, attr);
      else element.removeAttribute(name2);
    } catch (_) {
      try {
        element.removeAttribute(name2);
      } catch (_2) {
      }
    }
    if (name2 === "is") {
      if (RETURN_DOM || RETURN_DOM_FRAGMENT) try {
        _forceRemove(element);
      } catch (_) {
      }
      else try {
        element.setAttribute(name2, "");
      } catch (_) {
      }
    }
  };
  const _stripDisallowedAttributes = function _stripDisallowedAttributes2(element) {
    const attributes = getAttributes(element);
    if (!attributes) return;
    for (let i = attributes.length - 1; i >= 0; --i) {
      const attribute = attributes[i];
      const name2 = attribute && attribute.name;
      if (typeof name2 !== "string" || ALLOWED_ATTR[transformCaseFunc(name2)]) continue;
      _stripAttributeNode(element, attribute, name2);
    }
  };
  const _neutralizeSubtree = function _neutralizeSubtree2(root2) {
    const stack = [root2];
    while (stack.length > 0) {
      const node2 = stack.pop();
      if (_readNodeType(node2) === NODE_TYPE2.element) _stripDisallowedAttributes(node2);
      const childNodes = getChildNodes(node2);
      if (childNodes) for (let i = childNodes.length - 1; i >= 0; --i) stack.push(childNodes[i]);
    }
  };
  const _isPatchLinkageAttribute = function _isPatchLinkageAttribute2(lcName, lcTag) {
    if (!SAFE_FOR_XML) return false;
    if (lcName === "patchsrc") return true;
    return lcName === "for" && lcTag !== "label" && lcTag !== "output";
  };
  const _neutralizePatchLinkage = function _neutralizePatchLinkage2(root2) {
    if (!SAFE_FOR_XML) return;
    const stack = [root2];
    while (stack.length > 0) {
      const node2 = stack.pop();
      const nodeType = _readNodeType(node2);
      if (nodeType === NODE_TYPE2.processingInstruction || nodeType === NODE_TYPE2.comment && regExpTest(COMMENT_MARKUP_PROBE, node2.data)) {
        try {
          remove2(node2);
        } catch (_) {
        }
        continue;
      }
      if (nodeType === NODE_TYPE2.element) {
        const element = node2;
        const lcTag = transformCaseFunc(_readNodeName(node2));
        try {
          if (element.hasAttribute && element.hasAttribute("patchsrc")) element.removeAttribute("patchsrc");
          if (element.hasAttribute && element.hasAttribute("for") && _isPatchLinkageAttribute("for", lcTag)) element.removeAttribute("for");
        } catch (_) {
        }
      }
      const childNodes = getChildNodes(node2);
      if (childNodes) for (let i = childNodes.length - 1; i >= 0; --i) stack.push(childNodes[i]);
    }
  };
  const _initDocument = function _initDocument2(dirty) {
    let doc = null;
    let leadingWhitespace = null;
    if (FORCE_BODY) dirty = "<remove></remove>" + dirty;
    else {
      const matches = stringMatch(dirty, /^[\r\n\t ]+/);
      leadingWhitespace = matches && matches[0];
    }
    if (PARSER_MEDIA_TYPE === "application/xhtml+xml" && NAMESPACE === HTML_NAMESPACE) dirty = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + dirty + "</body></html>";
    const dirtyPayload = trustedTypesPolicy ? _createTrustedHTML(dirty) : dirty;
    if (NAMESPACE === HTML_NAMESPACE) try {
      doc = new DOMParser().parseFromString(dirtyPayload, PARSER_MEDIA_TYPE);
    } catch (_) {
    }
    if (!doc || !doc.documentElement) {
      doc = implementation.createDocument(NAMESPACE, "template", null);
      try {
        doc.documentElement.innerHTML = IS_EMPTY_INPUT ? emptyHTML : dirtyPayload;
      } catch (_) {
      }
    }
    const body = doc.body || doc.documentElement;
    if (dirty && leadingWhitespace) body.insertBefore(document2.createTextNode(leadingWhitespace), body.childNodes[0] || null);
    if (NAMESPACE === HTML_NAMESPACE) return getElementsByTagName.call(doc, WHOLE_DOCUMENT ? "html" : "body")[0];
    return WHOLE_DOCUMENT ? doc.documentElement : body;
  };
  const _createNodeIterator = function _createNodeIterator2(root2) {
    const doc = getOwnerDocument ? getOwnerDocument(root2) : root2.ownerDocument;
    return createNodeIterator.call(doc || root2, root2, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_TEXT | NodeFilter.SHOW_PROCESSING_INSTRUCTION | NodeFilter.SHOW_CDATA_SECTION, null);
  };
  const _stripTemplateExpressions = function _stripTemplateExpressions2(value) {
    value = stringReplace(value, MUSTACHE_EXPR$1, " ");
    value = stringReplace(value, ERB_EXPR$1, " ");
    value = stringReplace(value, TMPLIT_EXPR$1, " ");
    return value;
  };
  const _scrubTemplateExpressions2 = function _scrubTemplateExpressions(node2) {
    var _node$querySelectorAl;
    node2.normalize();
    const doc = getOwnerDocument ? getOwnerDocument(node2) : node2.ownerDocument;
    const walker = createNodeIterator.call(doc || node2, node2, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_CDATA_SECTION | NodeFilter.SHOW_PROCESSING_INSTRUCTION, null);
    let currentNode = walker.nextNode();
    while (currentNode) {
      currentNode.data = _stripTemplateExpressions(currentNode.data);
      currentNode = walker.nextNode();
    }
    const templates = (_node$querySelectorAl = node2.querySelectorAll) === null || _node$querySelectorAl === void 0 ? void 0 : _node$querySelectorAl.call(node2, "template");
    if (templates) arrayForEach(templates, (tmpl) => {
      if (_isDocumentFragment(tmpl.content)) _scrubTemplateExpressions2(tmpl.content);
    });
  };
  const _isClobbered = function _isClobbered2(element) {
    const realTagName = getNodeName ? getNodeName(element) : null;
    if (typeof realTagName !== "string") return false;
    if (transformCaseFunc(realTagName) !== "form") return false;
    return typeof element.nodeName !== "string" || typeof element.textContent !== "string" || typeof element.removeChild !== "function" || element.attributes !== getAttributes(element) || typeof element.removeAttribute !== "function" || typeof element.removeAttributeNode !== "function" || typeof element.getAttributeNode !== "function" || typeof element.setAttribute !== "function" || typeof element.namespaceURI !== "string" || typeof element.insertBefore !== "function" || typeof element.hasChildNodes !== "function" || element.nodeType !== getNodeType(element) || element.childNodes !== getChildNodes(element);
  };
  const _isDocumentFragment = function _isDocumentFragment2(value) {
    if (!getNodeType || typeof value !== "object" || value === null) return false;
    try {
      return getNodeType(value) === NODE_TYPE2.documentFragment;
    } catch (_) {
      return false;
    }
  };
  const _isNode = function _isNode2(value) {
    if (!getNodeType || typeof value !== "object" || value === null) return false;
    try {
      return typeof getNodeType(value) === "number";
    } catch (_) {
      return false;
    }
  };
  function _executeHooks(hooks2, currentNode, data) {
    if (hooks2.length === 0) return;
    arrayForEach(hooks2, (hook) => {
      hook.call(DOMPurify, currentNode, data, CONFIG);
    });
  }
  const _isUnsafeNode = function _isUnsafeNode2(currentNode, tagName) {
    if (SAFE_FOR_XML && currentNode.hasChildNodes() && !_isNode(currentNode.firstElementChild) && regExpTest(ELEMENT_MARKUP_PROBE, currentNode.textContent) && regExpTest(ELEMENT_MARKUP_PROBE, currentNode.innerHTML)) return true;
    if (SAFE_FOR_XML && currentNode.namespaceURI === HTML_NAMESPACE && LITERAL_TEXT_ELEMENTS[tagName] && (_isNode(currentNode.firstElementChild) || typeof currentNode.textContent === "string" && regExpTest(LITERAL_TEXT_CLOSE[tagName], currentNode.textContent))) return true;
    if (currentNode.nodeType === NODE_TYPE2.processingInstruction) return true;
    if (SAFE_FOR_XML && currentNode.nodeType === NODE_TYPE2.comment && regExpTest(COMMENT_MARKUP_PROBE, currentNode.data)) return true;
    return false;
  };
  const _matchesNameCheck = function _matchesNameCheck2(check, name2) {
    if (check instanceof RegExp) return regExpTest(check, name2);
    if (check instanceof Function) {
      for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) args[_key - 2] = arguments[_key];
      return Boolean(check(name2, ...args));
    }
    return false;
  };
  const _sanitizeDisallowedNode = function _sanitizeDisallowedNode2(currentNode, tagName, root2) {
    if (!FORBID_TAGS[tagName] && _isBasicCustomElement(tagName) && _matchesNameCheck(CUSTOM_ELEMENT_HANDLING.tagNameCheck, tagName)) return false;
    if (KEEP_CONTENT && !FORBID_CONTENTS[tagName]) {
      const parentNode = getParentNode(currentNode);
      const childNodes = getChildNodes(currentNode);
      if (childNodes && parentNode) {
        const childCount = childNodes.length;
        for (let i = childCount - 1; i >= 0; --i) {
          const hoisted = currentNode === root2 ? cloneNode(childNodes[i], true) : childNodes[i];
          parentNode.insertBefore(hoisted, getNextSibling(currentNode));
        }
      }
    }
    _forceRemove(currentNode);
    return true;
  };
  const _forkSharedAllowlist = function _forkSharedAllowlist2(hookList, set2, defaultSet, setConfigSet) {
    if (hookList.length === 0) return set2;
    return set2 === defaultSet || set2 === setConfigSet ? clone(set2) : set2;
  };
  const _handleHookDetachedNode = function _handleHookDetachedNode2(currentNode, root2) {
    if (currentNode === root2 || getParentNode(currentNode) !== null) return false;
    if (IN_PLACE) _neutralizeSubtree(currentNode);
    return true;
  };
  const _sanitizeElements = function _sanitizeElements2(currentNode, root2) {
    _executeHooks(hooks.beforeSanitizeElements, currentNode, null);
    if (_handleHookDetachedNode(currentNode, root2)) return true;
    if (_isClobbered(currentNode)) {
      _forceRemove(currentNode);
      return true;
    }
    const tagName = transformCaseFunc(_readNodeName(currentNode));
    ALLOWED_TAGS = _forkSharedAllowlist(hooks.uponSanitizeElement, ALLOWED_TAGS, DEFAULT_ALLOWED_TAGS, SET_CONFIG_ALLOWED_TAGS);
    _executeHooks(hooks.uponSanitizeElement, currentNode, {
      tagName,
      allowedTags: ALLOWED_TAGS
    });
    if (_handleHookDetachedNode(currentNode, root2)) return true;
    if (_isUnsafeNode(currentNode, tagName)) {
      _forceRemove(currentNode);
      return true;
    }
    if (FORBID_TAGS[tagName] || !(EXTRA_ELEMENT_HANDLING.tagCheck instanceof Function && EXTRA_ELEMENT_HANDLING.tagCheck(tagName)) && !ALLOWED_TAGS[tagName]) {
      const removed = _sanitizeDisallowedNode(currentNode, tagName, root2);
      if (removed === false) {
        _executeHooks(hooks.afterSanitizeElements, currentNode, null);
        if (_handleHookDetachedNode(currentNode, root2)) return true;
      }
      return removed;
    }
    if (_readNodeType(currentNode) === NODE_TYPE2.element && !_checkValidNamespace(currentNode)) {
      _forceRemove(currentNode);
      return true;
    }
    if ((tagName === "noscript" || tagName === "noembed" || tagName === "noframes") && regExpTest(FALLBACK_TAG_CLOSE, currentNode.innerHTML)) {
      _forceRemove(currentNode);
      return true;
    }
    if (SAFE_FOR_TEMPLATES && currentNode.nodeType === NODE_TYPE2.text) {
      const content = _stripTemplateExpressions(currentNode.textContent);
      if (currentNode.textContent !== content) {
        arrayPush(DOMPurify.removed, { element: currentNode.cloneNode() });
        currentNode.textContent = content;
      }
    }
    _executeHooks(hooks.afterSanitizeElements, currentNode, null);
    return _handleHookDetachedNode(currentNode, root2);
  };
  const _isValidAttribute = function _isValidAttribute2(lcTag, lcName, value) {
    if (FORBID_ATTR[lcName]) return false;
    if (_isPatchLinkageAttribute(lcName, lcTag)) return false;
    if (SANITIZE_DOM && (lcName === "id" || lcName === "name") && (value in document2 || value in formElement)) return false;
    const nameIsPermitted = ALLOWED_ATTR[lcName] || EXTRA_ELEMENT_HANDLING.attributeCheck instanceof Function && EXTRA_ELEMENT_HANDLING.attributeCheck(lcName, lcTag);
    if (ALLOW_DATA_ATTR && regExpTest(DATA_ATTR$1, lcName)) return true;
    if (ALLOW_ARIA_ATTR && regExpTest(ARIA_ATTR$1, lcName)) return true;
    if (!nameIsPermitted) return _isBasicCustomElement(lcTag) && _matchesNameCheck(CUSTOM_ELEMENT_HANDLING.tagNameCheck, lcTag) && _matchesNameCheck(CUSTOM_ELEMENT_HANDLING.attributeNameCheck, lcName, lcTag) || lcName === "is" && CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements && _matchesNameCheck(CUSTOM_ELEMENT_HANDLING.tagNameCheck, value);
    if (URI_SAFE_ATTRIBUTES[lcName]) return true;
    if (regExpTest(IS_ALLOWED_URI$1, stringReplace(value, ATTR_WHITESPACE$1, ""))) return true;
    if ((lcName === "src" || lcName === "xlink:href" || lcName === "href") && lcTag !== "script" && stringIndexOf(value, "data:") === 0 && DATA_URI_TAGS[lcTag]) return true;
    if (ALLOW_UNKNOWN_PROTOCOLS && !regExpTest(IS_SCRIPT_OR_DATA$1, stringReplace(value, ATTR_WHITESPACE$1, ""))) return true;
    return !value;
  };
  const RESERVED_CUSTOM_ELEMENT_NAMES = addToSet({}, [
    "annotation-xml",
    "color-profile",
    "font-face",
    "font-face-format",
    "font-face-name",
    "font-face-src",
    "font-face-uri",
    "missing-glyph"
  ]);
  const _isBasicCustomElement = function _isBasicCustomElement2(tagName) {
    return !RESERVED_CUSTOM_ELEMENT_NAMES[stringToLowerCase(tagName)] && regExpTest(CUSTOM_ELEMENT$1, tagName);
  };
  const _applyTrustedTypesToAttribute = function _applyTrustedTypesToAttribute2(lcTag, lcName, namespaceURI, value) {
    if (trustedTypesPolicy && typeof trustedTypes === "object" && typeof trustedTypes.getAttributeType === "function" && !namespaceURI) switch (trustedTypes.getAttributeType(lcTag, lcName)) {
      case "TrustedHTML":
        return _createTrustedHTML(value);
      case "TrustedScriptURL":
        return _createTrustedScriptURL(value);
    }
    return value;
  };
  const _setAttributeValue = function _setAttributeValue2(currentNode, name2, namespaceURI, value) {
    try {
      if (namespaceURI) currentNode.setAttributeNS(namespaceURI, name2, value);
      else currentNode.setAttribute(name2, value);
      if (_isClobbered(currentNode)) {
        _forceRemove(currentNode);
        return false;
      }
      return true;
    } catch (_) {
      _removeAttribute(name2, currentNode);
      return false;
    }
  };
  const _sanitizeAttributes = function _sanitizeAttributes2(currentNode, root2) {
    _executeHooks(hooks.beforeSanitizeAttributes, currentNode, null);
    if (_handleHookDetachedNode(currentNode, root2)) return;
    const attributes = currentNode.attributes;
    if (!attributes || _isClobbered(currentNode)) return;
    ALLOWED_ATTR = _forkSharedAllowlist(hooks.uponSanitizeAttribute, ALLOWED_ATTR, DEFAULT_ALLOWED_ATTR, SET_CONFIG_ALLOWED_ATTR);
    const hookEvent = {
      attrName: "",
      attrValue: "",
      keepAttr: true,
      allowedAttributes: ALLOWED_ATTR,
      forceKeepAttr: void 0
    };
    let l = attributes.length;
    const lcTag = transformCaseFunc(currentNode.nodeName);
    while (l--) {
      const attr = attributes[l];
      const name2 = attr.name, namespaceURI = attr.namespaceURI, attrValue = attr.value;
      const lcName = transformCaseFunc(name2);
      const initValue = attrValue;
      let value = name2 === "value" ? initValue : stringTrim(initValue);
      let recreatedNamedProp = false;
      hookEvent.attrName = lcName;
      hookEvent.attrValue = value;
      hookEvent.keepAttr = true;
      hookEvent.forceKeepAttr = void 0;
      _executeHooks(hooks.uponSanitizeAttribute, currentNode, hookEvent);
      value = hookEvent.attrValue;
      if (SANITIZE_NAMED_PROPS && (lcName === "id" || lcName === "name") && stringIndexOf(value, SANITIZE_NAMED_PROPS_PREFIX) !== 0) {
        _removeAttribute(name2, currentNode, attr);
        value = SANITIZE_NAMED_PROPS_PREFIX + value;
        recreatedNamedProp = true;
      }
      if (SAFE_FOR_XML && regExpTest(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i, value)) {
        _removeAttribute(name2, currentNode, attr);
        continue;
      }
      if (lcName === "attributename" && stringMatch(value, "href")) {
        _removeAttribute(name2, currentNode, attr);
        continue;
      }
      if (hookEvent.forceKeepAttr) continue;
      if (!hookEvent.keepAttr) {
        _removeAttribute(name2, currentNode, attr);
        continue;
      }
      if (!ALLOW_SELF_CLOSE_IN_ATTR && regExpTest(SELF_CLOSING_TAG, value)) {
        _removeAttribute(name2, currentNode, attr);
        continue;
      }
      if (SAFE_FOR_TEMPLATES) value = _stripTemplateExpressions(value);
      if (!_isValidAttribute(lcTag, lcName, value)) {
        _removeAttribute(name2, currentNode, attr);
        continue;
      }
      value = _applyTrustedTypesToAttribute(lcTag, lcName, namespaceURI, value);
      if (value !== initValue) {
        if (_setAttributeValue(currentNode, name2, namespaceURI, value) && recreatedNamedProp) arrayPop(DOMPurify.removed);
      }
    }
    _executeHooks(hooks.afterSanitizeAttributes, currentNode, null);
    _handleHookDetachedNode(currentNode, root2);
  };
  const _sanitizeShadowDOM2 = function _sanitizeShadowDOM(fragment) {
    let shadowNode = null;
    const shadowIterator = _createNodeIterator(fragment);
    _executeHooks(hooks.beforeSanitizeShadowDOM, fragment, null);
    while (shadowNode = shadowIterator.nextNode()) {
      _executeHooks(hooks.uponSanitizeShadowNode, shadowNode, null);
      _sanitizeElements(shadowNode, fragment);
      _sanitizeAttributes(shadowNode, fragment);
      if (_isDocumentFragment(shadowNode.content)) _sanitizeShadowDOM2(shadowNode.content);
      if (_readNodeType(shadowNode) === NODE_TYPE2.element) {
        const innerSr = getShadowRoot(shadowNode);
        if (_isDocumentFragment(innerSr)) {
          _sanitizeAttachedShadowRoots(innerSr);
          _sanitizeShadowDOM2(innerSr);
        }
      }
    }
    _executeHooks(hooks.afterSanitizeShadowDOM, fragment, null);
  };
  const _sanitizeAttachedShadowRoots = function _sanitizeAttachedShadowRoots2(root2) {
    const stack = [{
      node: root2,
      shadow: null
    }];
    while (stack.length > 0) {
      const item = stack.pop();
      if (item.shadow) {
        _sanitizeShadowDOM2(item.shadow);
        continue;
      }
      const node2 = item.node;
      const isElement = _readNodeType(node2) === NODE_TYPE2.element;
      const childNodes = getChildNodes(node2);
      if (childNodes) for (let i = childNodes.length - 1; i >= 0; --i) stack.push({
        node: childNodes[i],
        shadow: null
      });
      if (isElement) {
        const rootName = getNodeName ? getNodeName(node2) : null;
        if (typeof rootName === "string" && transformCaseFunc(rootName) === "template") {
          const content = node2.content;
          if (_isDocumentFragment(content)) stack.push({
            node: content,
            shadow: null
          });
        }
      }
      if (isElement) {
        const sr = getShadowRoot(node2);
        if (_isDocumentFragment(sr)) stack.push({
          node: null,
          shadow: sr
        }, {
          node: sr,
          shadow: null
        });
      }
    }
  };
  DOMPurify.sanitize = function(dirty) {
    let cfg = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    let body = null;
    let importedNode = null;
    let currentNode = null;
    let returnNode = null;
    IS_EMPTY_INPUT = !dirty;
    if (IS_EMPTY_INPUT) dirty = "<!-->";
    if (typeof dirty !== "string" && !_isNode(dirty)) {
      dirty = stringifyValue(dirty);
      if (typeof dirty !== "string") throw typeErrorCreate("dirty is not a string, aborting");
    }
    if (!DOMPurify.isSupported) return dirty;
    if (SET_CONFIG) {
      ALLOWED_TAGS = SET_CONFIG_ALLOWED_TAGS;
      ALLOWED_ATTR = SET_CONFIG_ALLOWED_ATTR;
    } else _parseConfig(cfg);
    if (hooks.uponSanitizeElement.length > 0 || hooks.uponSanitizeAttribute.length > 0) ALLOWED_TAGS = clone(ALLOWED_TAGS);
    if (hooks.uponSanitizeAttribute.length > 0) ALLOWED_ATTR = clone(ALLOWED_ATTR);
    DOMPurify.removed = [];
    const inPlace = IN_PLACE && typeof dirty !== "string" && _isNode(dirty);
    if (inPlace) {
      _neutralizePatchLinkage(dirty);
      const nn = _readNodeName(dirty);
      if (typeof nn === "string") {
        const tagName = transformCaseFunc(nn);
        if (!ALLOWED_TAGS[tagName] || FORBID_TAGS[tagName]) {
          _neutralizeRoot(dirty);
          throw typeErrorCreate("root node is forbidden and cannot be sanitized in-place");
        }
      }
      if (_isClobbered(dirty)) {
        _neutralizeRoot(dirty);
        throw typeErrorCreate("root node is clobbered and cannot be sanitized in-place");
      }
      try {
        _sanitizeAttachedShadowRoots(dirty);
      } catch (error) {
        _neutralizeRoot(dirty);
        throw error;
      }
    } else if (_isNode(dirty)) {
      body = _initDocument("<!---->");
      importedNode = body.ownerDocument.importNode(dirty, true);
      if (importedNode.nodeType === NODE_TYPE2.element && importedNode.nodeName === "BODY") body = importedNode;
      else if (importedNode.nodeName === "HTML") body = importedNode;
      else body.appendChild(importedNode);
      _sanitizeAttachedShadowRoots(body);
    } else {
      if (!RETURN_DOM && !SAFE_FOR_TEMPLATES && !WHOLE_DOCUMENT && dirty.indexOf("<") === -1) return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? _createTrustedHTML(dirty) : dirty;
      body = _initDocument(dirty);
      if (!body) return RETURN_DOM ? null : RETURN_TRUSTED_TYPE ? emptyHTML : "";
    }
    if (body && FORCE_BODY) _forceRemove(body.firstChild);
    const walkRoot = inPlace ? dirty : body;
    try {
      const nodeIterator = _createNodeIterator(walkRoot);
      while (currentNode = nodeIterator.nextNode()) {
        _sanitizeElements(currentNode, walkRoot);
        _sanitizeAttributes(currentNode, walkRoot);
        if (_isDocumentFragment(currentNode.content)) _sanitizeShadowDOM2(currentNode.content);
      }
    } catch (error) {
      if (inPlace) {
        _neutralizeRoot(dirty);
        arrayForEach(DOMPurify.removed, (entry) => {
          if (entry.element) _neutralizeSubtree(entry.element);
        });
      }
      throw error;
    }
    if (inPlace) {
      let rootWasRemoved = false;
      arrayForEach(DOMPurify.removed, (entry) => {
        if (entry.element) {
          if (entry.element === dirty) rootWasRemoved = true;
          _neutralizeSubtree(entry.element);
        }
      });
      if (rootWasRemoved) throw typeErrorCreate("a node selected for removal could not be safely returned; refusing to sanitize in place");
      if (SAFE_FOR_TEMPLATES) _scrubTemplateExpressions2(dirty);
      return dirty;
    }
    if (RETURN_DOM) {
      if (SAFE_FOR_TEMPLATES) _scrubTemplateExpressions2(body);
      if (RETURN_DOM_FRAGMENT) {
        returnNode = createDocumentFragment.call(body.ownerDocument);
        while (body.firstChild) returnNode.appendChild(body.firstChild);
      } else returnNode = body;
      if (ALLOWED_ATTR.shadowroot || ALLOWED_ATTR.shadowrootmode) returnNode = importNode.call(originalDocument, returnNode, true);
      return returnNode;
    }
    let serializedHTML = WHOLE_DOCUMENT ? body.outerHTML : body.innerHTML;
    if (WHOLE_DOCUMENT && ALLOWED_TAGS["!doctype"] && body.ownerDocument && body.ownerDocument.doctype && body.ownerDocument.doctype.name && regExpTest(DOCTYPE_NAME, body.ownerDocument.doctype.name)) serializedHTML = "<!DOCTYPE " + body.ownerDocument.doctype.name + ">\n" + serializedHTML;
    if (SAFE_FOR_TEMPLATES) serializedHTML = _stripTemplateExpressions(serializedHTML);
    return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? _createTrustedHTML(serializedHTML) : serializedHTML;
  };
  DOMPurify.setConfig = function() {
    let cfg = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    _parseConfig(cfg);
    SET_CONFIG = true;
    SET_CONFIG_ALLOWED_TAGS = ALLOWED_TAGS;
    SET_CONFIG_ALLOWED_ATTR = ALLOWED_ATTR;
  };
  DOMPurify.clearConfig = function() {
    CONFIG = null;
    SET_CONFIG = false;
    SET_CONFIG_ALLOWED_TAGS = null;
    SET_CONFIG_ALLOWED_ATTR = null;
    trustedTypesPolicy = defaultTrustedTypesPolicy;
    emptyHTML = "";
  };
  DOMPurify.isValidAttribute = function(tag, attr, value) {
    if (!CONFIG) _parseConfig({});
    const lcTag = transformCaseFunc(tag);
    const lcName = transformCaseFunc(attr);
    return _isValidAttribute(lcTag, lcName, value);
  };
  DOMPurify.addHook = function(entryPoint, hookFunction) {
    if (typeof hookFunction !== "function") return;
    if (!objectHasOwnProperty(hooks, entryPoint)) return;
    arrayPush(hooks[entryPoint], hookFunction);
  };
  DOMPurify.removeHook = function(entryPoint, hookFunction) {
    if (!objectHasOwnProperty(hooks, entryPoint)) return;
    if (hookFunction !== void 0) {
      const index = arrayLastIndexOf(hooks[entryPoint], hookFunction);
      return index === -1 ? void 0 : arraySplice(hooks[entryPoint], index, 1)[0];
    }
    return arrayPop(hooks[entryPoint]);
  };
  DOMPurify.removeHooks = function(entryPoint) {
    if (!objectHasOwnProperty(hooks, entryPoint)) return;
    hooks[entryPoint] = [];
  };
  DOMPurify.removeAllHooks = function() {
    hooks = _createHooksMap();
  };
  return DOMPurify;
}
var purify_default = createDOMPurify();

// node_modules/turndown/lib/turndown.browser.es.js
function extend(destination) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) destination[key] = source[key];
    }
  }
  return destination;
}
function repeat(character, count) {
  return Array(count + 1).join(character);
}
function trimLeadingNewlines(string2) {
  return string2.replace(/^\n*/, "");
}
function trimTrailingNewlines(string2) {
  var indexEnd = string2.length;
  while (indexEnd > 0 && string2[indexEnd - 1] === "\n") indexEnd--;
  return string2.substring(0, indexEnd);
}
function trimNewlines(string2) {
  return trimTrailingNewlines(trimLeadingNewlines(string2));
}
var blockElements = ["ADDRESS", "ARTICLE", "ASIDE", "AUDIO", "BLOCKQUOTE", "BODY", "CANVAS", "CENTER", "DD", "DIR", "DIV", "DL", "DT", "FIELDSET", "FIGCAPTION", "FIGURE", "FOOTER", "FORM", "FRAMESET", "H1", "H2", "H3", "H4", "H5", "H6", "HEADER", "HGROUP", "HR", "HTML", "ISINDEX", "LI", "MAIN", "MENU", "NAV", "NOFRAMES", "NOSCRIPT", "OL", "OUTPUT", "P", "PRE", "SECTION", "TABLE", "TBODY", "TD", "TFOOT", "TH", "THEAD", "TR", "UL"];
function isBlock2(node2) {
  return is(node2, blockElements);
}
var voidElements = ["AREA", "BASE", "BR", "COL", "COMMAND", "EMBED", "HR", "IMG", "INPUT", "KEYGEN", "LINK", "META", "PARAM", "SOURCE", "TRACK", "WBR"];
function isVoid(node2) {
  return is(node2, voidElements);
}
function hasVoid(node2) {
  return has(node2, voidElements);
}
var meaningfulWhenBlankElements = ["A", "TABLE", "THEAD", "TBODY", "TFOOT", "TH", "TD", "IFRAME", "SCRIPT", "AUDIO", "VIDEO"];
function isMeaningfulWhenBlank(node2) {
  return is(node2, meaningfulWhenBlankElements);
}
function hasMeaningfulWhenBlank(node2) {
  return has(node2, meaningfulWhenBlankElements);
}
function is(node2, tagNames) {
  return tagNames.indexOf(node2.nodeName) >= 0;
}
function has(node2, tagNames) {
  return node2.getElementsByTagName && tagNames.some(function(tagName) {
    return node2.getElementsByTagName(tagName).length;
  });
}
var markdownEscapes = [[/\\/g, "\\\\"], [/\*/g, "\\*"], [/^-/g, "\\-"], [/^\+ /g, "\\+ "], [/^(=+)/g, "\\$1"], [/^(#{1,6}) /g, "\\$1 "], [/`/g, "\\`"], [/^~~~/g, "\\~~~"], [/\[/g, "\\["], [/\]/g, "\\]"], [/^>/g, "\\>"], [/_/g, "\\_"], [/^(\d+)\. /g, "$1\\. "]];
function escapeMarkdown(string2) {
  return markdownEscapes.reduce(function(accumulator, escape) {
    return accumulator.replace(escape[0], escape[1]);
  }, string2);
}
var rules = {};
rules.paragraph = {
  filter: "p",
  replacement: function(content) {
    return "\n\n" + content + "\n\n";
  }
};
rules.lineBreak = {
  filter: "br",
  replacement: function(content, node2, options) {
    return options.br + "\n";
  }
};
rules.heading = {
  filter: ["h1", "h2", "h3", "h4", "h5", "h6"],
  replacement: function(content, node2, options) {
    var hLevel = Number(node2.nodeName.charAt(1));
    if (options.headingStyle === "setext" && hLevel < 3) {
      var underline = repeat(hLevel === 1 ? "=" : "-", content.length);
      return "\n\n" + content + "\n" + underline + "\n\n";
    } else {
      return "\n\n" + repeat("#", hLevel) + " " + content + "\n\n";
    }
  }
};
rules.blockquote = {
  filter: "blockquote",
  replacement: function(content) {
    content = trimNewlines(content).replace(/^/gm, "> ");
    return "\n\n" + content + "\n\n";
  }
};
rules.list = {
  filter: ["ul", "ol"],
  replacement: function(content, node2) {
    var parent = node2.parentNode;
    if (parent.nodeName === "LI" && parent.lastElementChild === node2) {
      return "\n" + content;
    } else {
      return "\n\n" + content + "\n\n";
    }
  }
};
rules.listItem = {
  filter: "li",
  replacement: function(content, node2, options) {
    var prefix = options.bulletListMarker + "   ";
    var parent = node2.parentNode;
    if (parent.nodeName === "OL") {
      var start = parent.getAttribute("start");
      var index = Array.prototype.indexOf.call(parent.children, node2);
      prefix = (start ? Number(start) + index : index + 1) + ".  ";
    }
    var isParagraph = /\n$/.test(content);
    content = trimNewlines(content) + (isParagraph ? "\n" : "");
    content = content.replace(/\n/gm, "\n" + " ".repeat(prefix.length));
    return prefix + content + (node2.nextSibling ? "\n" : "");
  }
};
rules.indentedCodeBlock = {
  filter: function(node2, options) {
    return options.codeBlockStyle === "indented" && node2.nodeName === "PRE" && node2.firstChild && node2.firstChild.nodeName === "CODE";
  },
  replacement: function(content, node2, options) {
    return "\n\n    " + node2.firstChild.textContent.replace(/\n/g, "\n    ") + "\n\n";
  }
};
rules.fencedCodeBlock = {
  filter: function(node2, options) {
    return options.codeBlockStyle === "fenced" && node2.nodeName === "PRE" && node2.firstChild && node2.firstChild.nodeName === "CODE";
  },
  replacement: function(content, node2, options) {
    var className = node2.firstChild.getAttribute("class") || "";
    var language = (className.match(/language-(\S+)/) || [null, ""])[1];
    var code = node2.firstChild.textContent;
    var fenceChar = options.fence.charAt(0);
    var fenceSize = 3;
    var fenceInCodeRegex = new RegExp("^" + fenceChar + "{3,}", "gm");
    var match;
    while (match = fenceInCodeRegex.exec(code)) {
      if (match[0].length >= fenceSize) {
        fenceSize = match[0].length + 1;
      }
    }
    var fence = repeat(fenceChar, fenceSize);
    return "\n\n" + fence + language + "\n" + code.replace(/\n$/, "") + "\n" + fence + "\n\n";
  }
};
rules.horizontalRule = {
  filter: "hr",
  replacement: function(content, node2, options) {
    return "\n\n" + options.hr + "\n\n";
  }
};
rules.inlineLink = {
  filter: function(node2, options) {
    return options.linkStyle === "inlined" && node2.nodeName === "A" && node2.getAttribute("href");
  },
  replacement: function(content, node2) {
    var href = escapeLinkDestination(node2.getAttribute("href"));
    var title = escapeLinkTitle(cleanAttribute(node2.getAttribute("title")));
    var titlePart = title ? ' "' + title + '"' : "";
    return "[" + content + "](" + href + titlePart + ")";
  }
};
rules.referenceLink = {
  filter: function(node2, options) {
    return options.linkStyle === "referenced" && node2.nodeName === "A" && node2.getAttribute("href");
  },
  replacement: function(content, node2, options) {
    var href = escapeLinkDestination(node2.getAttribute("href"));
    var title = cleanAttribute(node2.getAttribute("title"));
    if (title) title = ' "' + escapeLinkTitle(title) + '"';
    var replacement;
    var reference;
    switch (options.linkReferenceStyle) {
      case "collapsed":
        replacement = "[" + content + "][]";
        reference = "[" + content + "]: " + href + title;
        break;
      case "shortcut":
        replacement = "[" + content + "]";
        reference = "[" + content + "]: " + href + title;
        break;
      default:
        var id = this.references.length + 1;
        replacement = "[" + content + "][" + id + "]";
        reference = "[" + id + "]: " + href + title;
    }
    this.references.push(reference);
    return replacement;
  },
  references: [],
  append: function(options) {
    var references = "";
    if (this.references.length) {
      references = "\n\n" + this.references.join("\n") + "\n\n";
      this.references = [];
    }
    return references;
  }
};
rules.emphasis = {
  filter: ["em", "i"],
  replacement: function(content, node2, options) {
    if (!content.trim()) return "";
    return options.emDelimiter + content + options.emDelimiter;
  }
};
rules.strong = {
  filter: ["strong", "b"],
  replacement: function(content, node2, options) {
    if (!content.trim()) return "";
    return options.strongDelimiter + content + options.strongDelimiter;
  }
};
rules.code = {
  filter: function(node2) {
    var hasSiblings = node2.previousSibling || node2.nextSibling;
    var isCodeBlock = node2.parentNode.nodeName === "PRE" && !hasSiblings;
    return node2.nodeName === "CODE" && !isCodeBlock;
  },
  replacement: function(content) {
    if (!content) return "";
    content = content.replace(/\r?\n|\r/g, " ");
    var extraSpace = /^`|^ .*?[^ ].* $|`$/.test(content) ? " " : "";
    var delimiter = "`";
    var matches = content.match(/`+/gm) || [];
    while (matches.indexOf(delimiter) !== -1) delimiter = delimiter + "`";
    return delimiter + extraSpace + content + extraSpace + delimiter;
  }
};
rules.image = {
  filter: "img",
  replacement: function(content, node2) {
    var alt = escapeMarkdown(cleanAttribute(node2.getAttribute("alt")));
    var src = escapeLinkDestination(node2.getAttribute("src") || "");
    var title = cleanAttribute(node2.getAttribute("title"));
    var titlePart = title ? ' "' + escapeLinkTitle(title) + '"' : "";
    return src ? "![" + alt + "](" + src + titlePart + ")" : "";
  }
};
function cleanAttribute(attribute) {
  return attribute ? attribute.replace(/(\n+\s*)+/g, "\n") : "";
}
function escapeLinkDestination(destination) {
  var escaped = destination.replace(/([<>()])/g, "\\$1");
  return escaped.indexOf(" ") >= 0 ? "<" + escaped + ">" : escaped;
}
function escapeLinkTitle(title) {
  return title.replace(/"/g, '\\"');
}
function Rules(options) {
  this.options = options;
  this._keep = [];
  this._remove = [];
  this.blankRule = {
    replacement: options.blankReplacement
  };
  this.keepReplacement = options.keepReplacement;
  this.defaultRule = {
    replacement: options.defaultReplacement
  };
  this.array = [];
  for (var key in options.rules) this.array.push(options.rules[key]);
}
Rules.prototype = {
  add: function(key, rule) {
    this.array.unshift(rule);
  },
  keep: function(filter) {
    this._keep.unshift({
      filter,
      replacement: this.keepReplacement
    });
  },
  remove: function(filter) {
    this._remove.unshift({
      filter,
      replacement: function() {
        return "";
      }
    });
  },
  forNode: function(node2) {
    if (node2.isBlank) return this.blankRule;
    var rule;
    if (rule = findRule(this.array, node2, this.options)) return rule;
    if (rule = findRule(this._keep, node2, this.options)) return rule;
    if (rule = findRule(this._remove, node2, this.options)) return rule;
    return this.defaultRule;
  },
  forEach: function(fn) {
    for (var i = 0; i < this.array.length; i++) fn(this.array[i], i);
  }
};
function findRule(rules2, node2, options) {
  for (var i = 0; i < rules2.length; i++) {
    var rule = rules2[i];
    if (filterValue(rule, node2, options)) return rule;
  }
  return void 0;
}
function filterValue(rule, node2, options) {
  var filter = rule.filter;
  if (typeof filter === "string") {
    if (filter === node2.nodeName.toLowerCase()) return true;
  } else if (Array.isArray(filter)) {
    if (filter.indexOf(node2.nodeName.toLowerCase()) > -1) return true;
  } else if (typeof filter === "function") {
    if (filter.call(rule, node2, options)) return true;
  } else {
    throw new TypeError("`filter` needs to be a string, array, or function");
  }
}
function collapseWhitespace(options) {
  var element = options.element;
  var isBlock3 = options.isBlock;
  var isVoid2 = options.isVoid;
  var isPre = options.isPre || function(node3) {
    return node3.nodeName === "PRE";
  };
  if (!element.firstChild || isPre(element)) return;
  var prevText = null;
  var keepLeadingWs = false;
  var prev = null;
  var node2 = next(prev, element, isPre);
  while (node2 !== element) {
    if (node2.nodeType === 3 || node2.nodeType === 4) {
      var text2 = node2.data.replace(/[ \r\n\t]+/g, " ");
      if ((!prevText || / $/.test(prevText.data)) && !keepLeadingWs && text2[0] === " ") {
        text2 = text2.substr(1);
      }
      if (!text2) {
        node2 = remove(node2);
        continue;
      }
      node2.data = text2;
      prevText = node2;
    } else if (node2.nodeType === 1) {
      if (isBlock3(node2) || node2.nodeName === "BR") {
        if (prevText) {
          prevText.data = prevText.data.replace(/ $/, "");
        }
        prevText = null;
        keepLeadingWs = false;
      } else if (isVoid2(node2) || isPre(node2)) {
        prevText = null;
        keepLeadingWs = true;
      } else if (prevText) {
        keepLeadingWs = false;
      }
    } else {
      node2 = remove(node2);
      continue;
    }
    var nextNode = next(prev, node2, isPre);
    prev = node2;
    node2 = nextNode;
  }
  if (prevText) {
    prevText.data = prevText.data.replace(/ $/, "");
    if (!prevText.data) {
      remove(prevText);
    }
  }
}
function remove(node2) {
  var next2 = node2.nextSibling || node2.parentNode;
  node2.parentNode.removeChild(node2);
  return next2;
}
function next(prev, current, isPre) {
  if (prev && prev.parentNode === current || isPre(current)) {
    return current.nextSibling || current.parentNode;
  }
  return current.firstChild || current.nextSibling || current.parentNode;
}
var root = typeof window !== "undefined" ? window : {};
function canParseHTMLNatively() {
  var Parser2 = root.DOMParser;
  var canParse = false;
  try {
    if (new Parser2().parseFromString("", "text/html")) {
      canParse = true;
    }
  } catch (e) {
  }
  return canParse;
}
function createHTMLParser() {
  var Parser2 = function() {
  };
  {
    if (shouldUseActiveX()) {
      Parser2.prototype.parseFromString = function(string2) {
        var doc = new window.ActiveXObject("htmlfile");
        doc.designMode = "on";
        doc.open();
        doc.write(string2);
        doc.close();
        return doc;
      };
    } else {
      Parser2.prototype.parseFromString = function(string2) {
        var doc = document.implementation.createHTMLDocument("");
        doc.open();
        doc.write(string2);
        doc.close();
        return doc;
      };
    }
  }
  return Parser2;
}
function shouldUseActiveX() {
  var useActiveX = false;
  try {
    document.implementation.createHTMLDocument("").open();
  } catch (e) {
    if (root.ActiveXObject) useActiveX = true;
  }
  return useActiveX;
}
var HTMLParser = canParseHTMLNatively() ? root.DOMParser : createHTMLParser();
function RootNode(input, options) {
  var root2;
  if (typeof input === "string") {
    var doc = htmlParser().parseFromString(
      // DOM parsers arrange elements in the <head> and <body>.
      // Wrapping in a custom element ensures elements are reliably arranged in
      // a single element.
      '<x-turndown id="turndown-root">' + input + "</x-turndown>",
      "text/html"
    );
    root2 = doc.getElementById("turndown-root");
  } else {
    root2 = input.cloneNode(true);
  }
  collapseWhitespace({
    element: root2,
    isBlock: isBlock2,
    isVoid,
    isPre: options.preformattedCode ? isPreOrCode : null
  });
  return root2;
}
var _htmlParser;
function htmlParser() {
  _htmlParser = _htmlParser || new HTMLParser();
  return _htmlParser;
}
function isPreOrCode(node2) {
  return node2.nodeName === "PRE" || node2.nodeName === "CODE";
}
function Node(node2, options) {
  node2.isBlock = isBlock2(node2);
  node2.isCode = node2.nodeName === "CODE" || node2.parentNode.isCode;
  node2.isBlank = isBlank(node2);
  node2.flankingWhitespace = flankingWhitespace(node2, options);
  return node2;
}
function isBlank(node2) {
  return !isVoid(node2) && !isMeaningfulWhenBlank(node2) && /^\s*$/i.test(node2.textContent) && !hasVoid(node2) && !hasMeaningfulWhenBlank(node2);
}
function flankingWhitespace(node2, options) {
  if (node2.isBlock || options.preformattedCode && node2.isCode) {
    return {
      leading: "",
      trailing: ""
    };
  }
  var edges = edgeWhitespace(node2.textContent);
  if (edges.leadingAscii && isFlankedByWhitespace("left", node2, options)) {
    edges.leading = edges.leadingNonAscii;
  }
  if (edges.trailingAscii && isFlankedByWhitespace("right", node2, options)) {
    edges.trailing = edges.trailingNonAscii;
  }
  return {
    leading: edges.leading,
    trailing: edges.trailing
  };
}
function edgeWhitespace(string2) {
  var m = string2.match(/^(([ \t\r\n]*)(\s*))(?:(?=\S)[\s\S]*\S)?((\s*?)([ \t\r\n]*))$/);
  return {
    leading: m[1],
    // whole string for whitespace-only strings
    leadingAscii: m[2],
    leadingNonAscii: m[3],
    trailing: m[4],
    // empty for whitespace-only strings
    trailingNonAscii: m[5],
    trailingAscii: m[6]
  };
}
function isFlankedByWhitespace(side, node2, options) {
  var sibling;
  var regExp;
  var isFlanked;
  if (side === "left") {
    sibling = node2.previousSibling;
    regExp = / $/;
  } else {
    sibling = node2.nextSibling;
    regExp = /^ /;
  }
  if (sibling) {
    if (sibling.nodeType === 3) {
      isFlanked = regExp.test(sibling.nodeValue);
    } else if (options.preformattedCode && sibling.nodeName === "CODE") {
      isFlanked = false;
    } else if (sibling.nodeType === 1 && !isBlock2(sibling)) {
      isFlanked = regExp.test(sibling.textContent);
    }
  }
  return isFlanked;
}
var reduce = Array.prototype.reduce;
function TurndownService(options) {
  if (!(this instanceof TurndownService)) return new TurndownService(options);
  var defaults = {
    rules,
    headingStyle: "setext",
    hr: "* * *",
    bulletListMarker: "*",
    codeBlockStyle: "indented",
    fence: "```",
    emDelimiter: "_",
    strongDelimiter: "**",
    linkStyle: "inlined",
    linkReferenceStyle: "full",
    br: "  ",
    preformattedCode: false,
    blankReplacement: function(content, node2) {
      return node2.isBlock ? "\n\n" : "";
    },
    keepReplacement: function(content, node2) {
      return node2.isBlock ? "\n\n" + node2.outerHTML + "\n\n" : node2.outerHTML;
    },
    defaultReplacement: function(content, node2) {
      return node2.isBlock ? "\n\n" + content + "\n\n" : content;
    }
  };
  this.options = extend({}, defaults, options);
  this.rules = new Rules(this.options);
}
TurndownService.prototype = {
  /**
   * The entry point for converting a string or DOM node to Markdown
   * @public
   * @param {String|HTMLElement} input The string or DOM node to convert
   * @returns A Markdown representation of the input
   * @type String
   */
  turndown: function(input) {
    if (!canConvert(input)) {
      throw new TypeError(input + " is not a string, or an element/document/fragment node.");
    }
    if (input === "") return "";
    var output = process2.call(this, new RootNode(input, this.options));
    return postProcess.call(this, output);
  },
  /**
   * Add one or more plugins
   * @public
   * @param {Function|Array} plugin The plugin or array of plugins to add
   * @returns The Turndown instance for chaining
   * @type Object
   */
  use: function(plugin) {
    if (Array.isArray(plugin)) {
      for (var i = 0; i < plugin.length; i++) this.use(plugin[i]);
    } else if (typeof plugin === "function") {
      plugin(this);
    } else {
      throw new TypeError("plugin must be a Function or an Array of Functions");
    }
    return this;
  },
  /**
   * Adds a rule
   * @public
   * @param {String} key The unique key of the rule
   * @param {Object} rule The rule
   * @returns The Turndown instance for chaining
   * @type Object
   */
  addRule: function(key, rule) {
    this.rules.add(key, rule);
    return this;
  },
  /**
   * Keep a node (as HTML) that matches the filter
   * @public
   * @param {String|Array|Function} filter The unique key of the rule
   * @returns The Turndown instance for chaining
   * @type Object
   */
  keep: function(filter) {
    this.rules.keep(filter);
    return this;
  },
  /**
   * Remove a node that matches the filter
   * @public
   * @param {String|Array|Function} filter The unique key of the rule
   * @returns The Turndown instance for chaining
   * @type Object
   */
  remove: function(filter) {
    this.rules.remove(filter);
    return this;
  },
  /**
   * Escapes Markdown syntax
   * @public
   * @param {String} string The string to escape
   * @returns A string with Markdown syntax escaped
   * @type String
   */
  escape: function(string2) {
    return escapeMarkdown(string2);
  }
};
function process2(parentNode) {
  var self = this;
  return reduce.call(parentNode.childNodes, function(output, node2) {
    node2 = new Node(node2, self.options);
    var replacement = "";
    if (node2.nodeType === 3) {
      replacement = node2.isCode ? node2.nodeValue : self.escape(node2.nodeValue);
    } else if (node2.nodeType === 1) {
      replacement = replacementForNode.call(self, node2);
    }
    return join(output, replacement);
  }, "");
}
function postProcess(output) {
  var self = this;
  this.rules.forEach(function(rule) {
    if (typeof rule.append === "function") {
      output = join(output, rule.append(self.options));
    }
  });
  return output.replace(/^[\t\r\n]+/, "").replace(/[\t\r\n\s]+$/, "");
}
function replacementForNode(node2) {
  var rule = this.rules.forNode(node2);
  var content = process2.call(this, node2);
  var whitespace = node2.flankingWhitespace;
  if (whitespace.leading || whitespace.trailing) content = content.trim();
  return whitespace.leading + rule.replacement(content, node2, this.options) + whitespace.trailing;
}
function join(output, replacement) {
  var s1 = trimTrailingNewlines(output);
  var s2 = trimLeadingNewlines(replacement);
  var nls = Math.max(output.length - s1.length, replacement.length - s2.length);
  var separator = "\n\n".substring(0, nls);
  return s1 + separator + s2;
}
function canConvert(input) {
  return input != null && (typeof input === "string" || input.nodeType && (input.nodeType === 1 || input.nodeType === 9 || input.nodeType === 11));
}

// src/classification-view.js
var import_obsidian2 = require("obsidian");
var AutoClassifyModal = class extends import_obsidian2.Modal {
  constructor(view, batch) {
    super(view.app);
    this.view = view;
    this.batch = batch;
  }
  onOpen() {
    const root2 = this.contentEl;
    root2.classList.add("tz-classify");
    const heading = document.createElement("h2");
    heading.textContent = "\u81EA\u52A8\u5206\u7C7B";
    root2.append(heading);
    const copy = document.createElement("p");
    copy.textContent = "\u4E3A\u672A\u5173\u8054\u77E5\u8BC6\u70B9\u7684\u9898\u76EE\u8865\u9F50\u5206\u7C7B\u3002\u5148\u6309\u5DF2\u6709\u8003\u70B9\u6807\u7B7E\u5339\u914D\u672C\u5730\u77E5\u8BC6\u6811\uFF0C\u65E0\u6CD5\u786E\u5B9A\u7684\u9898\u4EA4\u7ED9 Agent \u5224\u65AD\u3002\u6559\u6750\u7AE0\u8282\u4FDD\u6301\u539F\u6837\u3002";
    root2.append(copy);
    const status = document.createElement("p");
    status.className = "tz-status";
    root2.append(status);
    const start = document.createElement("button");
    start.textContent = this.batch ? "\u5206\u7C7B\u672C\u6B21\u5BFC\u5165" : "\u5206\u7C7B\u6240\u6709\u672A\u5173\u8054\u9898\u76EE";
    start.className = "mod-cta";
    root2.append(start);
    start.onclick = async () => {
      start.disabled = true;
      status.textContent = "\u6B63\u5728\u68C0\u67E5\u672C\u5730\u9898\u76EE\u4E0E\u77E5\u8BC6\u6811\u2026\u2026";
      try {
        const result = await this.view.plugin.runLocal("auto-classify", this.batch ? ["--batch", this.batch] : []);
        status.textContent = result.considered ? `\u5DF2\u5173\u8054 ${result.classified} \u9898\uFF0C${result.pending} \u9898\u5F85 Agent \u5224\u65AD\u3002` : "\u5168\u90E8\u9898\u76EE\u90FD\u5DF2\u5173\u8054\u77E5\u8BC6\u70B9\u3002";
        start.remove();
        if (result.report) {
          const report = document.createElement("button");
          report.textContent = "\u67E5\u770B\u5206\u7C7B\u62A5\u544A";
          report.onclick = () => this.view.openFile(result.report.replace(this.app.vault.adapter.getBasePath(), "").replace(/^[\\/]/, "").replace(/\\/g, "/"));
          root2.append(report);
        }
        if (result.pending) {
          const prompt = `\u4F7F\u7528 tizhuang-local-bank\uFF0C\u7EE7\u7EED\u9898\u5E93\u201C${this.app.vault.adapter.getBasePath()}\u201D\u7684\u77E5\u8BC6\u70B9\u5206\u7C7B\u4EFB\u52A1\u3002\u8BFB\u53D6\u62A5\u544A\u201C${result.report}\u201D\u53CA\u5BF9\u5E94 result.json\uFF0C\u53EA\u5904\u7406\u5176\u4E2D\u5F85\u5224\u65AD\u7684\u9898\u76EE\u3002\u9605\u8BFB\u539F\u6587\u4E0E\u914D\u56FE\uFF0C\u5339\u914D\u672C\u5730\u6807\u51C6\u77E5\u8BC6\u6811\u7684\u771F\u5B9E\u8282\u70B9\uFF1B\u7EFC\u5408\u9898\u53EF\u5173\u8054\u591A\u4E2A\u3002\u751F\u6210\u5E76\u9A8C\u8BC1 classify \u6E05\u5355\u540E\u5E94\u7528\uFF0C\u4FDD\u7559\u6B63\u6587\u3001\u5206\u503C\u3001\u5BA1\u6838\u72B6\u6001\uFF0C\u6682\u4E0D\u5206\u6559\u6750\u7AE0\u8282\u3002`;
          const area = document.createElement("textarea");
          area.readOnly = true;
          area.value = prompt;
          area.rows = 4;
          root2.append(area);
          const agent = document.createElement("button");
          agent.textContent = "\u590D\u5236 Agent \u5206\u7C7B\u6307\u4EE4";
          agent.onclick = async () => {
            try {
              await window.navigator.clipboard.writeText(prompt);
              new import_obsidian2.Notice("\u5DF2\u590D\u5236\uFF0C\u8BF7\u4EA4\u7ED9\u4F60\u4F7F\u7528\u7684 Agent\u3002");
            } catch {
              area.focus();
              area.select();
            }
          };
          root2.append(agent);
        }
        await this.view.refresh();
      } catch (error) {
        status.textContent = error.message;
        start.disabled = false;
      }
    };
  }
  onClose() {
    this.contentEl.replaceChildren();
  }
};

// src/library-view.js
var import_obsidian4 = require("obsidian");

// src/library-core.js
function startSteps(catalog) {
  const rows = catalog.rows || [], reviewed = rows.filter((r) => r.q.status === "reviewed").length;
  const steps = [
    { id: "tree", title: "\u4E0B\u8F7D\u77E5\u8BC6\u6811", hint: "\u5728\u201C\u7F51\u7AD9\u53D6\u9898\u201D\u9009\u597D\u5B66\u79D1\u548C\u5B66\u6BB5\uFF0C\u76EE\u5F55\u4F1A\u4FDD\u5B58\u5230\u672C\u5730\uFF1B\u4E4B\u540E\u5206\u7C7B\u3001\u6309\u8003\u70B9\u627E\u9898\u90FD\u9760\u5B83\u3002", done: (catalog.trees || []).some((t) => t.kind === "knowledge"), action: "website", cta: "\u53BB\u4E0B\u8F7D" },
    { id: "import", title: "\u653E\u5165\u7B2C\u4E00\u6279\u9898", hint: "\u5BFC\u5165\u4E00\u4EFD PDF \u8BD5\u5377\uFF0C\u6216\u4ECE\u7F51\u7AD9\u4FDD\u5B58\u51E0\u9053\u9898\u3002", done: rows.length > 0, action: "pdf", cta: "\u5BFC\u5165 PDF" },
    { id: "review", title: "\u6838\u5BF9\u9898\u76EE", hint: "\u5728\u201C\u6211\u7684\u9898\u76EE\u201D\u5C55\u5F00\u9898\u76EE\uFF0C\u9010\u9898\u67E5\u770B\u9898\u5E72\u3001\u7B54\u6848\u548C\u914D\u56FE\uFF0C\u786E\u8BA4\u540E\u70B9\u201C\u6807\u8BB0\u4E3A\u5DF2\u6838\u5BF9\u201D\uFF1B\u6B63\u5F0F\u7EC4\u5377\u53EA\u7528\u5DF2\u6838\u5BF9\u7684\u9898\u3002", done: reviewed > 0, action: "review", cta: "\u53BB\u6838\u5BF9", locked: !rows.length },
    { id: "paper", title: "\u7EC4\u51FA\u7B2C\u4E00\u5F20\u8BD5\u5377", hint: "\u5728\u201C\u6211\u7684\u9898\u76EE\u201D\u52FE\u9009\u9898\u76EE\u52A0\u5165\u7EC4\u5377\u7BEE\uFF0C\u751F\u6210\u65E0\u7B54\u6848 Word \u548C\u6559\u5E08\u7B54\u6848 Word\u3002", done: (catalog.papers || []).length > 0, action: "basket", cta: "\u6253\u5F00\u7EC4\u5377\u7BEE", locked: !reviewed }
  ];
  const current = steps.find((s) => !s.done && !s.locked) || null;
  return { steps, current, complete: steps.every((s) => s.done) };
}
var LocalCatalog = class {
  constructor(store) {
    this.store = store;
    this.rows = [];
    this.errors = [];
    this.trees = [];
    this.names = {};
  }
  async load() {
    await this.store.init();
    this.rows = [];
    this.errors = [];
    this.trees = [];
    for (const path of await this.store.files("\u9898\u76EE\u5E93")) {
      try {
        const q = readNote(await this.store.io.read(path));
        if (q.schema !== "tizhuang.question/v1" || !q.id) throw Error("\u4E0D\u662F\u6709\u6548\u9898\u76EE");
        this.rows.push({ path, q });
      } catch (e) {
        this.errors.push({ path, message: e.message });
      }
    }
    this.names = await this.store.json(".bank/catalog/names.json", { subjects: {}, phases: {}, editions: {} });
    for (const [folder, kind] of [[".bank/taxonomy", "knowledge"], [".bank/textbooks", "chapter"]]) for (const path of await this.store.files(folder, ".json")) {
      try {
        const data = await this.store.json(path);
        if (!Array.isArray(data.nodes)) continue;
        const scope = [data.subject_id, data.phase_id, ...kind === "chapter" ? [data.edition_id] : []].join("-");
        this.trees.push({ ...data, kind, scope });
      } catch (e) {
        this.errors.push({ path, message: e.message });
      }
    }
    this.papers = (await this.store.files("\u8BD5\u5377")).filter((p) => p.endsWith("/\u8BD5\u5377.md"));
    this.paperTitles = /* @__PURE__ */ new Map();
    for (const path of this.papers) {
      const data = await this.store.json(path.replace(/试卷\.md$/, "manifest.json"));
      const text2 = await this.store.io.read(path);
      this.paperTitles.set(path, data.title || text2.match(/^#\s+(.+)$/m)?.[1] || path.split("/").at(-2));
    }
    this.imports = [];
    for (const path of await this.store.files(".bank/imports", ".json")) if (path.endsWith("/manifest.json")) {
      try {
        this.imports.push(await this.store.json(path));
      } catch {
        this.errors.push({ path, message: "\u5BFC\u5165\u8BB0\u5F55\u65E0\u6CD5\u8BFB\u53D6" });
      }
    }
    const reports = await this.store.files("\u5F85\u6574\u7406");
    for (const batch of this.imports) batch.reportPath = reports.find((p) => p.endsWith(" \xB7 " + batch.id.slice(0, 6) + ".md"));
    this.imports.sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
    return this;
  }
  scopeTitle(tree) {
    return [this.names.phases?.[tree.phase_id] || `\u5B66\u6BB5${tree.phase_id}`, this.names.subjects?.[tree.subject_id] || `\u5B66\u79D1${tree.subject_id}`, tree.kind === "chapter" ? this.names.editions?.[tree.edition_id] || `\u6559\u6750${tree.edition_id}` : "\u77E5\u8BC6\u70B9"].join(" \xB7 ");
  }
  treeMatch(q, tree) {
    return String(q.subject_id) === String(tree.subject_id) && String(q.phase_id) === String(tree.phase_id) && (tree.kind !== "chapter" || String(q.edition_id) === String(tree.edition_id));
  }
  descendants(tree, id) {
    const set2 = /* @__PURE__ */ new Set([String(id)]);
    let more = true;
    while (more) {
      more = false;
      for (const n of tree.nodes) if (set2.has(String(n.parent_id)) && !set2.has(String(n.id))) {
        set2.add(String(n.id));
        more = true;
      }
    }
    return set2;
  }
  select(filter = {}) {
    const tree = this.trees.find((t) => t.scope === filter.scope && t.kind === filter.kind);
    const ids = tree && filter.node ? this.descendants(tree, filter.node) : null;
    return this.rows.filter(({ q }) => {
      if (filter.status && q.status !== filter.status) return false;
      if (filter.unclassified && q.knowledge_tree_ids.length + q.chapter_ids.length) return false;
      if (filter.tag && !q.tags.some((t) => t === filter.tag || t.startsWith(filter.tag + "/"))) return false;
      if (filter.type && q.type !== filter.type) return false;
      if (filter.kind === "knowledge" || filter.kind === "chapter") {
        if (!tree || !this.treeMatch(q, tree)) return false;
        if (ids && !q[filter.kind === "knowledge" ? "knowledge_tree_ids" : "chapter_ids"].some((id) => ids.has(String(id)))) return false;
      }
      if (filter.query && !`${q.title}
${q.content}
${q.search_text}
${q.tags.join(" ")}`.toLocaleLowerCase().includes(filter.query.toLocaleLowerCase())) return false;
      return true;
    });
  }
  tagTree() {
    const map2 = /* @__PURE__ */ new Map();
    for (const { q } of this.rows) for (const tag of q.tags) {
      const parts = tag.split("/");
      for (let i = 1; i <= parts.length; i++) {
        const path = parts.slice(0, i).join("/");
        if (!map2.has(path)) map2.set(path, { id: path, name: parts[i - 1], parent_id: parts.slice(0, i - 1).join("/"), ids: /* @__PURE__ */ new Set() });
        map2.get(path).ids.add(q.id);
      }
    }
    return [...map2.values()].sort((a, b) => a.id.localeCompare(b.id, "zh-CN"));
  }
  async classify(path, { tags, knowledge }) {
    const original = await this.store.io.read(path), q = readNote(original);
    const tree = this.trees.find((t) => t.kind === "knowledge" && this.treeMatch(q, t));
    knowledge = knowledge.map(String);
    if (knowledge.length && (!tree || knowledge.some((id) => !tree.nodes.some((n) => String(n.id) === id)))) throw Error("\u77E5\u8BC6\u70B9\u4E0D\u5C5E\u4E8E\u8BE5\u9898\u7684\u5B66\u79D1\u5B66\u6BB5\u3002");
    const m = original.match(/^\uFEFF?---\r?\n([\s\S]*?)\r?\n---\r?\n/), meta = browser_default.parse(m[1]);
    delete meta["\u6807\u7B7E"];
    delete meta.knowledge_tree_ids;
    meta.tags = nativeTags(tags);
    meta["\u77E5\u8BC6\u8282\u70B9\u7F16\u53F7"] = knowledge;
    meta["\u7CBE\u786E\u77E5\u8BC6\u7F16\u53F7"] = (tree?.nodes || []).filter((n) => knowledge.includes(String(n.id)) && n.knowledge_id != null).map((n) => String(n.knowledge_id));
    let body = original.slice(m[0].length);
    const managed = /<!-- bank:knowledge:start -->[\s\S]*?<!-- bank:knowledge:end -->/g;
    if (body.includes("<!-- bank:knowledge:")) {
      if ((body.match(managed) || []).length !== 1) throw Error("\u77E5\u8BC6\u5173\u8054\u533A\u5757\u6807\u8BB0\u4E0D\u5B8C\u6574\uFF0C\u8BF7\u68C0\u67E5\u7B14\u8BB0\u3002");
      const mapping = await this.store.json(".bank/ui-paths.json", {}), paths = mapping.knowledge?.[`${q.subject_id}-${q.phase_id}`] || {};
      const links = knowledge.map((id) => {
        const name2 = tree.nodes.find((n) => String(n.id) === id).name, p = paths[id];
        return "- " + (p ? `[[${p.replace(/\.md$/, "")}|${name2}]]` : name2);
      }).join("\n");
      body = body.replace(managed, () => knowledge.length ? `<!-- bank:knowledge:start -->
## \u77E5\u8BC6\u70B9\u5206\u7C7B

${links}
<!-- bank:knowledge:end -->` : "");
    }
    const backup = ".bank/backups/" + q.id + "-" + crypto.randomUUID() + ".md";
    await this.store.mkdir(".bank/backups");
    await this.store.io.write(backup, original);
    if (await this.store.io.read(path) !== original) throw Error("\u9898\u76EE\u521A\u88AB\u5176\u4ED6\u64CD\u4F5C\u4FEE\u6539\uFF0C\u8BF7\u5237\u65B0\u540E\u91CD\u8BD5\u3002");
    await this.store.io.write(path, "---\n" + browser_default.stringify(meta, { version: "1.1" }) + "---\n" + body);
    await this.load();
    return q.id;
  }
  async writeHome() {
    const reviewed = this.rows.filter((r) => r.q.status === "reviewed").length;
    let text2 = `# \u9898\u5E93\u9996\u9875

\u5171 **${this.rows.length}** \u9898 \xB7 \u5DF2\u6838\u5BF9 **${reviewed}** \u9898 \xB7 \u5F85\u6838\u5BF9 **${this.rows.length - reviewed}** \u9898 \xB7 \u8BD5\u5377 **${this.papers.length}** \u4EFD

\`\`\`tizhuang-dashboard
\`\`\`

## \u6211\u7684\u9898\u76EE

`;
    const groups = /* @__PURE__ */ new Map();
    for (const row of this.rows) {
      const knowledge = this.trees.find((t) => t.kind === "knowledge" && this.treeMatch(row.q, t))?.nodes || [], chapters = this.trees.find((t) => t.kind === "chapter" && this.treeMatch(row.q, t))?.nodes || [];
      const group = groupFolder(row.q, this.names, knowledge, chapters).replaceAll("/", " \xB7 ");
      if (!groups.has(group)) groups.set(group, []);
      groups.get(group).push(row);
    }
    for (const [group, rows] of groups) {
      text2 += `### ${group}\uFF08${rows.length}\uFF09

`;
      for (const { path, q } of rows) text2 += `- ${hasImage(q) ? "[\u56FE] " : ""}[[${path.slice(0, -3)}|${cleanTitle(q.title).replace(/[\[\]|]/g, " ")}]] \xB7 ${q.type} \xB7 ${q.status === "reviewed" ? "\u5DF2\u6838\u5BF9" : "\u5F85\u6838\u5BF9"}
`;
      text2 += "\n";
    }
    text2 += "## \u6211\u7684\u8BD5\u5377\n\n" + (this.papers.map((path) => `- [[${path.slice(0, -3)}|${this.paperTitles.get(path)}]]`).join("\n") || "\u6682\u65E0\u8BD5\u5377\u3002\u6838\u5BF9\u9898\u76EE\u540E\uFF0C\u53EF\u4EA4\u7ED9 Agent \u7EC4\u5377\u3002") + "\n\n\u539F\u4EF6\u548C\u56FE\u7247\u6536\u5728\u300C\u8D44\u6599\u300D\uFF0C\u5907\u8BFE\u7B14\u8BB0\u653E\u5728\u300C\u6559\u5B66\u7B14\u8BB0\u300D\u3002\n";
    if (!await this.store.io.exists("\u9898\u5E93\u9996\u9875.md") || await this.store.io.read("\u9898\u5E93\u9996\u9875.md") !== text2) await this.store.io.write("\u9898\u5E93\u9996\u9875.md", text2);
  }
};

// src/paper-view.js
var import_obsidian3 = require("obsidian");
var E = (p, t, text2, cls) => {
  const e = document.createElement(t);
  if (text2 != null) e.textContent = text2;
  if (cls) e.className = cls;
  p.append(e);
  return e;
};
var B = (p, text2, fn, cls = "tz-quiet") => {
  const b = E(p, "button", text2, cls);
  b.type = "button";
  b.onclick = fn;
  return b;
};
var ClearBasketModal = class extends import_obsidian3.Modal {
  constructor(app, done) {
    super(app);
    this.done = done;
  }
  onOpen() {
    E(this.contentEl, "h2", "\u6E05\u7A7A\u7EC4\u5377\u7BEE\uFF1F");
    E(this.contentEl, "p", "\u9898\u5E93\u539F\u9898\u548C\u5DF2\u751F\u6210\u8BD5\u5377\u4F1A\u4FDD\u7559\u3002");
    B(this.contentEl, "\u4FDD\u7559", () => this.close());
    B(this.contentEl, "\u6E05\u7A7A\u7EC4\u5377\u7BEE", async () => {
      await this.done();
      this.close();
    }, "tz-primary");
  }
  onClose() {
    this.contentEl.replaceChildren();
  }
};
function basketBar(view, parent) {
  const bar = E(parent, "div", null, "tz-basket-bar");
  view.basketBarEl = bar;
  updateBasketBar(view);
  return bar;
}
function updateBasketBar(view) {
  const b = view.plugin.basket;
  if (!view.basketBarEl) return;
  view.basketBarEl.replaceChildren();
  E(view.basketBarEl, "span", `\u5DF2\u9009 ${b.data.items.length} \u9898 \xB7 ${b.total()} \u5206`);
  B(view.basketBarEl, "\u67E5\u770B\u7EC4\u5377\u7BEE", () => view.show("basket"), "tz-primary");
  const tab = view.contentEl.querySelector('[data-tab="basket"]');
  if (tab) tab.textContent = `\u7EC4\u5377\u7BEE${b.data.items.length ? "\uFF08" + b.data.items.length + "\uFF09" : ""}`;
}
function drawBasket(view) {
  const basket = view.plugin.basket, root2 = view.body;
  root2.replaceChildren();
  const heading = E(root2, "div", null, "tz-paper-heading");
  const title = E(heading, "div");
  E(title, "h2", "\u628A\u597D\u9898\uFF0C\u6392\u6210\u4E00\u5F20\u5377\u3002");
  E(title, "p", "\u62D6\u52A8\u6392\u9898\u5E8F\uFF0C\u5355\u72EC\u8BBE\u5206\u503C\uFF1B\u751F\u6210\u65F6\u4FDD\u7559\u539F\u9898\u3001\u516C\u5F0F\u548C\u914D\u56FE\u3002", "tz-muted");
  B(heading, "\u7EE7\u7EED\u9009\u9898", () => view.show("questions"));
  if (!basket.data.items.length) {
    const empty = E(root2, "div", null, "tz-basket-empty");
    E(empty, "h3", "\u7EC4\u5377\u7BEE\u8FD8\u662F\u7A7A\u7684");
    E(empty, "p", "\u5728\u201C\u6211\u7684\u9898\u76EE\u201D\u4E2D\u52FE\u9009\uFF0C\u8DE8\u7AE0\u8282\u9009\u9898\u4E5F\u4F1A\u4FDD\u7559\u3002", "tz-muted");
    B(empty, "\u53BB\u672C\u5730\u9898\u5E93\u9009\u9898", () => view.show("questions"), "tz-primary");
    return;
  }
  const missing = basket.data.items.filter((i) => !view.catalog.rows.some((r) => r.q.id === i.question_id));
  const drafts = basket.data.items.filter((i) => view.catalog.rows.find((r) => r.q.id === i.question_id)?.q.status !== "reviewed");
  const workspace = E(root2, "fieldset", null, "tz-paper-workspace"), list = E(workspace, "section", null, "tz-paper-basket-list"), aside = E(workspace, "aside", null, "tz-paper-settings");
  let status, generate, confirmed;
  const fail = (error) => {
    status.textContent = error.message;
    status.classList.add("tz-error");
  };
  const mutate = async (fn, redraw = true) => {
    try {
      await fn();
      if (redraw) drawBasket(view);
      else {
        status.textContent = "\u5DF2\u4FDD\u5B58";
        root2.querySelector(".tz-paper-total strong").textContent = String(basket.total());
        root2.querySelector(".tz-paper-success")?.remove();
      }
      updateBasketBar(view);
    } catch (error) {
      fail(error);
    }
  };
  const top = E(list, "div", null, "tz-local-summary");
  E(top, "strong", `${basket.data.items.length} \u9053\u9898\uFF0C\u6309\u5F53\u524D\u987A\u5E8F\u751F\u6210`);
  B(top, "\u6E05\u7A7A", () => new ClearBasketModal(view.app, () => mutate(() => basket.clear())).open());
  for (const [index, item] of basket.data.items.entries()) {
    const row = view.catalog.rows.find((r) => r.q.id === item.question_id), q = row?.q;
    const card = E(list, "article", null, "tz-question tz-basket-card");
    card.dataset.questionId = item.question_id;
    card.ondragover = (event) => event.preventDefault();
    card.ondrop = (event) => {
      event.preventDefault();
      const id = event.dataTransfer.getData("text/tizhuang-question");
      if (basket.has(id)) mutate(() => basket.move(id, index));
    };
    const head = E(card, "div", null, "tz-question-head"), handle = E(head, "span", "\u283F", "tz-drag-handle");
    handle.draggable = true;
    handle.title = "\u62D6\u52A8\u8C03\u6574\u9898\u5E8F";
    handle.ondragstart = (event) => {
      event.dataTransfer.setData("text/tizhuang-question", item.question_id);
      event.dataTransfer.effectAllowed = "move";
    };
    E(head, "strong", String(index + 1), "tz-order");
    E(head, "span", q?.type || "\u9898\u76EE\u7F3A\u5931", "tz-type");
    E(head, "span", q?.status === "reviewed" ? "\u5DF2\u6838\u5BF9" : "\u5F85\u6838\u5BF9", "tz-local-status");
    const body = E(card, "div", null, "tz-local-title");
    if (q && hasImage(q)) E(body, "span", "[\u56FE]", "tz-image-label");
    E(body, "span", q ? cleanTitle(q.title, q.type) : "\u8FD9\u9053\u9898\u5DF2\u88AB\u79FB\u8D70\u6216\u5220\u9664\uFF0C\u8BF7\u4ECE\u7EC4\u5377\u7BEE\u79FB\u9664\u540E\u518D\u751F\u6210\u3002");
    const tools = E(card, "div", null, "tz-basket-item-tools");
    const scoreLabel = E(tools, "label", "\u672C\u9898 "), score = E(scoreLabel, "input");
    score.type = "number";
    score.value = item.score;
    score.min = "0";
    score.max = "1000";
    score.step = "0.01";
    score.required = true;
    score.setAttribute("aria-label", `\u7B2C ${index + 1} \u9898\u5206\u503C`);
    E(scoreLabel, "span", " \u5206");
    score.onchange = () => mutate(() => basket.score(item.question_id, score.value), false);
    const up = B(tools, "\u4E0A\u79FB", () => mutate(() => basket.move(item.question_id, index - 1)));
    up.disabled = index === 0;
    up.setAttribute("aria-label", `\u4E0A\u79FB\u7B2C ${index + 1} \u9898`);
    const down = B(tools, "\u4E0B\u79FB", () => mutate(() => basket.move(item.question_id, index + 1)));
    down.disabled = index === basket.data.items.length - 1;
    down.setAttribute("aria-label", `\u4E0B\u79FB\u7B2C ${index + 1} \u9898`);
    B(tools, "\u79FB\u9664", () => mutate(() => basket.remove(item.question_id)));
    if (q) {
      const detail = E(card, "div", null, "tz-question-details");
      detail.hidden = true;
      let rendered = false;
      B(tools, "\u67E5\u770B\u539F\u9898\u4E0E\u7B54\u6848", async (event) => {
        detail.hidden = !detail.hidden;
        event.currentTarget.textContent = detail.hidden ? "\u67E5\u770B\u539F\u9898\u4E0E\u7B54\u6848" : "\u6536\u8D77";
        if (!rendered) {
          try {
            for (const [key, name3] of [["content", "\u9898\u76EE"], ["answer", "\u7B54\u6848"], ["analysis", "\u89E3\u6790"]]) {
              if (!q[key]) continue;
              const section = E(detail, "section", null, "tz-detail-section");
              E(section, "h4", name3);
              const content = E(section, "div", null, "tz-preview");
              const text2 = q[key].replace(/Assets\/([a-f0-9]+\.[a-z0-9]+)/g, (_, f) => {
                const path = view.plugin.store.assetDir + "/" + f, target = view.app.vault.getAbstractFileByPath(path);
                return target ? view.app.vault.getResourcePath(target) : path;
              });
              await import_obsidian3.MarkdownRenderer.render(view.app, text2, content, row.path, view);
            }
            rendered = true;
          } catch (error) {
            fail(error);
          }
        }
      });
    }
  }
  E(aside, "h3", "\u8BD5\u5377\u8BBE\u7F6E");
  const nameLabel = E(aside, "label", "\u8BD5\u5377\u6807\u9898", "tz-label"), name2 = E(nameLabel, "input");
  name2.value = basket.data.title;
  name2.maxLength = 120;
  name2.required = true;
  name2.setAttribute("aria-label", "\u8BD5\u5377\u6807\u9898");
  name2.onchange = () => mutate(() => basket.settings({ title: name2.value }), false);
  const field = (label2, key, min, max, unit) => {
    const l = E(aside, "label", label2, "tz-label"), line = E(l, "div", null, "tz-paper-number"), input = E(line, "input");
    input.type = "number";
    input.min = min;
    input.max = max;
    input.step = "1";
    input.required = true;
    input.value = basket.data[key];
    input.setAttribute("aria-label", label2);
    E(line, "span", unit);
    input.onchange = () => mutate(() => basket.settings({ [key]: input.value === "" ? NaN : Number(input.value), ...key === "duration_minutes" ? { duration_custom: true } : {} }), false);
  };
  field("\u8003\u8BD5\u65F6\u957F", "duration_minutes", 1, 600, "\u5206\u949F");
  field("\u6BCF\u9898\u4F5C\u7B54\u7559\u767D", "answer_space_mm", 0, 100, "\u6BEB\u7C73");
  const total = E(aside, "div", null, "tz-paper-total");
  E(total, "span", "\u8BD5\u5377\u603B\u5206");
  E(total, "strong", String(basket.total()));
  E(total, "small", `${basket.data.items.length} \u9898`);
  E(aside, "p", "\u65F6\u957F\u6309\u5B66\u79D1\u5B66\u6BB5\u5EFA\u8BAE\uFF0C\u53EF\u81EA\u7531\u8C03\u6574\uFF1B\u5206\u503C\u53EA\u7528\u4E8E\u672C\u5377\u3002", "tz-muted");
  if (missing.length) E(aside, "p", `${missing.length} \u9053\u9898\u5DF2\u4E0D\u5B58\u5728\uFF0C\u8BF7\u5148\u79FB\u9664\u3002`, "tz-error");
  if (drafts.length && !missing.length) {
    const label2 = E(aside, "label", null, "tz-review-check");
    confirmed = E(label2, "input");
    confirmed.type = "checkbox";
    confirmed.setAttribute("aria-label", "\u5DF2\u9010\u9898\u6838\u5BF9\u5F85\u6838\u5BF9\u9898");
    E(label2, "span", `\u6211\u5DF2\u9010\u9898\u6838\u5BF9\u8FD9 ${drafts.length} \u9053\u5F85\u6838\u5BF9\u9898\u7684\u9898\u5E72\u3001\u7B54\u6848\u548C\u56FE\u7247\u3002`);
    confirmed.onchange = () => generate.disabled = !confirmed.checked;
  }
  status = E(aside, "p", null, "tz-status");
  generate = B(aside, "\u751F\u6210\u8BD5\u5377\u4E0E\u6559\u5E08\u7B54\u6848", async () => {
    for (const input of workspace.querySelectorAll("input")) if (!input.reportValidity()) return;
    workspace.disabled = true;
    status.textContent = "\u6B63\u5728\u6574\u7406\u9898\u5E8F\u3001\u5206\u503C\u548C\u672C\u5730\u56FE\u7247\u2026\u2026";
    try {
      await basket.generate(view.plugin, !!confirmed?.checked);
      await view.catalog.load();
      await view.catalog.writeHome();
      drawBasket(view);
    } catch (error) {
      fail(error);
      workspace.disabled = false;
      generate.textContent = "\u91CD\u8BD5\u751F\u6210";
    }
  }, "tz-primary tz-paper-generate");
  generate.disabled = !!missing.length || !!drafts.length;
  E(aside, "p", "\u672C\u5730\u751F\u6210 Word \u53CC\u7248\uFF0C\u53EF\u7EE7\u7EED\u7F16\u8F91\uFF1B\u53E6\u9644\u6253\u5370\u7A3F\uFF0C\u53EF\u5B58\u4E3A PDF\u3002", "tz-muted");
  if (basket.data.last_result) {
    const result = basket.data.last_result, box = E(aside, "div", null, "tz-paper-success");
    E(box, "strong", "\u4E24\u4EFD\u8BD5\u5377\u5DF2\u4FDD\u5B58");
    if (result.student_docx && result.teacher_docx) {
      B(box, "\u7F16\u8F91\u65E0\u7B54\u6848 Word", () => view.plugin.openLocalOutput(result.student_docx), "tz-primary");
      B(box, "\u7F16\u8F91\u6559\u5E08\u7B54\u6848 Word", () => view.plugin.openLocalOutput(result.teacher_docx));
    } else {
      E(box, "p", "\u8FD9\u4EFD\u65E7\u5377\u4EC5\u6709\u6253\u5370\u7A3F\uFF0C\u751F\u6210\u65B0\u4E00\u7248\u5373\u53EF\u540C\u65F6\u83B7\u5F97 Word\u3002", "tz-muted");
    }
    B(box, "\u6253\u5F00\u65E0\u7B54\u6848\u8BD5\u5377", () => view.plugin.openLocalOutput(result.student));
    B(box, "\u6253\u5F00\u6559\u5E08\u7B54\u6848\u7248", () => view.plugin.openLocalOutput(result.teacher));
    B(box, "\u5F00\u59CB\u65B0\u4E00\u7248", async () => {
      await basket.save();
      await view.catalog.load();
      drawBasket(view);
    });
    B(box, "\u67E5\u770B\u8BD5\u5377\u8BB0\u5F55", () => view.openFile(result.note.replace(/\\/g, "/").slice(view.app.vault.adapter.getBasePath().replace(/\\/g, "/").length + 1)));
  }
}

// src/library-view.js
var LIBRARY_VIEW = "tizhuang-local-library";
var E2 = (p, t, text2, cls) => {
  const e = document.createElement(t);
  if (text2 != null) e.textContent = text2;
  if (cls) e.className = cls;
  p.append(e);
  return e;
};
var B2 = (p, text2, fn, cls = "tz-quiet") => {
  const b = E2(p, "button", text2, cls);
  b.type = "button";
  b.onclick = fn;
  return b;
};
var select = (p, title, entries2, value, fn) => {
  const label2 = E2(p, "label", title, "tz-label"), el = E2(label2, "select");
  el.setAttribute("aria-label", title);
  for (const [id, name2] of entries2) {
    const o = E2(el, "option", name2);
    o.value = id;
  }
  el.value = value || "";
  el.onchange = () => fn(el.value);
  return el;
};
var ClassifyModal = class extends import_obsidian4.Modal {
  constructor(app, catalog, row, done) {
    super(app);
    this.catalog = catalog;
    this.row = row;
    this.done = done;
  }
  onOpen() {
    const root2 = this.contentEl;
    root2.classList.add("tz-classify");
    E2(root2, "h2", "\u6574\u7406\u5206\u7C7B\u4E0E\u6807\u7B7E");
    E2(root2, "p", cleanTitle(this.row.q.title));
    const label2 = E2(root2, "label", "\u6807\u7B7E\uFF08\u7528\u9017\u53F7\u5206\u9694\uFF0C\u659C\u6760\u8868\u793A\u5C42\u7EA7\uFF09"), tags = E2(label2, "textarea");
    tags.value = this.row.q.tags.join(", ");
    tags.rows = 3;
    const tree = this.catalog.trees.find((t) => t.kind === "knowledge" && this.catalog.treeMatch(this.row.q, t));
    const selected = new Set(this.row.q.knowledge_tree_ids);
    E2(root2, "p", "\u5173\u8054\u77E5\u8BC6\u70B9\uFF1A\u53EF\u591A\u9009\uFF0C\u6559\u6750\u7AE0\u8282\u4FDD\u7559\u539F\u5173\u8054\u3002", "tz-muted");
    const search = E2(root2, "input");
    search.placeholder = "\u67E5\u627E\u77E5\u8BC6\u70B9";
    search.setAttribute("aria-label", "\u67E5\u627E\u77E5\u8BC6\u70B9");
    const list = E2(root2, "div", null, "tz-knowledge-picker");
    const draw = () => {
      list.replaceChildren();
      for (const n of tree?.nodes || []) {
        if (search.value && !n.name.includes(search.value)) continue;
        const line = E2(list, "label"), c = E2(line, "input");
        c.type = "checkbox";
        c.checked = selected.has(String(n.id));
        c.onchange = () => c.checked ? selected.add(String(n.id)) : selected.delete(String(n.id));
        E2(line, "span", n.name);
      }
      if (!tree) E2(list, "p", "\u8BE5\u5B66\u79D1\u5B66\u6BB5\u5C1A\u672A\u4E0B\u8F7D\u77E5\u8BC6\u6811\uFF0C\u53EF\u4EE5\u5148\u4FDD\u5B58\u6807\u7B7E\u3002");
    };
    draw();
    search.oninput = draw;
    const status = E2(root2, "p", null, "tz-status"), actions = E2(root2, "div", null, "tz-actions");
    B2(actions, "\u53D6\u6D88", () => this.close());
    const save = B2(actions, "\u4FDD\u5B58\u5206\u7C7B", async () => {
      save.disabled = true;
      try {
        await this.catalog.classify(this.row.path, { tags: nativeTags(tags.value), knowledge: [...selected] });
        this.close();
        await this.done();
      } catch (error) {
        status.textContent = error.message;
        save.disabled = false;
      }
    }, "tz-primary");
  }
  onClose() {
    this.contentEl.replaceChildren();
  }
};
var LibraryView = class extends import_obsidian4.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.catalog = new LocalCatalog(plugin.store);
    this.filter = { ...plugin.settings.libraryFilter || {} };
    this.tab = plugin.settings.libraryTab || "home";
    this.dimension = plugin.settings.libraryDimension || "chapter";
    this.sequence = 0;
    this.closed = false;
    this.pdfBusy = false;
  }
  getViewType() {
    return LIBRARY_VIEW;
  }
  getDisplayText() {
    return "\u9898\u5E84\u672C\u5730\u9898\u5E93";
  }
  getIcon() {
    return "library";
  }
  async onOpen() {
    await this.refresh();
  }
  async onClose() {
    this.closed = true;
    this.sequence++;
    clearTimeout(this.searchTimer);
  }
  async refresh() {
    if (this.pdfBusy || this.plugin.basket?.busy) return;
    const seq2 = ++this.sequence;
    try {
      await this.plugin.basket.queue;
      await this.plugin.basket.load();
      await this.plugin.store.syncKnowledgeDirectories();
      await this.catalog.load();
      if (this.closed || seq2 !== this.sequence) return;
      this.draw();
      const cfg = await this.plugin.store.json(".bank/config.json");
      if (cfg.ui_layout === "teacher/v2") await this.catalog.writeHome();
    } catch (error) {
      this.contentEl.replaceChildren();
      E2(this.contentEl, "p", error.message, "tz-error");
    }
  }
  async remember() {
    this.plugin.settings.libraryTab = this.tab;
    this.plugin.settings.libraryFilter = { ...this.filter };
    this.plugin.settings.libraryDimension = this.dimension;
    await this.plugin.saveData(this.plugin.settings);
  }
  async show(tab, filter) {
    this.tab = tab;
    if (filter) this.filter = filter;
    await this.remember();
    if (tab === "home" && !this.pdfBusy && !this.plugin.basket?.busy) await this.refresh();
    else this.draw();
  }
  async fromContext(context) {
    this.tab = "questions";
    this.dimension = context.mode === "chapter" ? "chapter" : "knowledge";
    this.filter = { kind: this.dimension, scope: [context.scope.subject_id, context.scope.phase_id, ...this.dimension === "chapter" ? [context.scope.edition_id] : []].join("-"), node: String(context.scope.chapter_id || context.scope.knowledge_tree_id) };
    await this.refresh();
    await this.remember();
  }
  draw() {
    const root2 = this.contentEl;
    root2.replaceChildren();
    root2.classList.add("tz-bank", "tz-library");
    const shell = E2(root2, "div", null, "tz-shell");
    const head = E2(shell, "header", null, "tz-header");
    renderBrand(head);
    const actions = E2(head, "div", null, "tz-header-actions");
    B2(actions, "\u5237\u65B0", () => this.refresh());
    const website = B2(actions, "", () => window.open("https://tizhuang.qcscience.cc/", "_blank", "noopener,noreferrer"));
    website.classList.add("tz-icon-button");
    website.title = "\u6253\u5F00\u9898\u5E84\u5B98\u7F51";
    website.setAttribute("aria-label", "\u6253\u5F00\u9898\u5E84\u5B98\u7F51");
    website.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0M3 12h18M12 3c5 5 5 13 0 18-5-5-5-13 0-18"/></svg>';
    renderNavigation(shell, this, this.tab);
    this.status = E2(shell, "p", null, "tz-status");
    this.status.setAttribute("role", "status");
    this.status.setAttribute("aria-live", "polite");
    if (this.catalog.errors.length) {
      E2(shell, "p", `${this.catalog.errors.length} \u4E2A\u6587\u4EF6\u9700\u8981\u68C0\u67E5\uFF0C\u5176\u4F59\u9898\u76EE\u53EF\u6B63\u5E38\u6D4F\u89C8\u3002`, "tz-error");
      const details = E2(shell, "details");
      E2(details, "summary", "\u67E5\u770B\u5F02\u5E38\u6587\u4EF6");
      for (const item of this.catalog.errors) B2(details, item.path + "\uFF1A" + item.message, () => this.openFile(item.path));
    }
    this.body = E2(shell, "div", null, "tz-lib-body");
    if (this.tab === "home") this.home();
    else if (this.tab === "pdf") this.pdf();
    else if (this.tab === "basket") drawBasket(this);
    else this.questions();
  }
  // Marking reviewed is the teacher's explicit act: it runs the same verified CLI path (image check + backup) as the paper basket.
  async markReviewed(ids) {
    if (this.plugin.localTaskActive || this.plugin.store.busy) {
      new import_obsidian4.Notice("\u6B63\u5728\u5199\u5165\u9898\u5E93\uFF0C\u8BF7\u7A0D\u5019\u3002");
      return false;
    }
    try {
      await this.plugin.runLocal("review", ["--ids", ...ids, "--confirm"]);
      new import_obsidian4.Notice(`\u5DF2\u6807\u8BB0 ${ids.length} \u9898\u4E3A\u5DF2\u6838\u5BF9\u3002`);
      await this.refresh();
      return true;
    } catch (error) {
      new import_obsidian4.Notice(error.message);
      return false;
    }
  }
  confirmReview(rows) {
    const view = this, modal = new import_obsidian4.Modal(this.app);
    modal.onOpen = () => {
      const root2 = modal.contentEl;
      E2(root2, "h2", `\u6807\u8BB0 ${rows.length} \u9053\u9898\u4E3A\u5DF2\u6838\u5BF9`);
      E2(root2, "p", "\u8BF7\u786E\u8BA4\u4F60\u5DF2\u7ECF\u9010\u9898\u770B\u8FC7\u9898\u5E72\u3001\u7B54\u6848\u548C\u914D\u56FE\u3002\u6807\u8BB0\u540E\u8FD9\u4E9B\u9898\u624D\u80FD\u7528\u4E8E\u6B63\u5F0F\u7EC4\u5377\u3002", "tz-muted");
      const actions = E2(root2, "div", null, "tz-actions");
      B2(actions, "\u53D6\u6D88", () => modal.close());
      B2(actions, "\u6211\u5DF2\u6838\u5BF9\uFF0C\u6807\u8BB0", async () => {
        modal.close();
        await view.markReviewed(rows.map((r) => r.q.id));
      }, "tz-primary");
    };
    modal.onClose = () => modal.contentEl.replaceChildren();
    modal.open();
  }
  openFile(path) {
    return this.app.workspace.openLinkText(path, "", false);
  }
  batchRow(parent, batch) {
    const line = E2(parent, "div", null, "tz-import-row");
    E2(line, "strong", batch.filename);
    const labels = { prepared: "\u5F85 Agent \u8FD8\u539F\u6B63\u6587", partial: "\u90E8\u5206\u5BFC\u5165\uFF0C\u53EF\u7EE7\u7EED", needs_agent: "\u5F85 Agent \u8BC6\u522B", imported: "\u5DF2\u5BFC\u5165\uFF0C\u5F85\u6838\u5BF9" };
    E2(line, "span", `${batch.pages.length} \u9875 \xB7 ${Object.keys(batch.imported || {}).length} \u9898\u5DF2\u5165\u5E93 \xB7 ${labels[batch.status] || "\u5F85\u5904\u7406"}`);
    const actions = E2(line, "div", null, "tz-actions");
    if (Object.keys(batch.imported || {}).length) B2(actions, "\u81EA\u52A8\u5206\u7C7B", () => new AutoClassifyModal(this, batch.id).open());
    if (batch.reportPath) B2(actions, "\u67E5\u770B\u62A5\u544A", () => this.openFile(batch.reportPath));
    if (batch.status === "partial" && batch.representation === "editable") B2(actions, "\u7EE7\u7EED\u5BFC\u5165", async () => {
      if (this.pdfBusy) return;
      this.pdfBusy = true;
      try {
        await this.plugin.runLocal("pdf-import", ["--batch", batch.id]);
        new import_obsidian4.Notice("\u5DF2\u5BFC\u5165\u8349\u7A3F\u5E76\u5C1D\u8BD5\u5173\u8054\u77E5\u8BC6\u70B9\uFF1B\u8BF7\u67E5\u770B\u5206\u7C7B\u62A5\u544A\u5E76\u6838\u5BF9\u9898\u76EE\u3002");
      } catch (error) {
        new import_obsidian4.Notice(error.message);
      } finally {
        this.pdfBusy = false;
        await this.refresh();
      }
    });
    if (batch.status !== "imported" && !(batch.status === "partial" && batch.representation === "editable")) B2(actions, "\u590D\u5236 Agent \u6307\u4EE4", async () => {
      const prompt = `\u4F7F\u7528 tizhuang-local-bank\uFF0C\u5728\u9898\u5E93\u201C${this.app.vault.adapter.getBasePath()}\u201D\u4E2D\u7EE7\u7EED PDF \u5BFC\u5165\u6279\u6B21 ${batch.id}\u3002\u67E5\u770B\u5168\u90E8\u539F\u9875\uFF0C\u5C06\u9898\u5E72\u3001\u9009\u9879\u3001\u516C\u5F0F\u548C\u8868\u683C\u8FD8\u539F\u4E3A\u53EF\u7F16\u8F91 Markdown/LaTeX\uFF0C\u5355\u72EC\u63D0\u53D6\u914D\u56FE\u3002\u53BB\u6389\u6B63\u6587\u539F\u9898\u53F7\u548C\u56FE\u7247\u4E2D\u7684\u201C\u7B2C\u51E0\u9898\u56FE\u201D\uFF0C\u539F\u7F16\u53F7\u53EA\u7559\u5728\u6765\u6E90\u8BB0\u5F55\uFF0C\u4FDD\u7559\u5C0F\u95EE\u4E0E\u56FE\u2460\u7B49\u5BF9\u5E94\u5173\u7CFB\u3002\u6838\u5BF9\u539F\u7B54\u6848\uFF0C\u6839\u636E\u8003\u67E5\u5185\u5BB9\u5173\u8054\u5230\u672C\u5730\u6807\u51C6\u77E5\u8BC6\u70B9\u6811\uFF0C\u7EFC\u5408\u9898\u53EF\u5173\u8054\u591A\u4E2A\u77E5\u8BC6\u70B9\uFF0C\u4E0D\u80FD\u53EA\u6709\u6807\u7B7E\uFF1B\u672A\u6307\u5B9A\u6559\u6750\u4E0D\u8865\u7AE0\u8282\u3002\u7528 v2 \u5206\u9898\u6E05\u5355\u5BFC\u5165\u5F85\u6838\u5BF9\u9898\u76EE\u3002`;
      try {
        await window.navigator.clipboard.writeText(prompt);
        new import_obsidian4.Notice("\u5DF2\u590D\u5236\u3002");
      } catch {
        const area = E2(line, "textarea");
        area.value = prompt;
        area.readOnly = true;
        area.select();
        new import_obsidian4.Notice("\u8BF7\u590D\u5236\u5DF2\u9009\u4E2D\u7684\u6307\u4EE4\u3002");
      }
    });
  }
  startCard() {
    const plan = startSteps(this.catalog);
    if (plan.complete) return;
    const card = E2(this.body, "section", null, "tz-start");
    card.setAttribute("aria-label", "\u65B0\u624B\u5F15\u5BFC");
    E2(card, "h3", "\u56DB\u6B65\u7528\u8D77\u6765");
    const list = E2(card, "ol", null, "tz-start-steps");
    const go = { website: () => this.plugin.open(), pdf: () => this.show("pdf"), review: () => this.show("questions", { status: "draft" }), basket: () => this.show("basket") };
    for (const step of plan.steps) {
      const item = E2(list, "li", null, "tz-start-step");
      item.classList.toggle("is-done", step.done);
      item.classList.toggle("is-current", step === plan.current);
      item.classList.toggle("is-locked", Boolean(step.locked) && !step.done);
      const mark = E2(item, "span", step.done ? "\u2713" : String(plan.steps.indexOf(step) + 1), "tz-start-mark");
      mark.setAttribute("aria-hidden", "true");
      const text2 = E2(item, "div", null, "tz-start-text");
      E2(text2, "strong", step.title + (step.done ? "\uFF08\u5DF2\u5B8C\u6210\uFF09" : ""));
      if (!step.done) E2(text2, "span", step.hint, "tz-muted");
      if (step === plan.current) B2(item, step.cta, go[step.action], "tz-primary");
    }
  }
  home() {
    const hero = E2(this.body, "section", null, "tz-lib-hero");
    E2(hero, "div", "\u6211\u7684\u6559\u5B66\u8D44\u4EA7", "tz-eyebrow");
    E2(hero, "h1", "\u597D\u9898\uFF0C\u90FD\u5728\u8FD9\u91CC\u3002");
    E2(hero, "p", "\u6309\u7AE0\u8282\u5907\u8BFE\uFF0C\u6309\u8003\u70B9\u627E\u9898\uFF0C\u628A\u81EA\u5DF1\u7684\u8BD5\u5377\u6162\u6162\u79EF\u7D2F\u4E0B\u6765\u3002");
    const actions = E2(hero, "div", null, "tz-actions");
    B2(actions, "\u6D4F\u89C8\u6211\u7684\u9898\u76EE", () => this.show("questions", {}), "tz-primary");
    B2(actions, "\u5BFC\u5165\u4E00\u4EFD PDF", () => this.show("pdf"));
    this.startCard();
    const stats = E2(this.body, "div", null, "tz-stats");
    for (const [title, count, fn] of [["\u5168\u90E8\u9898\u76EE", this.catalog.rows.length, () => this.show("questions", {})], ["\u5F85\u6838\u5BF9", this.catalog.rows.filter((r) => r.q.status !== "reviewed").length, () => this.show("questions", { status: "draft" })], ["\u5F85\u5206\u7C7B", this.catalog.rows.filter((r) => !r.q.knowledge_tree_ids.length && !r.q.chapter_ids.length).length, () => this.show("questions", { unclassified: true })], ["\u5DF2\u7EC4\u8BD5\u5377", this.catalog.papers.length, () => this.body.querySelector(".tz-paper-list").scrollIntoView({ block: "nearest" })]]) {
      const b = B2(stats, "", fn, "tz-stat");
      E2(b, "strong", String(count));
      E2(b, "span", title);
    }
    const columns = E2(this.body, "div", null, "tz-home-columns"), recent = E2(columns, "section", null, "tz-home-section");
    E2(recent, "h3", "\u6700\u8FD1\u4FDD\u5B58");
    for (const row of [...this.catalog.rows].sort((a, b) => String(b.q.created_at).localeCompare(String(a.q.created_at))).slice(0, 6)) {
      const b = B2(recent, "", () => this.openFile(row.path), "tz-recent-row");
      if (hasImage(row.q)) E2(b, "span", "[\u56FE]", "tz-image-label");
      E2(b, "span", cleanTitle(row.q.title, row.q.type));
      E2(b, "small", row.q.status === "reviewed" ? "\u5DF2\u6838\u5BF9" : "\u5F85\u6838\u5BF9");
    }
    if (!this.catalog.rows.length) E2(recent, "p", "\u5148\u5BFC\u5165 PDF\uFF0C\u6216\u4ECE\u7F51\u7AD9\u4FDD\u5B58\u51E0\u9053\u9898\u3002", "tz-muted");
    const activity = E2(columns, "section", null, "tz-home-section");
    E2(activity, "h3", "\u5BFC\u5165\u8FDB\u5EA6");
    for (const batch of this.catalog.imports.slice(0, 5)) this.batchRow(activity, batch);
    if (!this.catalog.imports.length) E2(activity, "p", "\u6682\u65E0\u5BFC\u5165\u4EFB\u52A1\u3002", "tz-muted");
    const papers = E2(this.body, "section", null, "tz-home-section tz-paper-list");
    E2(papers, "h3", "\u6211\u7684\u8BD5\u5377");
    for (const path of this.catalog.papers) B2(papers, this.catalog.paperTitles.get(path), () => this.openFile(path), "tz-recent-row");
    if (!this.catalog.papers.length) E2(papers, "p", "\u5148\u6838\u5BF9\u9898\u76EE\uFF0C\u518D\u544A\u8BC9 Agent\uFF1A\u201C\u6309\u672C\u7AE0\u5DF2\u6838\u5BF9\u7684\u9898\u7EC4\u4E00\u4EFD\u7EC3\u4E60\u5377\u3002\u201D", "tz-muted");
    const more = E2(this.body, "details", null, "tz-lib-resources");
    E2(more, "summary", "\u6559\u5B66\u7B14\u8BB0\u4E0E\u8D44\u6599");
    E2(more, "p", "\u539F\u4EF6\u3001\u56FE\u7247\u548C\u76EE\u5F55\u96C6\u4E2D\u653E\u5728\u300C\u8D44\u6599\u300D\uFF0C\u65E5\u5E38\u4ECE\u9898\u76EE\u8BE6\u60C5\u67E5\u770B\u5373\u53EF\u3002");
    B2(more, "\u6253\u5F00\u9898\u5E93\u9996\u9875\u7B14\u8BB0", () => this.openFile("\u9898\u5E93\u9996\u9875.md"));
    B2(more, "\u67E5\u770B\u5F85\u6574\u7406\u4EFB\u52A1", () => this.show("pdf"));
  }
  questions() {
    const bar = E2(this.body, "div", null, "tz-local-filters"), search = E2(bar, "input");
    search.type = "search";
    search.placeholder = "\u641C\u7D22\u9898\u5E72\u3001\u6807\u7B7E\u6216\u5BFC\u5165\u6587\u5B57";
    search.setAttribute("aria-label", "\u641C\u7D22\u672C\u5730\u9898\u76EE");
    search.value = this.filter.query || "";
    search.oninput = () => {
      this.filter.query = search.value;
      clearTimeout(this.searchTimer);
      this.searchTimer = setTimeout(() => {
        this.renderRows();
        this.remember();
      }, 160);
    };
    select(bar, "\u5BA1\u6838", [["", "\u5168\u90E8\u72B6\u6001"], ["draft", "\u5F85\u6838\u5BF9"], ["reviewed", "\u5DF2\u6838\u5BF9"]], this.filter.status, (value) => {
      this.filter.status = value;
      this.renderRows();
      this.remember();
    });
    select(bar, "\u9898\u578B", [["", "\u5168\u90E8\u9898\u578B"], ...[...new Set(this.catalog.rows.map((r) => r.q.type || "\u672A\u5206\u7C7B"))].map((t) => [t, t])], this.filter.type, (value) => {
      this.filter.type = value;
      this.renderRows();
      this.remember();
    });
    B2(bar, "\u91CD\u7F6E\u7B5B\u9009", () => this.show("questions", {}));
    const tools = E2(this.body, "div", null, "tz-classify-actions");
    B2(tools, "\u81EA\u52A8\u5206\u7C7B", () => new AutoClassifyModal(this).open(), "tz-secondary");
    E2(tools, "span", this.catalog.rows.filter((r) => !r.q.knowledge_tree_ids.length).length + " \u9898\u672A\u5173\u8054\u77E5\u8BC6\u70B9", "tz-muted");
    basketBar(this, this.body);
    const layout = E2(this.body, "div", null, "tz-library-layout");
    this.treeArea = E2(layout, "aside", null, "tz-tree-panel");
    select(this.treeArea, "\u5206\u7C7B\u65B9\u5F0F", [["chapter", "\u6559\u6750\u7AE0\u8282"], ["knowledge", "\u77E5\u8BC6\u70B9"], ["tags", "\u6807\u7B7E"]], this.dimension, (value) => {
      this.dimension = value;
      this.filter = { query: this.filter.query, status: this.filter.status, type: this.filter.type };
      this.drawTree();
      this.renderRows();
      this.remember();
    });
    this.tree = E2(this.treeArea, "div", null, "tz-tree");
    this.rowsArea = E2(layout, "section", null, "tz-local-results");
    this.drawTree();
    this.renderRows();
  }
  drawTree() {
    this.tree.replaceChildren();
    B2(this.tree, `\u5168\u90E8\u9898\u76EE \xB7 ${this.catalog.rows.length}`, () => this.pick({}), "tz-tree-item");
    const walk = (parent, nodes, parentId, pick) => {
      for (const n of nodes.filter((n2) => String(n2.parent_id || "") === String(parentId || ""))) {
        const count = n.count ?? n.ids?.size ?? 0;
        if (!count) continue;
        const children = nodes.some((c) => String(c.parent_id) === String(n.id) && ((c.count ?? c.ids?.size) || 0));
        if (children) {
          const detail = E2(parent, "details");
          detail.open = true;
          const summary = E2(detail, "summary");
          B2(summary, n.name + ` \xB7 ${count}`, () => pick(n), "tz-tree-item");
          walk(detail, nodes, n.id, pick);
        } else B2(parent, n.name + ` \xB7 ${count}`, () => pick(n), "tz-tree-item");
      }
    };
    if (this.dimension === "tags") walk(this.tree, this.catalog.tagTree(), "", (n) => this.pick({ tag: n.id }));
    else for (const tree of this.catalog.trees.filter((t) => t.kind === this.dimension)) {
      const rows = this.catalog.rows.filter((r) => this.catalog.treeMatch(r.q, tree));
      if (!rows.length) continue;
      const group = E2(this.tree, "details");
      group.open = true;
      E2(group, "summary", this.catalog.scopeTitle(tree), "tz-tree-scope");
      const field = tree.kind === "chapter" ? "chapter_ids" : "knowledge_tree_ids";
      const nodes = tree.nodes.map((n) => {
        const ids = this.catalog.descendants(tree, n.id);
        return { ...n, count: rows.filter((r) => r.q[field].some((id) => ids.has(String(id)))).length };
      });
      walk(group, nodes, "", (n) => this.pick({ kind: tree.kind, scope: tree.scope, node: String(n.id) }));
    }
    B2(this.tree, "\u5F85\u5206\u7C7B", () => this.pick({ unclassified: true }), "tz-tree-item");
  }
  pick(scope) {
    this.filter = { query: this.filter.query, status: this.filter.status, type: this.filter.type, ...scope };
    this.renderRows();
    this.remember();
  }
  async renderRows() {
    this.rowsArea.replaceChildren();
    const rows = this.catalog.select(this.filter);
    const title = E2(this.rowsArea, "div", null, "tz-local-summary");
    let label2 = this.filter.tag || "";
    const tree = this.catalog.trees.find((t) => t.kind === this.filter.kind && t.scope === this.filter.scope);
    if (tree) label2 = tree.nodes.find((n) => String(n.id) === this.filter.node)?.name || this.catalog.scopeTitle(tree);
    E2(title, "strong", (this.filter.unclassified ? "\u5F85\u5206\u7C7B" : label2 || "\u5168\u90E8\u9898\u76EE") + ` \xB7 ${rows.length} \u9898`);
    B2(title, "\u52FE\u9009\u5F53\u524D\u7ED3\u679C\uFF08" + Math.min(rows.length, 100) + "\uFF09", async () => {
      try {
        await this.plugin.basket.add(rows.slice(0, 100).map((r) => r.q));
        this.renderRows();
        updateBasketBar(this);
      } catch (error) {
        new import_obsidian4.Notice(error.message);
      }
    });
    {
      const pending = rows.slice(0, 100).filter((r) => r.q.status !== "reviewed");
      if (pending.length) B2(title, `\u6838\u5BF9\u672C\u9875\u663E\u793A\u7684\u5F85\u6838\u5BF9\u9898\uFF08${pending.length}\uFF09`, () => this.confirmReview(pending));
    }
    if (tree && this.filter.node) B2(title, "\u7F51\u7AD9\u8865\u9898", () => this.plugin.openFromContext({ mode: tree.kind === "chapter" ? "chapter" : "knowledge", scope: { subject_id: tree.subject_id, phase_id: tree.phase_id, ...tree.kind === "chapter" ? { edition_id: tree.edition_id, chapter_id: Number(this.filter.node) } : { knowledge_tree_id: Number(this.filter.node) } } }));
    if (!rows.length) {
      const empty = E2(this.rowsArea, "div", null, "tz-local-empty");
      if (!this.catalog.rows.length) {
        E2(empty, "strong", "\u9898\u5E93\u8FD8\u662F\u7A7A\u7684");
        E2(empty, "p", "\u5BFC\u5165\u4E00\u4EFD PDF \u8BD5\u5377\uFF0C\u6216\u4ECE\u7F51\u7AD9\u4FDD\u5B58\u51E0\u9053\u9898\uFF0C\u5C31\u80FD\u5728\u8FD9\u91CC\u6D4F\u89C8\u3001\u5206\u7C7B\u548C\u7EC4\u5377\u3002", "tz-muted");
        const a = E2(empty, "div", null, "tz-actions");
        B2(a, "\u5BFC\u5165 PDF", () => this.show("pdf"), "tz-primary");
        B2(a, "\u7F51\u7AD9\u53D6\u9898", () => this.plugin.open());
      } else {
        E2(empty, "strong", "\u5F53\u524D\u6761\u4EF6\u4E0B\u6CA1\u6709\u9898\u76EE");
        E2(empty, "p", "\u53EF\u4EE5\u653E\u5BBD\u7B5B\u9009\u3001\u6362\u4E00\u4E2A\u5206\u7C7B\uFF0C\u6216\u628A\u5F53\u524D\u5206\u7C7B\u4EA4\u7ED9\u7F51\u7AD9\u8865\u9898\u3002", "tz-muted");
        B2(empty, "\u91CD\u7F6E\u7B5B\u9009", () => this.show("questions", {}));
      }
      return;
    }
    const list = E2(this.rowsArea, "div", null, "tz-question-list");
    for (const row of rows.slice(0, 100)) {
      const { q } = row, card = E2(list, "article", null, "tz-question tz-local-card"), head = E2(card, "div", null, "tz-question-head");
      const check = E2(head, "input");
      check.type = "checkbox";
      check.checked = this.plugin.basket.has(q.id);
      check.setAttribute("aria-label", "\u52A0\u5165\u7EC4\u5377\u7BEE\uFF1A" + cleanTitle(q.title));
      card.classList.toggle("is-selected", check.checked);
      check.onchange = async () => {
        try {
          if (check.checked) await this.plugin.basket.add([q]);
          else await this.plugin.basket.remove(q.id);
          card.classList.toggle("is-selected", check.checked);
          updateBasketBar(this);
        } catch (error) {
          check.checked = this.plugin.basket.has(q.id);
          new import_obsidian4.Notice(error.message);
        }
      };
      E2(head, "span", q.type || "\u672A\u5206\u7C7B", "tz-type");
      if (typeof q.difficulty === "number") E2(head, "span", q.difficulty <= 2 ? "\u7B80\u5355" : q.difficulty >= 4 ? "\u56F0\u96BE" : "\u4E2D\u7B49", "tz-difficulty");
      E2(head, "span", q.tags.join(" \xB7 "), "tz-knowledge");
      E2(head, "span", q.status === "reviewed" ? "\u5DF2\u6838\u5BF9" : "\u5F85\u6838\u5BF9", "tz-local-status");
      const title2 = E2(card, "div", null, "tz-local-title");
      if (hasImage(q)) E2(title2, "span", "[\u56FE]", "tz-image-label");
      E2(title2, "span", cleanTitle(q.title, q.type));
      const actions = E2(card, "div", null, "tz-local-card-actions");
      const detail = E2(card, "div", null, "tz-question-details");
      detail.hidden = true;
      let rendered = false;
      B2(actions, "\u5C55\u5F00\u9898\u76EE", async (event) => {
        detail.hidden = !detail.hidden;
        event.currentTarget.textContent = detail.hidden ? "\u5C55\u5F00\u9898\u76EE" : "\u6536\u8D77";
        if (!rendered) {
          for (const [key, name2] of [["content", "\u9898\u76EE"], ["answer", "\u7B54\u6848"], ["analysis", "\u89E3\u6790"]]) {
            if (!q[key]) continue;
            const section = E2(detail, "section", null, "tz-detail-section");
            E2(section, "h4", name2);
            const content = E2(section, "div", null, "tz-preview");
            let text2 = q[key].replace(/Assets\/([a-f0-9]+\.[a-z0-9]+)/g, (_, file) => {
              const path = this.plugin.store.assetDir + "/" + file;
              const target = this.app.vault.getAbstractFileByPath(path);
              return target ? this.app.vault.getResourcePath(target) : path;
            });
            await import_obsidian4.MarkdownRenderer.render(this.app, text2, content, row.path, this);
          }
          E2(detail, "footer", q.source.label || "\u672C\u5730\u9898\u76EE", "tz-source-line");
          rendered = true;
        }
      });
      if (q.status !== "reviewed") B2(actions, "\u6807\u8BB0\u4E3A\u5DF2\u6838\u5BF9", () => this.confirmReview([row]), "tz-quiet tz-review-action");
      else E2(actions, "span", "\u5DF2\u6838\u5BF9", "tz-reviewed-badge");
      B2(actions, "\u6253\u5F00\u7B14\u8BB0", () => this.openFile(row.path));
      B2(actions, "\u5206\u7C7B / \u6807\u7B7E", () => new ClassifyModal(this.app, this.catalog, row, () => this.refresh()).open());
    }
    if (rows.length > 100) E2(this.rowsArea, "p", `\u663E\u793A\u524D 100 \u9898\uFF0C\u5171 ${rows.length} \u9898\u3002\u8BF7\u6309\u7AE0\u8282\u6216\u6807\u7B7E\u8FDB\u4E00\u6B65\u7B5B\u9009\u3002`, "tz-muted");
  }
  pdf() {
    E2(this.body, "h2", "\u628A\u8BD5\u5377\u53D8\u6210\u81EA\u5DF1\u7684\u9898\u5E93");
    E2(this.body, "p", "\u6587\u5B57\u4E0E\u516C\u5F0F\u53EF\u7F16\u8F91\uFF0C\u914D\u56FE\u5355\u72EC\u4FDD\u5B58\uFF1B\u5BFC\u5165\u540E\u5148\u6838\u5BF9\uFF0C\u518D\u7EC4\u5377\u3002", "tz-muted");
    const panel = E2(this.body, "section", null, "tz-pdf-panel");
    const file = E2(panel, "input");
    file.type = "file";
    file.accept = ".pdf,application/pdf";
    file.setAttribute("aria-label", "\u9009\u62E9 PDF \u8BD5\u5377");
    file.hidden = true;
    const chosen = E2(panel, "p", "\u652F\u6301\u6587\u5B57\u548C\u626B\u63CF PDF", "tz-muted");
    B2(panel, "\u9009\u62E9 PDF \u8BD5\u5377", () => file.click(), "tz-secondary");
    file.onchange = () => {
      chosen.textContent = file.files?.[0]?.name || "\u5C1A\u672A\u9009\u62E9\u6587\u4EF6";
    };
    const grid = E2(panel, "div", null, "tz-grid");
    const scope = { ...this.plugin.settings.lastPdfScope || this.plugin.settings.lastSelection?.scope || {} };
    delete scope.knowledge_tree_id;
    const entries2 = (dict) => [["", "\u672A\u6307\u5B9A"], ...Object.entries(dict || {})];
    let edition, chapter;
    const chapters = () => {
      chapter.replaceChildren();
      for (const [id, name2] of [["", "\u5F85\u5206\u7C7B"], ...(this.catalog.trees.find((t) => t.kind === "chapter" && String(t.subject_id) === String(scope.subject_id) && String(t.phase_id) === String(scope.phase_id) && String(t.edition_id) === String(scope.edition_id))?.nodes || []).map((n) => [String(n.id), n.name])]) {
        const o = E2(chapter, "option", name2);
        o.value = id;
      }
      chapter.value = String(scope.chapter_id || "");
    };
    const editions = () => {
      edition.replaceChildren();
      const ids = [...new Set(this.catalog.trees.filter((t) => t.kind === "chapter" && String(t.subject_id) === String(scope.subject_id) && String(t.phase_id) === String(scope.phase_id)).map((t) => String(t.edition_id)))];
      for (const [id, name2] of [["", "\u672A\u6307\u5B9A\u6559\u6750"], ...ids.map((id2) => [id2, this.catalog.names.editions?.[id2] || `\u6559\u6750${id2}`])]) {
        const o = E2(edition, "option", name2);
        o.value = id;
      }
      edition.value = String(scope.edition_id || "");
      scope.edition_id = edition.value;
      chapters();
    };
    select(grid, "\u5B66\u79D1", entries2(this.catalog.names.subjects), String(scope.subject_id || ""), (value) => {
      scope.subject_id = value;
      scope.edition_id = "";
      scope.chapter_id = "";
      editions();
    });
    select(grid, "\u5B66\u6BB5", entries2(this.catalog.names.phases), String(scope.phase_id || ""), (value) => {
      scope.phase_id = value;
      scope.edition_id = "";
      scope.chapter_id = "";
      editions();
    });
    edition = select(grid, "\u6559\u6750\u7248\u672C\uFF08\u53EF\u9009\uFF09", [], null, (value) => {
      scope.edition_id = value;
      scope.chapter_id = "";
      chapters();
    });
    chapter = select(grid, "\u7AE0\u8282\uFF08\u53EF\u9009\uFF09", [], null, (value) => {
      scope.chapter_id = value;
    });
    editions();
    const message = E2(panel, "p", null, "tz-status");
    const run = B2(panel, "\u51C6\u5907\u5BFC\u5165", async () => {
      if (this.pdfBusy) return;
      const selected = file.files?.[0];
      if (!selected) {
        message.textContent = "\u8BF7\u5148\u9009\u62E9\u4E00\u4EFD PDF\u3002";
        return;
      }
      if (selected.size > 100 * 1024 * 1024) {
        message.textContent = "\u6BCF\u4EFD PDF \u8BF7\u63A7\u5236\u5728 100 MB \u4EE5\u5185\u3002";
        return;
      }
      this.pdfBusy = true;
      run.disabled = true;
      message.textContent = "\u6B63\u5728\u672C\u5730\u5904\u7406\uFF0C\u8BF7\u7A0D\u5019\u2026\u2026";
      try {
        const bytes = await selected.arrayBuffer(), sha = await hash(bytes), name2 = selected.name.replace(/[<>:"/\\|?*]/g, "_");
        const input = "\u5F85\u6574\u7406/\u5F85\u5BFC\u5165PDF/" + sha.slice(0, 8) + "-" + name2;
        await this.plugin.store.mkdir("\u5F85\u6574\u7406/\u5F85\u5BFC\u5165PDF");
        await this.plugin.store.io.writeBinary(input, bytes);
        this.plugin.settings.lastPdfScope = scope;
        await this.plugin.saveData(this.plugin.settings);
        const args = ["--file", this.app.vault.adapter.getBasePath() + "/" + input];
        for (const [key, opt] of [["subject_id", "--subject"], ["phase_id", "--phase"], ["edition_id", "--edition"], ["chapter_id", "--chapter"]]) if (scope[key]) args.push(opt, String(scope[key]));
        let result = await this.plugin.runLocal("pdf-prepare", args);
        if (await this.plugin.store.io.exists(input)) await this.plugin.store.io.remove(input);
        message.textContent = result.status === "imported" ? `\u5DF2\u5BFC\u5165 ${result.imported} \u9898\uFF0C\u8BF7\u6838\u5BF9\u6B63\u6587\u3001\u914D\u56FE\u3001\u7B54\u6848\u548C\u5206\u7C7B\u3002` : "\u5DF2\u4FDD\u5B58\u539F\u9875\u3002\u590D\u5236\u4E0B\u65B9\u6307\u4EE4\uFF0C\u8BA9 Agent \u8FD8\u539F\u53EF\u7F16\u8F91\u6B63\u6587\u548C\u72EC\u7ACB\u914D\u56FE\u3002";
        B2(panel, "\u6253\u5F00\u5BFC\u5165\u62A5\u544A", () => this.openFile(result.report));
        if (result.status !== "imported") {
          const prompt = `\u4F7F\u7528 tizhuang-local-bank\uFF0C\u5728\u9898\u5E93\u201C${this.app.vault.adapter.getBasePath()}\u201D\u4E2D\u7EE7\u7EED PDF \u5BFC\u5165\u6279\u6B21 ${result.batch}\u3002\u67E5\u770B\u5168\u90E8\u539F\u9875\uFF0C\u5C06\u9898\u5E72\u3001\u9009\u9879\u3001\u516C\u5F0F\u548C\u8868\u683C\u8FD8\u539F\u4E3A\u53EF\u7F16\u8F91 Markdown/LaTeX\uFF0C\u5355\u72EC\u63D0\u53D6\u914D\u56FE\u3002\u53BB\u6389\u6B63\u6587\u539F\u9898\u53F7\u548C\u56FE\u7247\u4E2D\u7684\u201C\u7B2C\u51E0\u9898\u56FE\u201D\uFF0C\u539F\u7F16\u53F7\u53EA\u7559\u5728\u6765\u6E90\u8BB0\u5F55\uFF0C\u4FDD\u7559\u5C0F\u95EE\u4E0E\u56FE\u2460\u7B49\u5BF9\u5E94\u5173\u7CFB\u3002\u6838\u5BF9\u539F\u7B54\u6848\uFF0C\u6839\u636E\u8003\u67E5\u5185\u5BB9\u5173\u8054\u5230\u672C\u5730\u6807\u51C6\u77E5\u8BC6\u70B9\u6811\uFF0C\u7EFC\u5408\u9898\u53EF\u5173\u8054\u591A\u4E2A\u77E5\u8BC6\u70B9\uFF0C\u4E0D\u80FD\u53EA\u6709\u6807\u7B7E\uFF1B\u672A\u6307\u5B9A\u6559\u6750\u4E0D\u8865\u7AE0\u8282\u3002\u7528 v2 \u5206\u9898\u6E05\u5355\u5BFC\u5165\u5F85\u6838\u5BF9\u9898\u76EE\u3002`;
          const area = E2(panel, "textarea");
          area.value = prompt;
          area.readOnly = true;
          area.rows = 4;
          B2(panel, "\u590D\u5236 Agent \u6307\u4EE4", async () => {
            try {
              await window.navigator.clipboard.writeText(prompt);
              new import_obsidian4.Notice("\u5DF2\u590D\u5236\u3002");
            } catch {
              area.focus();
              area.select();
              new import_obsidian4.Notice("\u8BF7\u590D\u5236\u5DF2\u9009\u4E2D\u7684\u6307\u4EE4\u3002");
            }
          });
        }
        await this.catalog.load();
        await this.catalog.writeHome();
      } catch (error) {
        message.textContent = error.message;
      } finally {
        this.pdfBusy = false;
        run.disabled = false;
      }
    }, "tz-primary");
    E2(panel, "p", "\u63D2\u4EF6\u5728\u672C\u5730\u51C6\u5907\u539F\u9875\u548C\u6587\u5B57\u5019\u9009\uFF0C\u518D\u7531 Agent \u6838\u5BF9\u5E76\u8FD8\u539F\u9898\u76EE\u3002\u539F PDF \u4FDD\u7559\u4EE5\u4FBF\u56DE\u67E5\uFF0C\u4E0D\u4F7F\u7528\u7F51\u7AD9\u9898\u76EE\u989D\u5EA6\uFF1B\u6A21\u578B\u662F\u5426\u5728\u672C\u5730\u8FD0\u884C\u53D6\u51B3\u4E8E\u6240\u7528 Agent\u3002", "tz-pdf-note");
    const history = E2(this.body, "section", null, "tz-home-section");
    E2(history, "h3", "\u6700\u8FD1\u7684 PDF \u5BFC\u5165");
    for (const batch of this.catalog.imports.slice(0, 10)) this.batchRow(history, batch);
  }
};

// src/local-runner.js
var helperPath = (plugin, base, name2) => base + "/" + (plugin.manifest.dir || `${plugin.app.vault.configDir || ".obsidian"}/plugins/${plugin.manifest.id}`) + "/helper/" + name2;
function runLocal(plugin, command, args = []) {
  if (!["organize", "dashboard", "pdf-prepare", "pdf-import", "paper", "auto-classify", "classify", "repair-papers", "review"].includes(command)) throw Error("\u4E0D\u652F\u6301\u7684\u672C\u5730\u64CD\u4F5C");
  if (plugin.localTaskActive || plugin.store.busy) throw Error("\u6B63\u5728\u5199\u5165\u9898\u5E93\uFF0C\u8BF7\u7B49\u5F85\u5F53\u524D\u64CD\u4F5C\u5B8C\u6210\u3002");
  const base = plugin.app.vault.adapter.getBasePath?.();
  if (!base) throw Error("\u672C\u5730\u5BFC\u5165\u548C\u7EC4\u5377\u9700\u8981\u7535\u8111\u4E0A\u7684\u672C\u5730\u4ED3\u5E93\u3002");
  const executable = plugin.settings.pythonPath?.trim() || "python";
  const helper = helperPath(plugin, base, "local_bank.py");
  plugin.localTaskActive = true;
  return new Promise((resolve, reject) => {
    const { execFile } = require("child_process");
    const attempt = (file, prefix, fallback) => execFile(file, [...prefix, helper, "--vault", base, command, ...args], { windowsHide: true, timeout: 12e4, maxBuffer: 2 * 1024 * 1024, encoding: "utf8" }, (error, stdout, stderr) => {
      if (error?.code === "ENOENT" && fallback) return attempt(...fallback);
      plugin.localTaskActive = false;
      let data;
      try {
        data = JSON.parse(stdout);
      } catch {
      }
      if (data?.kind === "missing_dependency") return reject(Error(explainFailure(null, "ModuleNotFoundError " + data.error)));
      if (data?.ok === false) return reject(Error(data.error + (data.hint ? "\uFF08" + data.hint + "\uFF09" : "")));
      if (error) return reject(Error(explainFailure(error, stderr)));
      if (!data?.ok) return reject(Error("\u672C\u5730\u5DE5\u5177\u6CA1\u6709\u8FD4\u56DE\u6709\u6548\u7ED3\u679C\u3002"));
      resolve(data.result);
    });
    const chosen = plugin.settings.pythonPath?.trim();
    attempt(executable, [], !chosen && process.platform === "win32" ? ["py", ["-3"], null] : null);
  });
}
function explainFailure(error, stderr = "") {
  const text2 = String(stderr || error?.message || "");
  if (error?.code === "ENOENT") return "\u672A\u627E\u5230 Python\u3002\u8BF7\u5B89\u88C5 Python 3.10 \u6216\u66F4\u65B0\u7248\u672C\uFF0C\u5E76\u5728\u63D2\u4EF6\u8BBE\u7F6E\u91CC\u586B\u5199\u5B83\u7684\u8DEF\u5F84\uFF08\u9700\u5DF2\u5B89\u88C5\u672C\u5730\u9898\u5E93\u4F9D\u8D56\uFF09\u3002";
  if (error?.killed) return "\u5904\u7406\u8D85\u8FC7 120 \u79D2\uFF0C\u5DF2\u505C\u6B62\uFF1B\u518D\u6B21\u6267\u884C\u53EF\u7EE7\u7EED\u539F PDF \u6279\u6B21\u6216\u6062\u590D\u5DF2\u751F\u6210\u8BD5\u5377\u3002";
  if (/ModuleNotFoundError|ImportError|No module named/.test(text2)) return '\u8FD9\u4E2A Python \u7F3A\u5C11\u9898\u5E93\u4F9D\u8D56\u3002\u8BF7\u5728\u7EC8\u7AEF\u8FD0\u884C\uFF1Apython -m pip install -r "<\u63D2\u4EF6\u76EE\u5F55>/helper/requirements.txt"\uFF0C\u6216\u8BA9 Agent \u8FD0\u884C\u672C\u5730\u9898\u5E93\u7684\u73AF\u5883\u68C0\u67E5\u3002';
  if (/SyntaxError/.test(text2)) return "Python \u7248\u672C\u8FC7\u4F4E\uFF0C\u9700\u8981 3.10 \u6216\u66F4\u65B0\u7248\u672C\u3002";
  return "\u672C\u5730\u5904\u7406\u672A\u5B8C\u6210\u3002\u8BF7\u68C0\u67E5 Python \u73AF\u5883\u548C\u4F9D\u8D56\uFF1A" + text2.slice(-600);
}
function pythonCandidates(configured, platform = process.platform) {
  if (configured?.trim()) return [{ label: configured.trim(), file: configured.trim(), prefix: [] }];
  return platform === "win32" ? [{ label: "python", file: "python", prefix: [] }, { label: "py -3", file: "py", prefix: ["-3"] }] : [{ label: "python3", file: "python3", prefix: [] }, { label: "python", file: "python", prefix: [] }];
}
async function checkEnvironment(plugin, exec) {
  const base = plugin.app.vault.adapter.getBasePath?.();
  if (!base) return { ok: false, tried: [], summary: "\u9700\u8981\u7535\u8111\u4E0A\u7684\u672C\u5730\u4ED3\u5E93\u624D\u80FD\u68C0\u67E5\u73AF\u5883\u3002" };
  const run = exec || ((file, args) => new Promise((resolve) => require("child_process").execFile(file, args, { windowsHide: true, timeout: 3e4, maxBuffer: 1024 * 1024, encoding: "utf8" }, (error, stdout, stderr) => resolve({ error, stdout, stderr }))));
  const script = helperPath(plugin, base, "doctor.py"), tried = [];
  for (const c of pythonCandidates(plugin.settings.pythonPath)) {
    const { error, stdout, stderr } = await run(c.file, [...c.prefix, script, "--vault", base]);
    let data = null;
    try {
      data = JSON.parse(stdout);
    } catch {
    }
    if (!data) {
      const state = error?.code === "ENOENT" ? "missing" : error?.killed || error?.signal || error?.code === "ETIMEDOUT" ? "timeout" : "broken";
      tried.push({ label: c.label, state, found: state !== "missing", ok: false, checks: [], fix: "", detail: String(stderr || error?.message || "").trim().slice(-300) });
      continue;
    }
    const failed = (data.checks || []).filter((x) => !x.ok);
    tried.push({ label: c.label, state: data.ok ? "ok" : "problem", found: true, ok: Boolean(data.ok), python: data.python, checks: data.checks || [], fix: failed.map((x) => x.fix).filter(Boolean).join("\n"), status: data.status?.result || null });
    if (data.ok) break;
  }
  const good = tried.find((t) => t.ok), seen = tried.find((t) => t.state === "problem");
  return { ok: Boolean(good), python: good?.python || seen?.python || null, tried, fix: good ? "" : seen?.fix || "", summary: describeEnvironment(tried) };
}
function describeEnvironment(tried) {
  const good = tried.find((t) => t.ok);
  if (good) return `\u73AF\u5883\u6B63\u5E38\uFF1APython \u4E0E\u9898\u5E93\u4F9D\u8D56\u90FD\u5DF2\u5C31\u7EEA\uFF08${good.python}\uFF09\u3002`;
  const seen = tried.find((t) => t.state === "problem");
  if (seen) {
    const bad = seen.checks.filter((c) => !c.ok).map((c) => `${c.name}\uFF1A${c.detail || "\u672A\u901A\u8FC7"}`);
    return `\u627E\u5230\u4E86 Python\uFF08${seen.python}\uFF09\uFF0C\u4F46\u8FD8\u6709\u95EE\u9898\uFF1A${bad.join("\uFF1B")}\u3002`;
  }
  const slow = tried.find((t) => t.state === "timeout");
  if (slow) return `Python\uFF08${slow.label}\uFF09\u5DF2\u5B89\u88C5\uFF0C\u4F46\u68C0\u67E5\u8D85\u8FC7 30 \u79D2\u6CA1\u6709\u54CD\u5E94\uFF0C\u53EF\u80FD\u662F\u6740\u6BD2\u8F6F\u4EF6\u5728\u626B\u63CF\u6216\u9898\u5E93\u76EE\u5F55\u5728\u7F51\u76D8\u540C\u6B65\u3002\u8BF7\u7A0D\u7B49\u4E00\u4F1A\u513F\u518D\u70B9\u201C\u68C0\u67E5\u73AF\u5883\u201D\uFF0C\u4E0D\u9700\u8981\u91CD\u65B0\u5B89\u88C5 Python\u3002`;
  const broken = tried.find((t) => t.state === "broken");
  if (broken) return `Python\uFF08${broken.label}\uFF09\u5DF2\u5B89\u88C5\uFF0C\u4F46\u68C0\u67E5\u811A\u672C\u6CA1\u6709\u6B63\u5E38\u8FD0\u884C${broken.detail ? "\uFF1A" + broken.detail : ""}\u3002\u8BF7\u786E\u8BA4\u63D2\u4EF6\u6587\u4EF6\u5B8C\u6574\uFF08\u53EF\u91CD\u65B0\u5B89\u88C5\u63D2\u4EF6\uFF09\uFF0C\u4E0D\u9700\u8981\u91CD\u88C5 Python\u3002`;
  return "\u6CA1\u6709\u627E\u5230 Python\u3002\u8BF7\u5B89\u88C5 Python 3.10 \u6216\u66F4\u65B0\u7248\u672C\uFF08\u5B89\u88C5\u65F6\u52FE\u9009\u201CAdd to PATH\u201D\uFF09\uFF0C\u518D\u56DE\u6765\u68C0\u67E5\uFF1B\u6216\u5728\u4E0A\u65B9\u586B\u5199 Python \u7684\u5B8C\u6574\u8DEF\u5F84\u3002";
}

// src/main.js
var VIEW = "tizhuang-teacher-bank";
var td = new TurndownService({ headingStyle: "atx", codeBlockStyle: "fenced" });
td.keep(["table", "math", "sup", "sub"]);
var markdown = (value) => {
  const math = [];
  const prefix = "TZMATH" + crypto.randomUUID().replaceAll("-", "") + "TOKEN";
  const safe = purify_default.sanitize(String(value), { USE_PROFILES: { html: true, mathMl: true }, FORBID_TAGS: ["script", "style", "iframe", "object", "embed", "form", "input", "button"], FORBID_ATTR: ["style", "srcset"] });
  const shielded = safe.replace(/\$\$[\s\S]*?\$\$|\$(?:\\.|[^$])*?\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/g, (source) => {
    if (source.includes("<")) return source;
    const decoder = document.createElement("textarea");
    decoder.innerHTML = source;
    let text2 = decoder.value;
    if (text2.startsWith("\\(")) text2 = "$" + text2.slice(2, -2) + "$";
    if (text2.startsWith("\\[")) text2 = "$$" + text2.slice(2, -2) + "$$";
    const token = prefix + math.length + "END";
    math.push({ token, text: text2 });
    return token;
  });
  let result = td.turndown(shielded);
  for (const { token, text: text2 } of math) result = result.replaceAll(token, text2);
  return result;
};
var node = (parent, tag, text2, cls) => {
  const e = document.createElement(tag);
  if (text2 != null) e.textContent = text2;
  if (cls) e.className = cls;
  parent.append(e);
  return e;
};
var button = (parent, text2, run, kind = "secondary") => {
  const b = node(parent, "button", text2, "tz-" + kind + (kind === "primary" ? " mod-cta" : ""));
  b.type = "button";
  b.addEventListener("click", run);
  return b;
};
var label = (parent, text2) => node(parent, "label", text2, "tz-label");
var iconButton = (parent, title, run, icon) => {
  const b = button(parent, "", run, "quiet");
  b.classList.add("tz-icon-button");
  b.title = title;
  b.setAttribute("aria-label", title);
  const svg2 = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg2.setAttribute("viewBox", "0 0 24 24");
  svg2.setAttribute("aria-hidden", "true");
  const path = document.createElementNS(svg2.namespaceURI, "path");
  path.setAttribute("d", icon);
  svg2.append(path);
  b.append(svg2);
  return b;
};
var icons = { website: "M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0M3 12h18M12 3c5 5 5 13 0 18-5-5-5-13 0-18", key: "M7 10a5 5 0 1 0 0 10 5 5 0 0 0 0-10M10.5 11.5 21 1M18 4l3 3M15 7l3 3", refresh: "M20 7v5h-5M4 17v-5h5M6 6a8 8 0 0 1 13 3M5 15a8 8 0 0 0 13 3", node: "M4 4h16v16H4zM8 9h8M8 13h5", clear: "M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v5m4-5v5", open: "M14 4h6v6M20 4 10 14M10 4H4v16h16v-6" };
var SpendModal = class extends import_obsidian5.Modal {
  constructor(app, summary, resolve) {
    super(app);
    this.summary = summary;
    this.resolve = resolve;
    this.accepted = false;
  }
  onOpen() {
    node(this.contentEl, "h2", "\u786E\u8BA4\u83B7\u53D6\u9898\u76EE");
    node(this.contentEl, "p", this.summary);
    node(this.contentEl, "p", "\u6309\u7F51\u7AD9\u5B9E\u9645\u8FD4\u56DE\u7684\u9898\u6570\u6263\u51CF\u4ECA\u65E5\u989D\u5EA6\u3002\u518D\u6B21\u83B7\u53D6\u4E5F\u4F1A\u6263\u989D\uFF0C\u672C\u5730\u91CD\u590D\u9898\u4E0D\u4F1A\u9000\u989D\u3002");
    const actions = node(this.contentEl, "div", null, "tz-actions");
    button(actions, "\u53D6\u6D88", () => this.close());
    button(actions, "\u786E\u8BA4\u83B7\u53D6\u5E76\u6263\u51CF\u989D\u5EA6", () => {
      this.accepted = true;
      this.close();
    }, "primary");
  }
  onClose() {
    this.resolve(this.accepted);
    this.contentEl.replaceChildren();
  }
};
var CredentialsTab = class extends import_obsidian5.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.replaceChildren();
    node(containerEl, "h2", "\u9898\u5E84\u672C\u5730\u9898\u5E93\u8BBE\u7F6E");
    node(containerEl, "p", "\u4F7F\u7528\u81EA\u5DF1\u7684\u9898\u5E84 API Key\uFF0C\u9898\u76EE\u4ECE\u81EA\u5DF1\u7684\u4ECA\u65E5\u989D\u5EA6\u6263\u51CF\u3002\u8BF7\u5728\u6B64\u8F93\u5165\uFF0C\u4E0D\u8981\u53D1\u9001\u5230\u804A\u5929\u4E2D\u3002");
    let value = "";
    new import_obsidian5.Setting(containerEl).setName("\u9898\u5E84 API Key").setDesc("\u8F93\u5165\u540E\u70B9\u51FB\u4E0B\u65B9\u4FDD\u5B58\u3002\u672C\u5730\u9898\u5E93 skill \u548C\u73B0\u6709\u53D6\u9898 skill \u7684\u51ED\u8BC1\u4E0D\u4F1A\u81EA\u52A8\u8BFB\u53D6\u3002").addText((t) => {
      t.inputEl.type = "password";
      t.inputEl.autocomplete = "off";
      t.setPlaceholder("\u8F93\u5165\u81EA\u5DF1\u7684 API Key").onChange((v) => {
        value = v;
      });
    });
    let persist = Boolean(this.app.secretStorage);
    new import_obsidian5.Setting(containerEl).setName("\u4FDD\u5B58\u5230 Obsidian \u5BC6\u94A5\u5B58\u50A8").setDesc(this.app.secretStorage ? "\u53EA\u4FDD\u5B58\u5BC6\u94A5\u5F15\u7528\u5230\u63D2\u4EF6\u914D\u7F6E\uFF0C\u4E0D\u628A API Key \u5199\u5165\u7B14\u8BB0\u6216\u63D2\u4EF6\u914D\u7F6E\u3002" : "\u5F53\u524D Obsidian \u7248\u672C\u4E0D\u652F\u6301\u5BC6\u94A5\u5B58\u50A8\uFF0C\u4EC5\u5728\u672C\u6B21\u5E94\u7528\u8FD0\u884C\u671F\u95F4\u4F7F\u7528\u3002").addToggle((t) => t.setValue(persist).setDisabled(!this.app.secretStorage).onChange((v) => {
      persist = v;
    }));
    new import_obsidian5.Setting(containerEl).setName("\u5E94\u7528\u51ED\u8BC1").addButton((b) => b.setButtonText("\u4FDD\u5B58\u51ED\u8BC1").setCta().onClick(async () => {
      if (!value.trim()) {
        new import_obsidian5.Notice("\u8BF7\u586B\u5199\u81EA\u5DF1\u7684 API Key\u3002");
        return;
      }
      try {
        await this.plugin.setKey(value.trim(), persist);
        value = "";
        this.display();
        new import_obsidian5.Notice("\u51ED\u8BC1\u5DF2\u5E94\u7528\uFF0C\u53EF\u56DE\u9898\u5E93\u9762\u677F\u5237\u65B0\u989D\u5EA6\u3002");
      } catch {
        new import_obsidian5.Notice("\u51ED\u8BC1\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002");
      }
    })).addButton((b) => b.setButtonText("\u6E05\u9664\u51ED\u8BC1").onClick(async () => {
      await this.plugin.clearKey();
      this.display();
      new import_obsidian5.Notice("\u5DF2\u6E05\u9664\u672C\u63D2\u4EF6\u4F7F\u7528\u7684\u51ED\u8BC1\u3002");
    }));
    node(containerEl, "p", this.plugin.getKey() ? "\u5F53\u524D\u72B6\u6001\uFF1A\u5DF2\u914D\u7F6E\u81EA\u5DF1\u7684\u51ED\u8BC1\u3002" : "\u5F53\u524D\u72B6\u6001\uFF1A\u5C1A\u672A\u914D\u7F6E\u51ED\u8BC1\u3002");
    node(containerEl, "p", `\u670D\u52A1\u5730\u5740\uFF1A${BASE}\u3002\u83B7\u53D6\u6559\u6750\u76EE\u5F55\u548C\u5237\u65B0\u989D\u5EA6\u4E0D\u6263\u9898\u76EE\u989D\u5EA6\uFF1B\u83B7\u53D6\u9898\u76EE\u4F1A\u6263\u989D\u3002`);
    new import_obsidian5.Setting(containerEl).setName("PDF \u5BFC\u5165\u4F7F\u7528\u7684 Python").setDesc("\u586B\u5199\u5DF2\u5B89\u88C5\u672C\u5730\u9898\u5E93\u4F9D\u8D56\u7684 Python \u7A0B\u5E8F\u8DEF\u5F84\uFF1B\u7559\u7A7A\u5219\u81EA\u52A8\u5C1D\u8BD5\u7CFB\u7EDF Python\u3002\u4E0D\u786E\u5B9A\u65F6\u70B9\u4E0B\u65B9\u201C\u68C0\u67E5\u73AF\u5883\u201D\u3002\u4EC5 PDF \u548C\u76EE\u5F55\u6574\u7406\u9700\u8981\u3002").addText((t) => {
      t.setPlaceholder("\u4F8B\u5982 C:\\Python312\\python.exe");
      t.inputEl.value = this.plugin.settings.pythonPath || "";
      t.onChange(async (value2) => {
        this.plugin.settings.pythonPath = value2.trim();
        await this.plugin.saveData(this.plugin.settings);
      });
    });
    const env = node(containerEl, "div", null, "tz-env-check");
    const result = node(env, "p", null, "tz-status");
    result.setAttribute("role", "status");
    const fix = node(env, "pre", null, "tz-env-fix");
    fix.hidden = true;
    const actions = node(env, "div", null, "tz-actions");
    const check = button(actions, "\u68C0\u67E5\u73AF\u5883", async () => {
      check.disabled = true;
      result.textContent = "\u6B63\u5728\u68C0\u67E5\u2026\u2026";
      result.classList.remove("tz-error");
      fix.hidden = true;
      use.hidden = true;
      copy.hidden = true;
      try {
        const r = await checkEnvironment(this.plugin);
        result.textContent = r.summary;
        result.classList.toggle("tz-error", !r.ok);
        if (r.ok && !this.plugin.settings.pythonPath?.trim() && r.python) {
          use.hidden = false;
          use.onclick = async () => {
            this.plugin.settings.pythonPath = r.python;
            await this.plugin.saveData(this.plugin.settings);
            new import_obsidian5.Notice("\u5DF2\u4FDD\u5B58\u8FD9\u4E2A Python\u3002");
            this.display();
          };
        }
        if (!r.ok && r.fix) {
          fix.hidden = false;
          fix.textContent = r.fix;
          copy.hidden = false;
          copy.onclick = async () => {
            try {
              await navigator.clipboard.writeText(r.fix);
              new import_obsidian5.Notice("\u4FEE\u590D\u547D\u4EE4\u5DF2\u590D\u5236\uFF0C\u7C98\u8D34\u5230\u7EC8\u7AEF\u6267\u884C\u540E\u518D\u70B9\u201C\u68C0\u67E5\u73AF\u5883\u201D\u3002");
            } catch {
              new import_obsidian5.Notice("\u590D\u5236\u5931\u8D25\uFF0C\u8BF7\u624B\u52A8\u9009\u4E2D\u4E0A\u65B9\u547D\u4EE4\u3002");
            }
          };
        }
      } catch (error) {
        result.textContent = "\u68C0\u67E5\u6CA1\u6709\u5B8C\u6210\uFF1A" + (error.message || error);
        result.classList.add("tz-error");
      } finally {
        check.disabled = false;
      }
    }, "secondary");
    const use = button(actions, "\u4F7F\u7528\u8FD9\u4E2A Python", () => {
    }, "quiet");
    use.hidden = true;
    const copy = button(actions, "\u590D\u5236\u4FEE\u590D\u547D\u4EE4", () => {
    }, "quiet");
    copy.hidden = true;
  }
};
var BankView = class extends import_obsidian5.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.scope = {};
    this.mode = "chapter";
    this.sourcePath = "";
    this.nodes = [];
    this.knowledgeNodes = [];
    this.meta = {};
    this.batch = null;
    this.lock = false;
    this.loading = false;
    this.epoch = 0;
    this.queuedContext = null;
    this.closed = false;
    this.chapterOptions = /* @__PURE__ */ new Map();
    this.expandedQuestions = /* @__PURE__ */ new Set();
  }
  getViewType() {
    return VIEW;
  }
  getDisplayText() {
    return "\u9898\u5E84\u672C\u5730\u9898\u5E93";
  }
  getIcon() {
    return "library";
  }
  async onOpen() {
    this.draw();
    await this.loadInitial();
    await this.run(async () => {
      if (await this.plugin.store.io.exists(".bank/pending/questions.json")) {
        const data = JSON.parse(await this.plugin.store.io.read(".bank/pending/questions.json"));
        if (!["tizhuang.pending/v1", "tizhuang.pending/v2"].includes(data.schema) || !Array.isArray(data.batch?.items) || data.batch.items.length > 20) throw Error("\u4E0A\u6B21\u53D6\u9898\u7F13\u5B58\u683C\u5F0F\u65E0\u6548\uFF0C\u8BF7\u5148\u68C0\u67E5\u7F13\u5B58\u6587\u4EF6\u3002");
        const directory = directoryNodes(data.batch.scope, data.batch.nodes);
        validateKnowledge(directory.knowledge);
        validateChapters(directory.chapters, data.batch.scope);
        requireScope(data.batch.scope, directory);
        this.batch = data.batch;
        await this.renderBatch();
        if (data.batch.items.some((i) => !i.saved)) this.say("\u5DF2\u6062\u590D\u4E0A\u6B21\u53D6\u9898\u7ED3\u679C\uFF0C\u53EF\u4EE5\u7EE7\u7EED\u4FDD\u5B58\uFF0C\u65E0\u9700\u518D\u6B21\u6263\u989D\u3002");
      }
    });
  }
  async onClose() {
    this.closed = true;
    this.epoch++;
  }
  select(parent, name2, key, change) {
    const field = node(parent, "div", null, "tz-select-field");
    label(field, name2);
    const el = node(field, "select");
    el.setAttribute("aria-label", name2);
    this.inputs[key] = el;
    this.options(key, [], "\u8BF7\u5148\u52A0\u8F7D");
    el.addEventListener("change", async () => {
      if (this.lock) return;
      this.scope[key] = el.value ? Number(el.value) : null;
      this.sourcePath = "";
      if (key === "chapter_id" || key === "knowledge_tree_id") {
        this.mode = key === "chapter_id" ? "chapter" : "knowledge";
        const other = key === "chapter_id" ? "knowledge_tree_id" : "chapter_id";
        if (el.value && this.scope[other]) {
          this.scope[other] = null;
          this.inputs[other].value = "";
          this.say(key === "chapter_id" ? "\u5DF2\u9009\u7AE0\u8282\uFF0C\u77E5\u8BC6\u70B9\u7B5B\u9009\u5DF2\u6E05\u7A7A\u3002" : "\u5DF2\u9009\u77E5\u8BC6\u70B9\uFF0C\u7AE0\u8282\u7B5B\u9009\u5DF2\u6E05\u7A7A\u3002");
        }
      }
      try {
        await change();
        this.updateContext();
        await this.remember();
      } catch (error) {
        this.say(error.message || "\u5207\u6362\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002", true);
      }
    });
    return el;
  }
  options(key, values, placeholder = "\u8BF7\u9009\u62E9") {
    const el = this.inputs[key], fragment = document.createDocumentFragment();
    const first = node(fragment, "option", placeholder);
    first.value = "";
    for (const v of values) {
      const o = node(fragment, "option", v.name);
      o.value = String(v.id);
    }
    el.replaceChildren(fragment);
    el.value = this.scope[key] ? String(this.scope[key]) : "";
    el.disabled = this.lock || !values.length;
  }
  reset(keys) {
    for (const k of keys) {
      this.scope[k] = null;
      this.options(k, [], "\u8BF7\u5148\u9009\u62E9\u4E0A\u7EA7");
    }
    if (keys.includes("knowledge_tree_id")) this.knowledgeNodes = [];
    if (keys.includes("chapter_id")) {
      this.nodes = [];
      this.chapterOptions.clear();
    }
    this.epoch++;
    this.loading = false;
    if (this.loadNotice) this.loadNotice.hidden = true;
    this.contentEl.setAttribute("aria-busy", "false");
    this.setDisabled(this.lock);
  }
  async run(task) {
    if (this.lock) return;
    this.lock = true;
    this.setDisabled(true);
    try {
      await task();
    } catch (e) {
      this.say(e.message || "\u64CD\u4F5C\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002", true);
    } finally {
      this.lock = false;
      this.setDisabled(false);
      this.updateContext();
      try {
        await this.remember();
      } catch {
        this.say("\u9009\u62E9\u8BB0\u5FC6\u4FDD\u5B58\u5931\u8D25\uFF0C\u5F53\u524D\u64CD\u4F5C\u4ECD\u53EF\u7EE7\u7EED\u3002", true);
      }
      if (this.queuedContext) {
        const next2 = this.queuedContext;
        this.queuedContext = null;
        await this.applyContext(next2);
      }
    }
  }
  setDisabled(value) {
    for (const el of this.contentEl.querySelectorAll("button,select,input")) el.disabled = value || el.dataset.saved === "true" || el.tagName === "SELECT" && el.options.length <= 1;
    if (this.fetchButton) this.fetchButton.disabled = value || this.loading;
    if (this.quotaButton) this.quotaButton.disabled = value || Boolean(this.quotaBusy);
    this.updateSelection(value);
  }
  async load(task) {
    if (this.lock) return;
    const seq2 = ++this.epoch;
    this.loading = true;
    this.loadNotice.hidden = false;
    this.contentEl.setAttribute("aria-busy", "true");
    this.setDisabled(false);
    try {
      await task();
    } catch (error) {
      if (seq2 === this.epoch && !this.closed) this.say(error.message || "\u76EE\u5F55\u52A0\u8F7D\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002", true);
    } finally {
      if (seq2 === this.epoch && !this.closed) {
        this.loading = false;
        this.loadNotice.hidden = true;
        this.contentEl.setAttribute("aria-busy", "false");
        this.setDisabled(this.lock);
        this.updateContext();
        try {
          await this.remember();
        } catch {
          this.say("\u9009\u62E9\u8BB0\u5FC6\u4FDD\u5B58\u5931\u8D25\uFF0C\u5F53\u524D\u64CD\u4F5C\u4ECD\u53EF\u7EE7\u7EED\u3002", true);
        }
      }
    }
  }
  showQuota(remaining, used) {
    this.quota.textContent = typeof remaining === "number" ? `\u5269\u4F59 ${remaining} \u9898` : "\u989D\u5EA6\u5F85\u67E5\u8BE2";
    this.quota.title = typeof remaining === "number" ? `\u4ECA\u65E5\u5269\u4F59\u9898\u76EE\u989D\u5EA6\uFF1A${remaining} \u9898${typeof used === "number" ? ` \xB7 \u4ECA\u65E5\u5DF2\u7528 ${used} \u9898` : ""}` : "\u5237\u65B0\u67E5\u770B\u4ECA\u65E5\u9898\u76EE\u989D\u5EA6";
    this.quota.setAttribute("aria-label", this.quota.title);
  }
  async refreshQuota() {
    if (this.quotaBusy) return;
    this.quotaBusy = true;
    this.quotaButton.disabled = true;
    try {
      const q = await this.plugin.api.quota();
      this.showQuota(q.remaining, q.used);
      this.say("\u989D\u5EA6\u5DF2\u5237\u65B0\u3002");
    } catch (error) {
      this.say(error.message, true);
    } finally {
      this.quotaBusy = false;
      this.quotaButton.disabled = this.lock;
    }
  }
  say(text2, error = false) {
    this.status.textContent = text2;
    this.status.classList.toggle("tz-error", error);
  }
  normalizeChoice() {
    if (this.scope.chapter_id && this.scope.knowledge_tree_id) this.scope[this.mode === "knowledge" ? "chapter_id" : "knowledge_tree_id"] = null;
  }
  directory() {
    return { chapters: this.nodes, knowledge: this.knowledgeNodes };
  }
  scopeText() {
    const value = (rows, id) => rows?.find((v) => String(v.id) === String(id))?.name;
    return [value(this.meta.phases, this.scope.phase_id), value(this.meta.subjects, this.scope.subject_id), value(this.meta.editions, this.scope.edition_id), value(this.meta.grades, this.scope.grade_id), value(this.nodes, this.scope.chapter_id) || "\u4E0D\u9650\u7AE0\u8282", value(this.knowledgeNodes, this.scope.knowledge_tree_id) || "\u4E0D\u9650\u77E5\u8BC6\u70B9"].filter(Boolean).join(" \xB7 ");
  }
  updateContext() {
    if (!this.contextLabel) return;
    const subject = this.meta.subjects?.find((v) => String(v.id) === String(this.scope.subject_id))?.name || "", phase = this.meta.phases?.find((v) => String(v.id) === String(this.scope.phase_id))?.name || "";
    const chapter = this.nodes.find((v) => String(v.id) === String(this.scope.chapter_id)), knowledge = this.knowledgeNodes.find((v) => String(v.id) === String(this.scope.knowledge_tree_id));
    const edition = this.meta.editions?.find((v) => String(v.id) === String(this.scope.edition_id))?.name;
    this.contextMeta.textContent = [phase, subject, edition].filter(Boolean).join(" \xB7 ") || "\u5F53\u524D\u53D6\u9898\u8303\u56F4";
    this.contextLabel.textContent = [chapter?.name, knowledge?.name].filter(Boolean).join(" \xB7 ") || "\u4E0D\u9650\u7AE0\u8282 \xB7 \u4E0D\u9650\u77E5\u8BC6\u70B9";
    this.contextHint.textContent = !chapter && !knowledge ? ["\u8986\u76D6\u5F53\u524D\u5B66\u6BB5\u77E5\u8BC6\u6811", !this.scope.edition_id ? "\u672A\u9650\u5B9A\u6559\u6750" : "", this.meta.grades?.find((v) => String(v.id) === String(this.scope.grade_id))?.name].filter(Boolean).join(" \xB7 ") : !this.scope.edition_id ? "\u672A\u9650\u5B9A\u6559\u6750 \xB7 \u53EF\u5C55\u5F00\u7B5B\u9009\uFF0C\u6216\u6253\u5F00\u5DE6\u4FA7\u76EE\u5F55\u9009\u62E9\u8282\u70B9" : this.meta.grades?.find((v) => String(v.id) === String(this.scope.grade_id))?.name || "\u53EF\u5C55\u5F00\u7B5B\u9009\uFF0C\u6216\u6253\u5F00\u5DE6\u4FA7\u76EE\u5F55\u9009\u62E9\u8282\u70B9";
    this.contextLabel.title = "\u6253\u5F00\u5DE6\u4FA7\u76EE\u5F55\u5E76\u5B9A\u4F4D\u8282\u70B9";
    this.chapterRoute.textContent = chapter ? "\u5B9A\u4F4D\u7AE0\u8282" : "\u7AE0\u8282\u76EE\u5F55";
    this.knowledgeRoute.textContent = knowledge ? "\u5B9A\u4F4D\u77E5\u8BC6\u70B9" : "\u77E5\u8BC6\u70B9\u76EE\u5F55";
  }
  async remember() {
    if (!this.scope.subject_id || !this.scope.phase_id) return;
    await this.plugin.saveSelection({ mode: this.mode, scope: { ...this.scope }, sourcePath: this.sourcePath, count: Number(this.count.value), solutions: this.solutions.checked, advancedOpen: this.advanced.open });
  }
  async applyContext(context) {
    if (this.lock) {
      this.queuedContext = context;
      return;
    }
    await this.load(async () => {
      const seq2 = this.epoch;
      this.nodes = [];
      this.knowledgeNodes = [];
      this.chapterOptions.clear();
      this.mode = context.mode;
      this.scope = { ...context.scope };
      this.normalizeChoice();
      this.sourcePath = context.path || "";
      if (!this.meta.subjects?.length) await this.loadInitial(true, false);
      if (seq2 !== this.epoch) return;
      this.scope = { ...context.scope };
      this.normalizeChoice();
      this.options("subject_id", this.meta.subjects);
      this.options("phase_id", this.meta.phases);
      if (!this.inputs.subject_id.value || !this.inputs.phase_id.value) throw Error("\u5F53\u524D\u7B14\u8BB0\u7684\u5B66\u79D1\u5B66\u6BB5\u4E0D\u5728\u7F51\u7AD9\u76EE\u5F55\u4E2D\uFF0C\u8BF7\u68C0\u67E5\u8282\u70B9\u5C5E\u6027\u3002");
      await this.loadScoped(true);
      if (seq2 !== this.epoch) return;
      if (this.scope.edition_id) await this.loadChapters(true);
      if (seq2 !== this.epoch) return;
      requireScope(this.scope, this.directory());
      this.advanced.open = false;
      this.updateContext();
      this.say("\u5DF2\u5E26\u5165\u5DE6\u4FA7\u8282\u70B9\uFF0C\u53EF\u4EE5\u76F4\u63A5\u83B7\u53D6\u9898\u76EE\u3002");
    });
  }
  draw() {
    const root2 = this.contentEl;
    root2.replaceChildren();
    root2.classList.add("tz-bank");
    this.inputs = {};
    const shell = node(root2, "div", null, "tz-shell");
    const header = node(shell, "header", null, "tz-header");
    renderBrand(header);
    const actions = node(header, "div", null, "tz-header-actions");
    const website = iconButton(actions, "\u6253\u5F00\u9898\u5E84\u5B98\u7F51", () => window.open("https://tizhuang.qcscience.cc/", "_blank", "noopener,noreferrer"), icons.website);
    website.classList.add("tz-website");
    renderNavigation(shell, this, "website");
    const workspace = node(shell, "div", null, "tz-workspace");
    const context = node(workspace, "div", null, "tz-context");
    const contextTop = node(context, "div", null, "tz-context-top");
    this.contextMeta = node(contextTop, "span", null, "tz-context-meta");
    iconButton(contextTop, "\u4F7F\u7528\u5F53\u524D\u6253\u5F00\u7684\u8282\u70B9", () => this.plugin.useActiveFile(this), icons.node);
    this.contextLabel = button(node(context, "h3"), "", () => this.plugin.openDirectory(this, this.scope.chapter_id ? "chapter" : "knowledge"), "quiet");
    this.contextLabel.classList.add("tz-context-link");
    this.contextHint = node(context, "p", null, "tz-context-hint");
    const routes = node(context, "div", null, "tz-context-routes");
    this.chapterRoute = button(routes, "\u7AE0\u8282\u76EE\u5F55", () => this.plugin.openDirectory(this, "chapter"), "quiet");
    this.knowledgeRoute = button(routes, "\u77E5\u8BC6\u70B9\u76EE\u5F55", () => this.plugin.openDirectory(this, "knowledge"), "quiet");
    this.advanced = node(workspace, "details", null, "tz-advanced");
    const summary = node(this.advanced, "summary");
    node(summary, "span", "\u7B5B\u9009\u53D6\u9898\u8303\u56F4");
    node(summary, "span", "\u6559\u6750 / \u77E5\u8BC6\u70B9", "tz-filter-hint");
    this.advanced.open = this.plugin.settings.lastSelection?.advancedOpen ?? true;
    const grid = node(this.advanced, "div", null, "tz-grid");
    const reload = () => {
      this.reset(["edition_id", "grade_id", "chapter_id", "knowledge_tree_id"]);
      return this.loadScoped();
    };
    this.select(grid, "\u5B66\u79D1", "subject_id", reload);
    this.select(grid, "\u5B66\u6BB5", "phase_id", reload);
    this.chapterFields = node(grid, "div", null, "tz-grid");
    this.select(this.chapterFields, "\u6559\u6750\u7248\u672C\uFF08\u53EF\u9009\uFF09", "edition_id", () => {
      this.reset(["chapter_id"]);
      this.filterChapters();
      return this.loadChapters();
    });
    this.select(this.chapterFields, "\u5E74\u7EA7 / \u5B66\u671F\uFF08\u53EF\u9009\uFF09", "grade_id", () => {
      this.scope.chapter_id = null;
      this.filterChapters();
      this.say(this.loading ? "\u6B63\u5728\u52A0\u8F7D\u6240\u9009\u6559\u6750\uFF0C\u5B8C\u6210\u540E\u4F1A\u663E\u793A\u8FD9\u4E2A\u5B66\u671F\u7684\u7AE0\u8282\u3002" : `\u5DF2\u6309\u5B66\u671F\u7B5B\u9009 ${this.inputs.chapter_id.options.length - 1} \u4E2A\u7AE0\u8282\u3002`);
    });
    this.select(this.chapterFields, "\u7AE0\u8282\uFF08\u53EF\u9009\uFF09", "chapter_id", () => {
    });
    this.knowledgeFields = node(grid, "div", null, "tz-grid");
    this.select(this.knowledgeFields, "\u77E5\u8BC6\u70B9\uFF08\u53EF\u9009\uFF09", "knowledge_tree_id", () => {
    });
    node(this.advanced, "p", "\u7AE0\u8282\u548C\u77E5\u8BC6\u70B9\u4E8C\u9009\u4E00\uFF0C\u4E5F\u53EF\u4EE5\u90FD\u4E0D\u9009\u3002", "tz-muted tz-filter-choice-hint");
    const more = node(this.advanced, "details", null, "tz-directory-tools");
    node(more, "summary", "\u66F4\u591A\u76EE\u5F55\u64CD\u4F5C");
    button(more, "\u91CD\u65B0\u52A0\u8F7D\u76EE\u5F55", () => this.loadInitial(false, true, true), "quiet");
    node(more, "p", "\u76EE\u5F55\u6709\u66F4\u65B0\u6216\u52A0\u8F7D\u5F02\u5E38\u65F6\u518D\u4F7F\u7528\u3002", "tz-muted");
    const remembered = this.plugin.settings.lastSelection || {};
    const controls = node(workspace, "div", null, "tz-fetch-controls");
    const countRow = node(controls, "label", null, "tz-count");
    node(countRow, "span", "\u9898\u6570");
    this.count = node(countRow, "input");
    this.count.type = "number";
    this.count.min = "1";
    this.count.max = "20";
    this.count.step = "1";
    this.count.value = String(remembered.count >= 1 && remembered.count <= 20 ? remembered.count : 5);
    this.count.setAttribute("aria-label", "\u83B7\u53D6\u9898\u6570");
    this.count.title = "\u6BCF\u6B21\u83B7\u53D6 1\u201420 \u9898";
    this.fetchButton = button(controls, "\u83B7\u53D6\u9898\u76EE", () => this.run(() => this.fetch()), "primary");
    this.fetchButton.classList.add("tz-fetch");
    const options = node(workspace, "div", null, "tz-fetch-options");
    const check = node(options, "label", null, "tz-check");
    this.solutions = node(check, "input");
    this.solutions.type = "checkbox";
    this.solutions.checked = Boolean(remembered.solutions);
    node(check, "span", "\u542B\u7B54\u6848\u89E3\u6790");
    check.title = "\u4FDD\u5B58\u7B54\u6848\u548C\u89E3\u6790\uFF0C\u4F9B\u6559\u5E08\u53C2\u8003";
    const balance = node(options, "div", null, "tz-balance");
    this.quota = node(balance, "span", null, "tz-quota");
    this.showQuota();
    this.quotaButton = iconButton(balance, "\u5237\u65B0\u989D\u5EA6", () => this.refreshQuota(), icons.refresh);
    iconButton(balance, "\u8BBE\u7F6E\u81EA\u5DF1\u7684\u51ED\u8BC1", () => {
      this.app.setting.open();
      this.app.setting.openTabById(this.plugin.manifest.id);
    }, icons.key);
    for (const event of ["change"]) {
      this.count.addEventListener(event, () => this.remember());
      this.solutions.addEventListener(event, () => this.remember());
    }
    this.advanced.addEventListener("toggle", () => this.remember());
    node(workspace, "p", "\u53D6\u9898\u6263\u9898\u76EE\u989D\u5EA6 \xB7 \u4FDD\u5B58\u4E0D\u518D\u6263\u989D", "tz-cost-hint");
    const directory = node(workspace, "div", null, "tz-directory-balance");
    this.directoryQuotaText = node(directory, "span", "\u76EE\u5F55\u6309\u5B66\u6BB5 \xD7 \u5B66\u79D1\u5F00\u901A\uFF0C\u9ED8\u8BA4 5 \u4E2A\uFF1B\u540C\u4E00\u8303\u56F4\u91CD\u590D\u4F7F\u7528\u4E0D\u6263\u3002", "tz-muted");
    button(directory, "\u76EE\u5F55\u989D\u5EA6", async () => {
      try {
        if (!await this.plugin.api.directoryCapabilities(true)) {
          this.directoryQuotaText.textContent = "\u76EE\u5F55\u989D\u5EA6\u670D\u52A1\u5C1A\u672A\u53D1\u5E03\uFF0C\u5F53\u524D\u6CBF\u7528\u539F\u76EE\u5F55\u63A5\u53E3\u3002";
          return;
        }
        const state = await this.plugin.api.directoryQuota();
        this.directoryQuotaText.textContent = `\u76EE\u5F55\u5DF2\u5F00\u901A ${state.used} / ${state.limit} \u4E2A\uFF0C\u5269\u4F59 ${state.remaining} \u4E2A\u3002`;
      } catch (error) {
        this.say(error.message, true);
      }
    }, "quiet");
    this.loadNotice = node(shell, "p", "\u6B63\u5728\u52A0\u8F7D\u76EE\u5F55\uFF0C\u53EF\u7EE7\u7EED\u5207\u6362\u2026\u2026", "tz-progress");
    this.loadNotice.hidden = true;
    this.loadNotice.setAttribute("role", "status");
    this.status = node(shell, "p", "\u6B63\u5728\u52A0\u8F7D\u5B66\u79D1\u548C\u5B66\u6BB5\u2026\u2026", "tz-status");
    this.status.setAttribute("role", "status");
    this.status.setAttribute("aria-live", "polite");
    this.results = node(shell, "div", null, "tz-results");
  }
  async loadInitial(inRun = false, restore = true, force = false) {
    const wanted = restore ? this.plugin.settings.lastSelection : null;
    const task = async () => {
      const seq2 = this.epoch;
      const results = await Promise.all([this.plugin.api.meta("subjects", {}, { force }), this.plugin.api.meta("phases", {}, { force })]);
      if (seq2 !== this.epoch) return;
      this.meta.subjects = results[0];
      this.meta.phases = results[1];
      this.scope = {};
      this.nodes = [];
      this.knowledgeNodes = [];
      this.chapterOptions.clear();
      if (wanted && results[0].some((n) => n.id === wanted.scope?.subject_id) && results[1].some((n) => n.id === wanted.scope?.phase_id)) {
        this.mode = wanted.mode === "knowledge" ? "knowledge" : "chapter";
        this.scope = { ...wanted.scope };
        this.normalizeChoice();
        this.sourcePath = wanted.sourcePath || "";
      }
      await this.plugin.store.saveCatalog({ subjects: results[0], phases: results[1] });
      this.options("subject_id", results[0]);
      this.options("phase_id", results[1]);
      for (const k of ["edition_id", "grade_id", "chapter_id", "knowledge_tree_id"]) this.options(k, [], "\u8BF7\u5148\u9009\u62E9\u4E0A\u7EA7");
      if (this.scope.subject_id && this.scope.phase_id) {
        await this.loadScoped(true, force);
        if (seq2 !== this.epoch) return;
        if (this.scope.edition_id) await this.loadChapters(true, force);
        if (seq2 !== this.epoch) return;
        this.say(force ? "\u76EE\u5F55\u5DF2\u66F4\u65B0\uFF0C\u5F53\u524D\u9009\u62E9\u5DF2\u4FDD\u7559\u3002" : "\u5DF2\u6062\u590D\u4E0A\u6B21\u9009\u62E9\u3002");
      } else this.say("\u53EF\u5728\u5DE6\u4FA7\u9009\u62E9\u8282\u70B9\uFF0C\u6216\u7528\u9AD8\u7EA7\u7B5B\u9009\u8BBE\u7F6E\u8303\u56F4\u3002");
    };
    if (inRun) return task();
    return this.load(task);
  }
  async loadScoped(inRun = false, force = false) {
    if (!this.scope.subject_id || !this.scope.phase_id) return;
    const task = async () => {
      const seq2 = this.epoch, s = { ...this.scope };
      const [editions, grades] = await Promise.all([this.plugin.api.meta("editions", { subject_id: s.subject_id, phase_id: s.phase_id }, { force }), this.plugin.api.meta("grades", { phase_id: s.phase_id }, { force }), this.loadKnowledge(true, force)]);
      if (seq2 !== this.epoch) return;
      this.meta.editions = editions;
      this.meta.grades = grades;
      await this.plugin.store.saveCatalog({ editions });
      if (seq2 !== this.epoch) return;
      this.options("edition_id", editions, "\u4E0D\u9650\u6559\u6750\u7248\u672C");
      this.options("grade_id", grades, "\u5168\u90E8\u5E74\u7EA7 / \u5B66\u671F");
      if (this.scope.edition_id && !this.inputs.edition_id.value) {
        this.scope.edition_id = null;
        this.scope.chapter_id = null;
      }
      if (this.scope.grade_id && !this.inputs.grade_id.value) {
        this.scope.grade_id = null;
        this.scope.chapter_id = null;
      }
      this.filterChapters();
      this.say("\u7AE0\u8282\u548C\u77E5\u8BC6\u70B9\u4E8C\u9009\u4E00\uFF0C\u4E5F\u53EF\u4EE5\u90FD\u4E0D\u9009\u3002");
    };
    return inRun ? task() : this.load(task);
  }
  async loadKnowledge(inRun = false, force = false) {
    const task = async () => {
      const s = { ...this.scope }, seq2 = this.epoch, path = `.bank/taxonomy/${s.subject_id}-${s.phase_id}.json`, params = { subject_id: s.subject_id, phase_id: s.phase_id, limit: 5e3 };
      if (!force && await this.plugin.store.io.exists(path)) {
        const saved = JSON.parse(await this.plugin.store.io.read(path));
        if (saved.subject_id !== s.subject_id || saved.phase_id !== s.phase_id) throw Error("\u672C\u5730\u77E5\u8BC6\u6811\u5B66\u79D1\u5B66\u6BB5\u4E0D\u4E00\u81F4\u3002");
        validateKnowledge(saved.nodes);
        this.plugin.api.cache.seed("knowledge-points", params, saved.nodes, saved.downloaded_at);
      }
      const nodes = await this.plugin.api.meta("knowledge-points", params, { force });
      if (seq2 !== this.epoch) return;
      this.knowledgeNodes = validateKnowledge(nodes);
      try {
        if (await this.plugin.store.saveTaxonomy(s.subject_id, s.phase_id, nodes)) this.say(`\u77E5\u8BC6\u6811\u5DF2\u4FDD\u5B58\u5230\u672C\u5730\uFF08${nodes.length} \u4E2A\u8282\u70B9\uFF09\uFF0C\u5206\u7C7B\u548C\u6309\u8003\u70B9\u627E\u9898\u53EF\u4EE5\u7528\u4E86\u3002`);
      } catch {
        this.say("\u77E5\u8BC6\u6811\u5DF2\u52A0\u8F7D\uFF0C\u4F46\u672C\u5730\u76EE\u5F55\u751F\u6210\u672A\u5B8C\u6210\uFF1B\u8BF7\u68C0\u67E5\u9898\u5E93\u6587\u4EF6\u5939\u6743\u9650\u540E\u91CD\u8BD5\u3002", true);
      }
      if (this.directoryQuotaText) this.directoryQuotaText.textContent = this.plugin.api.directoryPolicy === "legacy" ? "\u76EE\u5F55\u989D\u5EA6\u670D\u52A1\u5C1A\u672A\u53D1\u5E03\uFF0C\u5F53\u524D\u6CBF\u7528\u539F\u76EE\u5F55\u63A5\u53E3\u3002" : "\u76EE\u5F55\u6309\u5B66\u6BB5 \xD7 \u5B66\u79D1\u5F00\u901A\uFF0C\u9ED8\u8BA4 5 \u4E2A\uFF1B\u540C\u4E00\u8303\u56F4\u91CD\u590D\u4F7F\u7528\u4E0D\u6263\u3002";
      const map2 = new Map(nodes.map((n) => [n.id, n]));
      this.options("knowledge_tree_id", nodes.map((n) => {
        const names = [n.name];
        let p = map2.get(n.parent_id);
        while (p) {
          names.unshift(p.name);
          p = map2.get(p.parent_id);
        }
        return { ...n, name: names.join(" / ") };
      }), "\u4E0D\u9650\u77E5\u8BC6\u70B9");
      if (s.knowledge_tree_id && !this.inputs.knowledge_tree_id.value) {
        this.scope.knowledge_tree_id = null;
        throw Error("\u4E0A\u6B21\u77E5\u8BC6\u70B9\u5DF2\u4E0D\u5728\u76EE\u5F55\u4E2D\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9\u3002");
      }
    };
    return inRun ? task() : this.load(task);
  }
  async loadChapters(inRun = false, force = false) {
    if (!this.scope.edition_id) return;
    const task = async () => {
      const s = { ...this.scope }, seq2 = this.epoch, params = { subject_id: s.subject_id, phase_id: s.phase_id, edition_id: s.edition_id, limit: 1e3 }, path = `.bank/textbooks/${s.subject_id}-${s.phase_id}-${s.edition_id}.json`;
      if (!force && await this.plugin.store.io.exists(path)) {
        const saved = JSON.parse(await this.plugin.store.io.read(path));
        validateChapters(saved.nodes, s);
        this.plugin.api.cache.seed("chapters", params, saved.nodes, saved.downloaded_at);
      }
      const data = await this.plugin.api.meta("chapters", params, { force });
      if (seq2 !== this.epoch) return;
      this.nodes = validateChapters(data, s);
      await this.plugin.store.saveTextbook(s, data);
      if (seq2 !== this.epoch) return;
      this.prepareChapters();
      this.filterChapters();
      if (this.scope.chapter_id && !this.inputs.chapter_id.value) {
        this.scope.chapter_id = null;
        throw Error("\u7AE0\u8282\u5DF2\u4E0D\u5728\u5F53\u524D\u7248\u672C\u76EE\u5F55\u4E2D\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9\u3002");
      }
      this.say(`\u5DF2\u52A0\u8F7D ${data.length} \u4E2A\u7AE0\u8282\u3002\u5207\u6362\u5B66\u671F\u4F1A\u7ACB\u5373\u7B5B\u9009\u3002`);
    };
    return inRun ? task() : this.load(task);
  }
  prepareChapters() {
    const map2 = new Map(this.nodes.map((n) => [String(n.id), n]));
    const values = this.nodes.map((n) => {
      let parts = [n.name], p = map2.get(String(n.parent_id));
      while (p) {
        parts.unshift(p.name);
        p = map2.get(String(p.parent_id));
      }
      const grade = this.meta.grades?.find((g) => String(g.id) === String(n.grade_id));
      return { ...n, name: (grade ? grade.name + " \xB7 " : "") + parts.join(" / ") };
    });
    this.chapterOptions.clear();
    this.chapterOptions.set("", values);
    for (const n of values) {
      const key = String(n.grade_id);
      if (!this.chapterOptions.has(key)) this.chapterOptions.set(key, []);
      this.chapterOptions.get(key).push(n);
    }
  }
  filterChapters() {
    const values = this.chapterOptions.get(this.scope.grade_id ? String(this.scope.grade_id) : "") || [];
    this.options("chapter_id", values, values.length ? "\u4E0D\u9650\u7AE0\u8282" : this.scope.edition_id ? "\u4E0D\u9650\u7AE0\u8282\uFF08\u5F53\u524D\u6761\u4EF6\u6682\u65E0\u76EE\u5F55\uFF09" : "\u4E0D\u9650\u7AE0\u8282\uFF08\u9009\u6559\u6750\u540E\u53EF\u7EC6\u9009\uFF09");
  }
  async fetch() {
    queryFilters(this.scope, this.directory());
    const count = Number(this.count.value);
    if (!Number.isInteger(count) || count < 1 || count > 20) throw Error("\u6BCF\u6B21\u83B7\u53D6\u9898\u6570\u987B\u4E3A 1 \u5230 20\u3002");
    if (!this.plugin.getKey()) throw Error("\u8BF7\u5148\u5728\u63D2\u4EF6\u8BBE\u7F6E\u4E2D\u586B\u5199\u81EA\u5DF1\u7684\u9898\u5E84 API Key\u3002");
    if (this.batch?.items.some((i) => !i.saved)) throw Error("\u4E0A\u6279\u9898\u76EE\u5C1A\u672A\u5168\u90E8\u4FDD\u5B58\uFF0C\u8BF7\u5148\u4FDD\u5B58\u6216\u70B9\u51FB\u300C\u6E05\u7A7A\u7ED3\u679C\u300D\u518D\u83B7\u53D6\uFF0C\u907F\u514D\u91CD\u590D\u6263\u989D\u3002");
    const s = { ...this.scope };
    const title = this.scopeText() + (!s.chapter_id && !s.knowledge_tree_id ? "\uFF08\u5F53\u524D\u5B66\u6BB5\u77E5\u8BC6\u6811\u8303\u56F4\uFF09" : "");
    const yes = await new Promise((resolve) => new SpendModal(this.app, `${title}\uFF1A\u6700\u591A\u83B7\u53D6 ${count} \u9898\uFF0C\u4F7F\u7528\u81EA\u5DF1\u7684\u989D\u5EA6\u3002`, resolve).open());
    if (!yes) {
      this.say("\u5DF2\u53D6\u6D88\u83B7\u53D6\uFF0C\u672A\u53D1\u9001\u53D6\u9898\u8BF7\u6C42\u3002");
      return;
    }
    await this.plugin.store.init();
    await this.plugin.store.mkdir(".bank/pending");
    this.say("\u6B63\u5728\u83B7\u53D6\u9898\u76EE\uFF0C\u8BF7\u52FF\u91CD\u590D\u70B9\u51FB\u2026\u2026");
    const solutions = this.solutions.checked;
    let data, before;
    const key = cursorKey(s);
    const offset = this.plugin.settings.cursors?.[key] || 0;
    try {
      data = await this.plugin.api.questions(s, this.directory(), count, { offset, onQuota: (q) => {
        before = q;
        this.showQuota(q.remaining, q.used);
      } });
    } catch (error) {
      let check = "";
      try {
        const after = await this.plugin.api.quota();
        this.showQuota(after.remaining, after.used);
        check = before ? `\u8BF7\u6C42\u524D\u540E\u4ECA\u65E5\u5DF2\u7528\u989D\u5EA6\uFF1A${before.used} \u2192 ${after.used} \u9898\u3002` : "\u989D\u5EA6\u5DF2\u5237\u65B0\u3002";
      } catch {
        check = "\u989D\u5EA6\u5237\u65B0\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u624B\u52A8\u5237\u65B0\u3002";
      }
      throw Error(error.message + "\n" + check);
    }
    this.batch = { scope: s, nodes: structuredClone(this.directory()), solutions, items: data.items.map((raw) => ({ raw: redacted(raw, solutions), saved: false, selected: true, path: null })) };
    let cacheFailed = false;
    try {
      await this.persistBatch();
    } catch {
      cacheFailed = true;
    }
    if (data.items.length) {
      this.plugin.settings.cursors = { ...this.plugin.settings.cursors, [key]: offset + data.items.length };
      try {
        await this.plugin.saveData(this.plugin.settings);
      } catch {
        cacheFailed = true;
      }
    }
    this.showQuota(data.quota_remaining_today);
    await this.renderBatch();
    this.say(data.items.length ? `\u5DF2\u83B7\u53D6 ${data.items.length} \u9898\u3002\u4FDD\u5B58\u5230\u672C\u5730\u4E0D\u518D\u6263\u989D\u3002${cacheFailed ? "\u53D6\u9898\u7F13\u5B58\u5199\u5165\u5931\u8D25\uFF0C\u8BF7\u4FDD\u6301\u9762\u677F\u6253\u5F00\u5E76\u7ACB\u5373\u4FDD\u5B58\u3002" : ""}` : offset ? "\u5F53\u524D\u8303\u56F4\u6CA1\u6709\u66F4\u591A\u9898\u76EE\u3002\u53EF\u66F4\u6362\u8282\u70B9\uFF1B\u4E0D\u4F1A\u81EA\u52A8\u653E\u5BBD\u7B5B\u9009\u6761\u4EF6\u3002" : "\u5F53\u524D\u7B5B\u9009\u8303\u56F4\u6CA1\u6709\u5339\u914D\u9898\u76EE\uFF0C\u53EF\u8C03\u6574\u6761\u4EF6\uFF1B\u4E0D\u4F1A\u81EA\u52A8\u653E\u5BBD\u7B5B\u9009\u6761\u4EF6\u3002", cacheFailed);
  }
  async persistBatch() {
    await this.plugin.store.io.write(".bank/pending/questions.json", JSON.stringify({ schema: "tizhuang.pending/v2", batch: this.batch }, null, 2));
  }
  updateSelection(disabled = this.lock) {
    if (!this.batch || !this.saveButton) return;
    const unsaved = this.batch.items.filter((i) => !i.saved), chosen = unsaved.filter((i) => i.selected).length;
    this.selectionLabel.textContent = `\u5DF2\u9009 ${chosen} / ${unsaved.length}`;
    this.selectAll.checked = unsaved.length > 0 && chosen === unsaved.length;
    this.selectAll.indeterminate = chosen > 0 && chosen < unsaved.length;
    this.selectAll.disabled = disabled || !unsaved.length;
    this.saveButton.textContent = chosen ? `\u4FDD\u5B58\u5230\u672C\u5730 (${chosen})` : "\u4FDD\u5B58\u5230\u672C\u5730";
    this.saveButton.disabled = disabled || !chosen;
  }
  questionMetadata(raw) {
    const knowledge = typeof raw.knowledges === "string" ? raw.knowledges.split(/[,，、]/).map((s) => s.trim()).filter(Boolean) : [];
    const difficulty = typeof raw.difficulty === "number" && Number.isFinite(raw.difficulty) && raw.difficulty >= 0 && raw.difficulty <= 5 ? raw.difficulty : null;
    const difficultyLabel = difficulty == null ? null : difficulty <= 2 ? "\u7B80\u5355" : difficulty >= 4 ? "\u56F0\u96BE" : "\u4E2D\u7B49";
    return { knowledge: [...new Set(knowledge)], difficulty, difficultyLabel };
  }
  async renderQuestionDetails(region, item, q) {
    const { raw } = item;
    if (!this.batch.solutions) node(region, "p", "\u672C\u6B21\u672A\u5305\u542B\u7B54\u6848\u89E3\u6790\u3002\u4E0B\u6B21\u53D6\u9898\u53EF\u52FE\u9009\u300C\u542B\u7B54\u6848\u89E3\u6790\u300D\u3002", "tz-detail-empty");
    else if (!q) node(region, "p", "\u9898\u76EE\u683C\u5F0F\u5F02\u5E38\uFF0C\u6682\u65E0\u6CD5\u663E\u793A\u7B54\u6848\u89E3\u6790\u3002", "tz-detail-empty");
    else for (const [key, title] of [["answer", "\u7B54\u6848"], ["analysis", "\u89E3\u6790"]]) {
      const section = node(region, "section", null, "tz-detail-section");
      node(section, "h4", title);
      const content = node(section, "div", null, "tz-preview");
      if (q[key]?.trim()) await import_obsidian5.MarkdownRenderer.render(this.app, q[key], content, "", this);
      else node(content, "p", `\u7F51\u7AD9\u672A\u63D0\u4F9B${title}\u3002`, "tz-detail-empty");
    }
    const sourceFields = [["\u6765\u6E90\u5E74\u4EFD", Number.isInteger(raw.year) && raw.year > 0 ? raw.year : null], ["\u6765\u6E90\u5730\u533A", typeof raw.area === "string" ? raw.area.trim() : null], ["\u539F\u8BD5\u5377\u6765\u6E90", typeof raw.source === "string" ? raw.source.trim() : null], ["\u6765\u6E90\u9898\u53F7", raw.id]].filter(([, value]) => value != null && value !== "");
    if (sourceFields.length) {
      const footer = node(region, "footer", null, "tz-source-line");
      footer.setAttribute("aria-label", "\u9898\u76EE\u6765\u6E90");
      for (const [title, value] of sourceFields) {
        const field = node(footer, "span", String(value));
        field.title = title;
      }
    }
  }
  async renderBatch() {
    this.results.replaceChildren();
    this.saveButton = null;
    if (!this.batch || !this.batch.items.length) return;
    const toolbar = node(this.results, "div", null, "tz-result-toolbar");
    const selection = node(toolbar, "label", null, "tz-check tz-select-all");
    this.selectAll = node(selection, "input");
    this.selectAll.type = "checkbox";
    this.selectAll.setAttribute("aria-label", "\u5168\u9009\u672A\u4FDD\u5B58\u7684\u9898\u76EE");
    this.selectionLabel = node(selection, "span");
    this.selectAll.addEventListener("change", () => {
      for (const item of this.batch.items) if (!item.saved) item.selected = this.selectAll.checked;
      for (const input of this.results.querySelectorAll('.tz-question input:not([data-saved="true"])')) {
        input.checked = this.selectAll.checked;
        input.closest(".tz-question").classList.toggle("is-selected", input.checked);
      }
      this.updateSelection();
    });
    const actions = node(toolbar, "div", null, "tz-result-actions");
    this.saveButton = button(actions, "\u4FDD\u5B58\u5230\u672C\u5730", () => this.run(() => this.saveBatch()), "primary");
    iconButton(actions, "\u6E05\u7A7A\u7ED3\u679C", () => this.run(async () => {
      if (await this.plugin.store.io.exists(".bank/pending/questions.json")) await this.plugin.store.io.remove(".bank/pending/questions.json");
      this.batch = null;
      this.saveButton = null;
      this.results.replaceChildren();
      this.say("\u7ED3\u679C\u5DF2\u6E05\u7A7A\uFF0C\u5DF2\u6D88\u8017\u7684\u989D\u5EA6\u4E0D\u4F1A\u9000\u56DE\u3002");
    }), icons.clear);
    const list = node(this.results, "div", null, "tz-question-list");
    for (const [index, item] of this.batch.items.entries()) {
      const card = node(list, "section", null, "tz-question");
      card.classList.toggle("is-selected", Boolean(item.selected && !item.saved));
      card.classList.toggle("is-saved", Boolean(item.saved));
      const head = node(card, "div", null, "tz-question-head");
      const input = node(head, "input");
      input.type = "checkbox";
      input.checked = item.selected;
      input.disabled = item.saved || this.lock;
      input.dataset.saved = String(Boolean(item.saved));
      input.setAttribute("aria-label", `\u52FE\u9009\u7B2C ${index + 1} \u9053\u9898`);
      input.addEventListener("change", () => {
        item.selected = input.checked;
        card.classList.toggle("is-selected", input.checked);
        this.updateSelection();
      });
      node(head, "span", item.raw.question_type || "\u672A\u5206\u7C7B", "tz-type");
      const meta = this.questionMetadata(item.raw);
      if (meta.difficultyLabel) node(head, "span", meta.difficultyLabel, "tz-difficulty");
      const knowledge = node(head, "span", meta.knowledge.join(" \xB7 "), "tz-knowledge");
      knowledge.title = meta.knowledge.join("\u3001");
      node(head, "span", item.saved ? "\u5DF2\u4FDD\u5B58" : "\u672A\u4FDD\u5B58", "tz-local-status" + (item.saved ? " tz-saved" : ""));
      if (item.path) iconButton(head, "\u6253\u5F00\u672C\u5730\u9898\u76EE", () => this.app.workspace.openLinkText(item.path, "", false), icons.open);
      let q;
      try {
        q = questionFrom(item.raw, this.batch.scope, this.batch.solutions, markdown);
        const preview = node(card, "div", null, "tz-preview");
        await import_obsidian5.MarkdownRenderer.render(this.app, q.content, preview, "", this);
      } catch (e) {
        node(card, "p", e.message, "tz-error");
      }
      const region = node(card, "div", null, "tz-question-details");
      region.hidden = true;
      region.id = "tz-detail-" + crypto.randomUUID();
      region.setAttribute("role", "region");
      region.setAttribute("aria-label", `\u7B2C ${index + 1} \u9053\u9898\u8BE6\u60C5`);
      let rendered;
      const setOpen = async (open) => {
        region.hidden = !open;
        toggle.textContent = open ? "\u6536\u8D77" : "\u8BE6\u60C5";
        toggle.setAttribute("aria-expanded", String(open));
        if (open) {
          this.expandedQuestions.add(String(item.raw.id));
          rendered ?? (rendered = this.renderQuestionDetails(region, item, q).catch(() => node(region, "p", "\u8BE6\u60C5\u663E\u793A\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u9898\u5E93\u9762\u677F\u3002", "tz-error")));
          await rendered;
        } else this.expandedQuestions.delete(String(item.raw.id));
      };
      const toggle = button(head, "\u8BE6\u60C5", () => setOpen(region.hidden), "quiet");
      toggle.classList.add("tz-detail-toggle");
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-controls", region.id);
      toggle.title = "\u67E5\u770B\u7B54\u6848\u3001\u89E3\u6790\u548C\u6765\u6E90\uFF0C\u4E0D\u6263\u9898\u76EE\u989D\u5EA6";
      toggle.disabled = this.lock;
      if (this.expandedQuestions.has(String(item.raw.id))) await setOpen(true);
    }
    this.updateSelection();
  }
  async saveBatch() {
    if (this.plugin.localTaskActive) throw Error("\u672C\u5730\u5BFC\u5165\u6B63\u5728\u5199\u5165\u9898\u5E93\uFF0C\u8BF7\u7B49\u5F85\u5B8C\u6210\u540E\u4FDD\u5B58\u3002");
    if (!this.batch) return;
    let added = 0, duplicates = 0;
    const errors = [];
    const chosen = this.batch.items.filter((i) => i.selected && !i.saved);
    if (!chosen.length) {
      this.say("\u8BF7\u9009\u62E9\u5C1A\u672A\u4FDD\u5B58\u7684\u9898\u76EE\u3002");
      return;
    }
    for (const item of chosen) {
      try {
        this.say(`\u6B63\u5728\u4FDD\u5B58\u9898\u53F7 ${item.raw.id}\u2026\u2026`);
        const q = questionFrom(item.raw, this.batch.scope, this.batch.solutions, markdown);
        const prepared = await localize(q, import_obsidian5.requestUrl, document);
        const r = await this.plugin.store.save(prepared.question, this.batch.nodes, prepared.downloaded);
        item.saved = true;
        item.path = r.path;
        if (r.action === "duplicate") duplicates++;
        else added++;
        await this.persistBatch();
      } catch (e) {
        errors.push(`\u9898\u53F7 ${item.raw.id}\uFF1A${e.message}`);
      }
    }
    await this.renderBatch();
    this.say(`\u65B0\u589E ${added} \u9898\uFF0C\u5DF2\u6709 ${duplicates} \u9898\u3002${errors.length ? "\n" + errors.join("\n") + "\n\u53EF\u518D\u6B21\u70B9\u51FB\u4FDD\u5B58\uFF0C\u65E0\u9700\u91CD\u65B0\u53D6\u9898\u3002" : "\u53EF\u5728\u300C\u9898\u76EE\u5E93\u300D\u4E2D\u67E5\u770B\uFF0C\u6216\u4EA4\u7ED9\u672C\u5730 skill \u68C0\u7D22\u3001\u7EC4\u5377\u3002"}`, Boolean(errors.length));
  }
};
var TeacherBankPlugin = class extends import_obsidian5.Plugin {
  async onload() {
    this.settings = await this.loadData() || {};
    this.sessionKey = "";
    this.store = new Store(this.app.vault.adapter);
    this.basket = await new PaperBasket(this.store).load();
    this.api = new Api(import_obsidian5.requestUrl, () => this.getKey(), { cache: new MetadataCache(this.store.io), scopedDirectories: true });
    this.registerView(VIEW, (leaf) => new BankView(leaf, this));
    this.addSettingTab(new CredentialsTab(this.app, this));
    this.registerView(LIBRARY_VIEW, (leaf) => new LibraryView(leaf, this));
    this.registerMarkdownCodeBlockProcessor?.("tizhuang-dashboard", (_source, el) => {
      const actions = node(el, "div", null, "tz-actions");
      button(actions, "\u6253\u5F00\u9898\u5E93\u5DE5\u4F5C\u53F0", () => this.openLibrary("home"), "primary");
      button(actions, "\u6D4F\u89C8\u6211\u7684\u9898\u76EE", () => this.openLibrary("questions"));
      button(actions, "\u5BFC\u5165 PDF", () => this.openLibrary("pdf"));
      button(actions, "\u6253\u5F00\u7EC4\u5377\u7BEE", () => this.openLibrary("basket"));
    });
    this.registerMarkdownCodeBlockProcessor?.("tizhuang-paper", async (_source, el, ctx) => {
      const source = ctx?.sourcePath || "";
      if (!/^试卷\/[^/]+\/试卷\.md$/.test(source)) return;
      const folder = source.slice(0, source.lastIndexOf("/")), actions = node(el, "div", null, "tz-actions");
      for (const [name2, rel] of [["\u65E0\u7B54\u6848 Word", "\u6253\u5370\u7A3F/\u8BD5\u5377.docx"], ["\u6559\u5E08\u7B54\u6848 Word", "\u6559\u5E08\u7A3F/\u8BD5\u5377.docx"], ["\u65E0\u7B54\u6848\u6253\u5370\u7A3F", "\u6253\u5370\u7A3F/\u8BD5\u5377.html"], ["\u6559\u5E08\u6253\u5370\u7A3F", "\u6559\u5E08\u7A3F/\u8BD5\u5377.html"]]) if (await this.store.io.exists(folder + "/" + rel)) button(actions, name2, () => this.openLocalOutput(this.app.vault.adapter.getBasePath() + "/" + folder + "/" + rel));
    });
    this.registerMarkdownPostProcessor((el, ctx) => {
      for (const img of el.querySelectorAll("img")) {
        const src = img.getAttribute("src") || "";
        const m = src.match(/^(?:\.\.\/)+((?:资料\/)?附件\/[a-f0-9]{64}\.(?:png|jpe?g|gif|webp))$/);
        if (m) {
          const file2 = this.app.vault.getAbstractFileByPath(m[1]);
          if (file2) img.src = this.app.vault.getResourcePath(file2);
        }
      }
      if (ctx?.sourcePath?.startsWith("\u8BD5\u5377/") && ctx.sourcePath.endsWith("/\u8BD5\u5377.md")) for (const link of el.querySelectorAll("a")) {
        let href;
        try {
          href = decodeURIComponent(link.getAttribute("data-href") || link.getAttribute("href") || "");
        } catch {
          continue;
        }
        if (/^(打印稿|教师稿)\/试卷\.(html|docx)$/.test(href)) {
          link.addEventListener("click", (event) => {
            event.preventDefault();
            event.stopImmediatePropagation();
            this.openLocalOutput(this.app.vault.adapter.getBasePath() + "/" + ctx.sourcePath.slice(0, ctx.sourcePath.lastIndexOf("/")) + "/" + href);
          }, true);
        }
      }
      const file = ctx?.sourcePath ? this.app.vault.getAbstractFileByPath(ctx.sourcePath) : null;
      const context = this.contextFor(file);
      if (context && el.querySelector("h1") && !el.querySelector(".tz-node-action")) {
        const b = button(el, "\u6D4F\u89C8\u672C\u5730\u9898\u76EE", async () => {
          const view = await this.openLibrary("questions");
          await view?.fromContext(context);
        }, "primary");
        b.classList.add("tz-node-action");
        el.prepend(b);
        const fetch = button(el, "\u4ECE\u7F51\u7AD9\u8865\u9898", () => this.openFromContext(context));
        fetch.classList.add("tz-node-action");
        fetch.title = "\u81EA\u52A8\u8BBE\u7F6E\u53D6\u9898\u8303\u56F4\uFF0C\u786E\u8BA4\u540E\u624D\u6263\u51CF\u989D\u5EA6";
      }
    });
    this.registerEvent(this.app.workspace.on("file-menu", (menu, file) => {
      const context = this.contextFor(file);
      if (context) {
        menu.addItem((item) => item.setTitle("\u6D4F\u89C8\u672C\u5730\u9898\u76EE").setIcon("library").onClick(async () => {
          const view = await this.openLibrary("questions");
          await view?.fromContext(context);
        }));
        menu.addItem((item) => item.setTitle(context.mode === "chapter" ? "\u4ECE\u6B64\u7AE0\u8282\u83B7\u53D6\u9898\u76EE" : "\u4ECE\u6B64\u77E5\u8BC6\u70B9\u83B7\u53D6\u9898\u76EE").setIcon("download").onClick(() => this.openFromContext(context)));
      }
    }));
    this.registerEvent(this.app.workspace.on("file-open", (file) => {
      if (this.routingDirectory) return;
      const context = this.contextFor(file);
      if (context) {
        for (const leaf of this.app.workspace.getLeavesOfType(VIEW)) leaf.view?.applyContext(context);
        for (const leaf of this.app.workspace.getLeavesOfType(LIBRARY_VIEW)) leaf.view?.fromContext(context);
      }
    }));
    this.addRibbonIcon("library", "\u6253\u5F00\u9898\u5E84\u672C\u5730\u9898\u5E93", () => this.openLibrary("home"));
    this.addCommand({ id: "open-teacher-bank", name: "\u6253\u5F00\u672C\u5730\u9898\u5E93", callback: () => this.openLibrary("home") });
    this.addCommand({ id: "open-paper-basket", name: "\u6253\u5F00\u53EF\u89C6\u5316\u7EC4\u5377\u7BEE", callback: () => this.openLibrary("basket") });
    this.addCommand({ id: "browse-local-questions", name: "\u6D4F\u89C8\u672C\u5730\u9898\u76EE", callback: () => this.openLibrary("questions") });
    this.addCommand({ id: "import-local-pdf", name: "\u5BFC\u5165 PDF \u8BD5\u5377", callback: () => this.openLibrary("pdf") });
    this.addCommand({ id: "fetch-website-questions", name: "\u4ECE\u7F51\u7AD9\u83B7\u53D6\u9898\u76EE", callback: () => this.open() });
    this.addCommand({ id: "fetch-from-current-node", name: "\u4ECE\u5F53\u524D\u7AE0\u8282\u6216\u77E5\u8BC6\u70B9\u83B7\u53D6\u9898\u76EE", callback: () => this.useActiveFile() });
    const refresh = (file) => {
      if (!file?.path?.startsWith("\u9898\u76EE\u5E93/")) return;
      clearTimeout(this.refreshTimer);
      this.refreshTimer = setTimeout(() => {
        if (!this.localTaskActive) for (const leaf of this.app.workspace.getLeavesOfType(LIBRARY_VIEW)) leaf.view?.refresh();
      }, 300);
    };
    if (this.app.vault.on) for (const name2 of ["create", "modify", "delete", "rename"]) this.registerEvent(this.app.vault.on(name2, refresh));
  }
  contextFor(file) {
    if (!file) return null;
    let target = file;
    if (file.extension !== "md") target = this.app.vault.getAbstractFileByPath(file.path + ".md");
    if (!target) return null;
    return contextFromProperties(this.app.metadataCache.getFileCache(target)?.frontmatter, target.path);
  }
  async openDirectory(view, kind) {
    try {
      await openDirectory(this, view, kind);
    } catch (error) {
      view.say(error.message || "\u76EE\u5F55\u6253\u5F00\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002", true);
    }
  }
  async useActiveFile(view) {
    const context = this.contextFor(this.app.workspace.getActiveFile());
    if (!context) {
      new import_obsidian5.Notice("\u8BF7\u5148\u5728\u5DE6\u4FA7\u6253\u5F00\u4E00\u4E2A\u5E26\u7AE0\u8282\u7F16\u53F7\u6216\u77E5\u8BC6\u8282\u70B9\u7F16\u53F7\u7684\u8282\u70B9\u7B14\u8BB0\u3002");
      return;
    }
    if (view) return view.applyContext(context);
    return this.openFromContext(context);
  }
  async openFromContext(context) {
    const view = await this.open();
    if (view) await view.applyContext(context);
  }
  async saveSelection(selection) {
    this.settings.lastSelection = selection;
    await this.saveData(this.settings);
  }
  getKey() {
    return this.sessionKey || (this.settings.secretId && this.app.secretStorage?.getSecret(this.settings.secretId) || "");
  }
  async setKey(key, persist) {
    if (persist && this.app.secretStorage) {
      const id = this.settings.secretId || "tizhuang-question-bank-" + crypto.randomUUID().replaceAll("-", "");
      this.app.secretStorage.setSecret(id, key);
      this.settings.secretId = id;
      this.sessionKey = "";
      await this.saveData(this.settings);
    } else {
      await this.clearKey();
      this.sessionKey = key;
    }
  }
  async clearKey() {
    if (this.settings.secretId && this.app.secretStorage) this.app.secretStorage.setSecret(this.settings.secretId, "");
    this.sessionKey = "";
    delete this.settings.secretId;
    await this.saveData(this.settings);
  }
  async open(preferredLeaf) {
    let leaf = preferredLeaf || this.app.workspace.getLeavesOfType(VIEW)[0];
    if (!leaf || leaf.view?.getViewType?.() !== VIEW) {
      leaf = leaf || this.app.workspace.getLeaf("tab");
      if (!leaf) {
        new import_obsidian5.Notice("\u65E0\u6CD5\u6253\u5F00\u9898\u5E93\u9762\u677F\u3002");
        return;
      }
      await leaf.setViewState({ type: VIEW, active: true });
    }
    await this.app.workspace.revealLeaf(leaf);
    return leaf.view;
  }
  async openLibrary(tab = "home", preferredLeaf) {
    let leaf = preferredLeaf || this.app.workspace.getLeavesOfType(LIBRARY_VIEW)[0];
    if (!leaf || leaf.view?.getViewType?.() !== LIBRARY_VIEW) {
      leaf = leaf || this.app.workspace.getLeaf("tab");
      if (!leaf) return;
      await leaf.setViewState({ type: LIBRARY_VIEW, active: true });
    }
    await this.app.workspace.revealLeaf(leaf);
    if (leaf.view?.show) await leaf.view.show(tab);
    return leaf.view;
  }
  async openLocalOutput(value) {
    const base = this.app.vault.adapter.getBasePath().replace(/\\/g, "/").replace(/\/$/, ""), path = String(value).replace(/\\/g, "/");
    if (!path.toLowerCase().startsWith((base + "/\u8BD5\u5377/").toLowerCase()) || path.split("/").includes("..") || !/^.+\/(打印稿|教师稿)\/试卷\.(html|docx)$/.test(path)) {
      new import_obsidian5.Notice("\u8BD5\u5377\u8F93\u51FA\u8DEF\u5F84\u65E0\u6548");
      return;
    }
    try {
      const error = await require("electron").shell.openPath(path);
      if (error) new import_obsidian5.Notice("\u6253\u5F00\u5931\u8D25\uFF1A" + error);
    } catch (error) {
      new import_obsidian5.Notice("\u8BF7\u4ECE\u8BD5\u5377\u8BB0\u5F55\u4E2D\u6253\u5F00\u6587\u4EF6\uFF1A" + error.message);
    }
  }
  runLocal(command, args) {
    return runLocal(this, command, args);
  }
  onunload() {
    this.sessionKey = "";
    clearTimeout(this.refreshTimer);
  }
};
/*! Bundled license information:

dompurify/dist/purify.es.mjs:
  (*! @license DOMPurify 3.4.16 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.4.16/LICENSE *)
  (*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE *)
*/
